
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Replicate from "https://esm.sh/replicate@0.25.2"

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ImageGenerationRequest {
  prompt: string;
  model: string;
  quality?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const REPLICATE_API_KEY = Deno.env.get('REPLICATE_API_KEY')
    if (!REPLICATE_API_KEY) {
      throw new Error('REPLICATE_API_KEY is not set')
    }

    const replicate = new Replicate({
      auth: REPLICATE_API_KEY,
    })

    const body: ImageGenerationRequest = await req.json()

    if (!body.prompt) {
      return new Response(
        JSON.stringify({ 
          error: "Missing required field: prompt is required" 
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      )
    }

    console.log("Generating image with Replicate:", { model: body.model, promptLength: body.prompt.length })

    // Map model IDs to Replicate model names
    const modelMap: Record<string, string> = {
      'flux-schnell': 'black-forest-labs/flux-schnell',
      'flux-dev': 'black-forest-labs/flux-dev',
    }

    const replicateModel = modelMap[body.model] || 'black-forest-labs/flux-schnell'

    // Configure model-specific parameters
    const baseConfig = {
      prompt: body.prompt,
      go_fast: true,
      num_outputs: 1,
      aspect_ratio: "1:1",
      output_format: "webp" as const,
      output_quality: 80,
    }

    let modelConfig
    if (body.model === 'flux-dev') {
      modelConfig = {
        ...baseConfig,
        guidance_scale: 3.5,
        num_inference_steps: 28,
        megapixels: body.quality === 'ultra' ? "1" : "0.25",
      }
    } else {
      // flux-schnell
      modelConfig = {
        ...baseConfig,
        num_inference_steps: 4,
        megapixels: body.quality === 'ultra' ? "1" : "0.25",
      }
    }

    const output = await replicate.run(replicateModel, {
      input: modelConfig
    })

    console.log("Replicate generation completed successfully")

    // Extract the image URL from the output
    const imageUrl = Array.isArray(output) ? output[0] : output

    return new Response(JSON.stringify({ imageUrl }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    console.error("Error in replicate-image-generation function:", error)
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})
