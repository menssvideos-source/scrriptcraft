
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { temporaryUrl, scriptId, frameId, sceneNumber, title } = await req.json()
    
    console.log(`Starting server-side image storage for frame ${frameId}`)
    console.log(`Source URL: ${temporaryUrl.substring(0, 60)}...`)

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Get user from authorization header
    const authHeader = req.headers.get('authorization')
    if (!authHeader) {
      throw new Error('No authorization header provided')
    }

    const { data: { user }, error: userError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )
    
    if (userError || !user) {
      throw new Error(`Authentication failed: ${userError?.message || 'User not found'}`)
    }

    console.log(`Authenticated user: ${user.id}`)

    // Download the image from the temporary URL (server-side, no CORS issues)
    console.log('Downloading image from DALL-E (server-side)...')
    const response = await fetch(temporaryUrl)
    
    if (!response.ok) {
      throw new Error(`Failed to download image: ${response.status} ${response.statusText}`)
    }

    const imageBlob = await response.blob()
    console.log(`Downloaded image: ${imageBlob.size} bytes, type: ${imageBlob.type}`)

    // Generate a unique filename
    const timestamp = Date.now()
    const fileName = `${user.id}/${scriptId}/${frameId}_${timestamp}.png`
    console.log(`Storage path: ${fileName}`)

    // Convert blob to array buffer for upload
    const arrayBuffer = await imageBlob.arrayBuffer()
    const uint8Array = new Uint8Array(arrayBuffer)

    // Upload to Supabase Storage
    console.log('Uploading to Supabase storage...')
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('storyboard-images')
      .upload(fileName, uint8Array, {
        contentType: 'image/png',
        upsert: true,
        cacheControl: '3600'
      })

    if (uploadError) {
      console.error('Storage upload error:', uploadError)
      throw new Error(`Storage upload failed: ${uploadError.message}`)
    }

    console.log('Upload successful:', uploadData.path)

    // Get the public URL
    const { data: urlData } = supabase.storage
      .from('storyboard-images')
      .getPublicUrl(fileName)

    const publicUrl = urlData.publicUrl
    console.log(`Generated public URL: ${publicUrl}`)

    // Store metadata in the database
    console.log('Storing image metadata...')
    const { error: dbError } = await supabase
      .from('storyboard_images')
      .upsert({
        script_id: scriptId,
        frame_id: frameId,
        scene_number: sceneNumber,
        title: title,
        image_path: fileName,
        user_id: user.id,
        original_url: temporaryUrl
      }, {
        onConflict: 'script_id,frame_id'
      })

    if (dbError) {
      console.error('Database error:', dbError)
      throw new Error(`Database storage failed: ${dbError.message}`)
    }

    console.log('Metadata stored successfully')

    return new Response(
      JSON.stringify({ 
        success: true, 
        publicUrl: publicUrl,
        message: 'Image stored successfully'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Server-side image storage failed:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})
