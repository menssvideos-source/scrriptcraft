
-- Create storage bucket for storyboard images if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('storyboard-images', 'storyboard-images', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing storage policies if they exist
DROP POLICY IF EXISTS "Users can view storyboard images" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload storyboard images" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their storyboard images" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their storyboard images" ON storage.objects;

-- Create comprehensive storage policies for storyboard images
CREATE POLICY "Users can view storyboard images" ON storage.objects
  FOR SELECT USING (bucket_id = 'storyboard-images');

CREATE POLICY "Users can upload storyboard images" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'storyboard-images' AND 
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can update their storyboard images" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'storyboard-images' AND 
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can delete their storyboard images" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'storyboard-images' AND 
    auth.role() = 'authenticated'
  );
