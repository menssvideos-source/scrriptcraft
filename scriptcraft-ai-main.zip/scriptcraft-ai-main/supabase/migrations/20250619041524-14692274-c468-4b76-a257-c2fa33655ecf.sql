
-- Check if scripts table has proper structure for title updates
-- The scripts table should already have a title column based on the schema
-- Let's ensure RLS policies are properly set for script updates

-- Enable RLS on scripts table if not already enabled
ALTER TABLE public.scripts ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate them
DROP POLICY IF EXISTS "Users can view their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can update their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can insert their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can delete their own scripts" ON public.scripts;

-- Create policy for users to view their own scripts
CREATE POLICY "Users can view their own scripts" 
  ON public.scripts 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create policy for users to update their own scripts
CREATE POLICY "Users can update their own scripts" 
  ON public.scripts 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create policy for users to insert their own scripts
CREATE POLICY "Users can insert their own scripts" 
  ON public.scripts 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Create policy for users to delete their own scripts
CREATE POLICY "Users can delete their own scripts" 
  ON public.scripts 
  FOR DELETE 
  USING (auth.uid() = user_id);
