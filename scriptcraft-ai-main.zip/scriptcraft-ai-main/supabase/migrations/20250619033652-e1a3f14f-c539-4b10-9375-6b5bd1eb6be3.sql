
-- Create a table to store storyboard images with metadata
CREATE TABLE public.storyboard_images (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  script_id UUID NOT NULL,
  frame_id TEXT NOT NULL,
  scene_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  image_path TEXT NOT NULL,
  original_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  user_id UUID REFERENCES auth.users NOT NULL,
  UNIQUE(script_id, frame_id)
);

-- Add Row Level Security (RLS)
ALTER TABLE public.storyboard_images ENABLE ROW LEVEL SECURITY;

-- Create policies for storyboard images
CREATE POLICY "Users can view their own storyboard images" 
  ON public.storyboard_images 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own storyboard images" 
  ON public.storyboard_images 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own storyboard images" 
  ON public.storyboard_images 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own storyboard images" 
  ON public.storyboard_images 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Create storage bucket for storyboard images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('storyboard-images', 'storyboard-images', true);

-- Create storage policies
CREATE POLICY "Users can view storyboard images" ON storage.objects
  FOR SELECT USING (bucket_id = 'storyboard-images');

CREATE POLICY "Users can upload storyboard images" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'storyboard-images' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their storyboard images" ON storage.objects
  FOR UPDATE USING (bucket_id = 'storyboard-images' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their storyboard images" ON storage.objects
  FOR DELETE USING (bucket_id = 'storyboard-images' AND auth.uid()::text = (storage.foldername(name))[1]);
