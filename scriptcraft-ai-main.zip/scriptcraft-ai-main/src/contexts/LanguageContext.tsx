
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, languages, translations, TranslationKey } from '../lib/i18n';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: React.ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  // Auto-detect user's preferred language on first visit
  useEffect(() => {
    const savedLanguage = localStorage.getItem('scriptcraft-language') as Language;
    if (savedLanguage && Object.keys(languages).includes(savedLanguage)) {
      setLanguage(savedLanguage);
    } else {
      // Auto-detect Arabic if user's browser language is Arabic
      const browserLanguage = navigator.language.toLowerCase();
      if (browserLanguage.startsWith('ar')) {
        setLanguage('ar');
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('scriptcraft-language', language);
    document.documentElement.lang = language;
    document.documentElement.dir = languages[language].dir;
    document.body.className = languages[language].dir === 'rtl' ? 'rtl' : 'ltr';
    
    // Add Arabic font class for better typography
    if (language === 'ar') {
      document.body.classList.add('font-arabic');
    } else {
      document.body.classList.remove('font-arabic');
    }
  }, [language]);

  const t = (key: TranslationKey): string => {
    return translations[language][key] || translations.en[key] || key;
  };

  const isRTL = languages[language].dir === 'rtl';

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};
