
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { storageService } from '../services/StorageService';
import { useAuth } from './AuthContext';

export interface ImageModel {
  id: string;
  name: string;
  provider: 'openai' | 'huggingface' | 'replicate';
  cost: 'low' | 'medium' | 'high';
  quality: 'standard' | 'high' | 'ultra';
  description: string;
}

export const AVAILABLE_IMAGE_MODELS: ImageModel[] = [
  {
    id: 'dall-e-3',
    name: 'DALL-E 3',
    provider: 'openai',
    cost: 'high',
    quality: 'ultra',
    description: 'OpenAI\'s premium model with exceptional quality'
  },
  {
    id: 'dall-e-2',
    name: 'DALL-E 2',
    provider: 'openai',
    cost: 'medium',
    quality: 'high',
    description: 'OpenAI\'s balanced model for good quality at lower cost'
  },
  {
    id: 'flux-dev',
    name: 'FLUX.1 Dev',
    provider: 'replicate',
    cost: 'medium',
    quality: 'ultra',
    description: 'High-quality FLUX model for professional results'
  },
  {
    id: 'flux-schnell',
    name: 'FLUX.1 Schnell',
    provider: 'replicate',
    cost: 'low',
    quality: 'high',
    description: 'Fast and cost-effective FLUX model with great results'
  }
];

interface APIKeyContextType {
  // Text API Key (for script analysis, generation, etc.)
  textApiKey: string;
  setTextApiKey: (key: string) => void;
  
  // Image API Key (for storyboard generation)
  imageApiKey: string;
  setImageApiKey: (key: string) => void;
  
  // Model Selection
  selectedImageModel: ImageModel;
  setSelectedImageModel: (model: ImageModel) => void;
  
  // Settings
  useSameKeyForImages: boolean;
  setUseSameKeyForImages: (same: boolean) => void;
  
  // Computed values
  effectiveImageApiKey: string;
  isConfigurationValid: boolean;
  
  // Loading state
  loading: boolean;
}

const APIKeyContext = createContext<APIKeyContextType | undefined>(undefined);

interface APIKeyProviderProps {
  children: ReactNode;
}

export const APIKeyProvider: React.FC<APIKeyProviderProps> = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const [textApiKey, setTextApiKeyState] = useState('');
  const [imageApiKey, setImageApiKeyState] = useState('');
  const [selectedImageModel, setSelectedImageModelState] = useState<ImageModel>(AVAILABLE_IMAGE_MODELS[0]);
  const [useSameKeyForImages, setUseSameKeyForImagesState] = useState(true);
  const [loading, setLoading] = useState(true);
  const [lastUserId, setLastUserId] = useState<string | null>(null);

  // Load user-specific data when user changes or on mount
  useEffect(() => {
    if (authLoading) return; // Wait for auth to be ready

    const currentUserId = user?.id || null;
    
    // If user changed, clear previous data and load new data
    if (lastUserId !== currentUserId) {
      console.log('APIKeyContext: User changed, loading user-specific data', { 
        from: lastUserId, 
        to: currentUserId 
      });
      
      // Migrate global keys to user-specific keys if this is a new user
      if (currentUserId) {
        storageService.migrateGlobalKeysToUser(currentUserId);
      }
      
      // Load user-specific data
      const savedTextKey = storageService.getAPIKey('openai', currentUserId);
      const savedImageKey = storageService.getAPIKey('openai-image', currentUserId);
      const savedUseSameKey = storageService.getUserSetting('use-same-key-for-images', currentUserId) !== 'false';
      const savedModelId = storageService.getUserSetting('selected-image-model', currentUserId);
      
      setTextApiKeyState(savedTextKey);
      setImageApiKeyState(savedImageKey);
      setUseSameKeyForImagesState(savedUseSameKey);
      
      if (savedModelId) {
        const model = AVAILABLE_IMAGE_MODELS.find(m => m.id === savedModelId);
        if (model) {
          setSelectedImageModelState(model);
        }
      } else {
        setSelectedImageModelState(AVAILABLE_IMAGE_MODELS[0]);
      }
      
      setLastUserId(currentUserId);
    }
    
    setLoading(false);
  }, [user, authLoading, lastUserId]);

  // Save methods that use user-aware storage
  const setTextApiKey = (key: string) => {
    setTextApiKeyState(key);
    if (key.trim()) {
      storageService.setAPIKey('openai', key, user?.id || null);
    }
  };

  const setImageApiKey = (key: string) => {
    setImageApiKeyState(key);
    if (key.trim()) {
      storageService.setAPIKey('openai-image', key, user?.id || null);
    }
  };

  const setSelectedImageModel = (model: ImageModel) => {
    setSelectedImageModelState(model);
    storageService.setUserSetting('selected-image-model', model.id, user?.id || null);
  };

  const setUseSameKeyForImages = (same: boolean) => {
    setUseSameKeyForImagesState(same);
    storageService.setUserSetting('use-same-key-for-images', same.toString(), user?.id || null);
  };

  // Computed values
  const effectiveImageApiKey = useSameKeyForImages ? textApiKey : imageApiKey;
  const isConfigurationValid = textApiKey.trim().length > 0 && effectiveImageApiKey.trim().length > 0;

  const contextValue: APIKeyContextType = {
    textApiKey,
    setTextApiKey,
    imageApiKey,
    setImageApiKey,
    selectedImageModel,
    setSelectedImageModel,
    useSameKeyForImages,
    setUseSameKeyForImages,
    effectiveImageApiKey,
    isConfigurationValid,
    loading: loading || authLoading
  };

  return (
    <APIKeyContext.Provider value={contextValue}>
      {children}
    </APIKeyContext.Provider>
  );
};

export const useAPIKeys = (): APIKeyContextType => {
  const context = useContext(APIKeyContext);
  if (!context) {
    throw new Error('useAPIKeys must be used within an APIKeyProvider');
  }
  return context;
};
