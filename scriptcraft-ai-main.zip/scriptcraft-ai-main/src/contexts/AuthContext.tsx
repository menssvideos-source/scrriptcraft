
import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { storageService } from '../services/StorageService';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: any }>;
  signInWithGoogle: () => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  
  // FIXED: Use ref to track previous user ID to prevent dependency loop
  const prevUserIdRef = useRef<string | null>(null);

  useEffect(() => {
    // Set up auth state listener - NO dependencies that cause loops
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('AuthContext: Auth state changed:', event, !!session?.user);
        
        const currentUserId = session?.user?.id || null;
        const previousUserId = prevUserIdRef.current;
        
        // Handle user logout/session end
        if (event === 'SIGNED_OUT' || !session) {
          if (previousUserId) {
            console.log('AuthContext: Clearing user data for logged out user:', previousUserId);
            storageService.clearUserData(previousUserId);
          }
          
          // Also clear any guest data that might have accumulated
          storageService.clearGuestData();
        }
        
        // Update state
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
        
        // Update ref with current user ID
        prevUserIdRef.current = currentUserId;
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
      
      // Initialize ref with current user ID
      prevUserIdRef.current = session?.user?.id || null;
    });

    return () => subscription.unsubscribe();
  }, []); // FIXED: Empty dependency array to prevent loops

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          full_name: fullName,
        },
      },
    });
    return { error };
  };

  // NEW: Google OAuth sign-in
  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/dashboard`,
      },
    });
    return { error };
  };

  const signOut = async () => {
    const currentUserId = user?.id;
    
    // Clear user data before signing out
    if (currentUserId) {
      console.log('AuthContext: Clearing user data before logout for user:', currentUserId);
      storageService.clearUserData(currentUserId);
    }
    
    await supabase.auth.signOut();
  };

  const value = {
    user,
    session,
    loading,
    signIn,
    signUp,
    signInWithGoogle,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
