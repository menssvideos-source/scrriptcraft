
import React, { createContext, useContext, useState, useCallback } from 'react';
import { StoryboardFrame } from '../lib/storyboard';

export interface GenerationProgress {
  currentStep: 'analyzing' | 'generating' | 'completed' | 'cancelled' | 'error';
  currentScene: number;
  totalScenes: number;
  message: string;
  frames: StoryboardFrame[];
  errors: { [frameId: string]: string };
  isGenerating: boolean;
  canResume: boolean;
}

interface StoryboardGenerationContextType {
  progress: GenerationProgress;
  startGeneration: (totalScenes: number) => void;
  updateProgress: (update: Partial<GenerationProgress>) => void;
  cancelGeneration: () => void;
  resumeGeneration: () => void;
  clearGeneration: () => void;
  isGenerating: boolean;
  abortController: AbortController | null;
}

const StoryboardGenerationContext = createContext<StoryboardGenerationContextType | undefined>(undefined);

export const useStoryboardGeneration = () => {
  const context = useContext(StoryboardGenerationContext);
  if (!context) {
    throw new Error('useStoryboardGeneration must be used within StoryboardGenerationProvider');
  }
  return context;
};

export const StoryboardGenerationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [progress, setProgress] = useState<GenerationProgress>({
    currentStep: 'analyzing',
    currentScene: 0,
    totalScenes: 0,
    message: 'Ready to generate',
    frames: [],
    errors: {},
    isGenerating: false,
    canResume: false
  });

  const [abortController, setAbortController] = useState<AbortController | null>(null);

  const startGeneration = useCallback((totalScenes: number) => {
    const controller = new AbortController();
    setAbortController(controller);
    setProgress({
      currentStep: 'analyzing',
      currentScene: 0,
      totalScenes,
      message: `Analyzing scenes... (0/${totalScenes})`,
      frames: [],
      errors: {},
      isGenerating: true,
      canResume: false
    });
  }, []);

  const updateProgress = useCallback((update: Partial<GenerationProgress>) => {
    setProgress(prev => ({ ...prev, ...update }));
  }, []);

  const cancelGeneration = useCallback(() => {
    if (abortController) {
      abortController.abort();
    }
    setProgress(prev => ({
      ...prev,
      currentStep: 'cancelled',
      message: 'Generation cancelled',
      isGenerating: false,
      canResume: prev.currentScene > 0
    }));
    setAbortController(null);
  }, [abortController]);

  const resumeGeneration = useCallback(() => {
    const controller = new AbortController();
    setAbortController(controller);
    setProgress(prev => ({
      ...prev,
      currentStep: 'generating',
      isGenerating: true,
      canResume: false
    }));
  }, []);

  const clearGeneration = useCallback(() => {
    if (abortController) {
      abortController.abort();
    }
    setProgress({
      currentStep: 'analyzing',
      currentScene: 0,
      totalScenes: 0,
      message: 'Ready to generate',
      frames: [],
      errors: {},
      isGenerating: false,
      canResume: false
    });
    setAbortController(null);
  }, [abortController]);

  return (
    <StoryboardGenerationContext.Provider
      value={{
        progress,
        startGeneration,
        updateProgress,
        cancelGeneration,
        resumeGeneration,
        clearGeneration,
        isGenerating: progress.isGenerating,
        abortController
      }}
    >
      {children}
    </StoryboardGenerationContext.Provider>
  );
};
