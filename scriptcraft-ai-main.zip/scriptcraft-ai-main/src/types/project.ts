
export interface Character {
  id: string;
  name: string;
  age?: number;
  gender?: string;
  description: string;
  physicalDescription?: string;
  role: 'protagonist' | 'antagonist' | 'supporting' | 'minor';
  backstory?: string;
  motivation?: string;
  arc?: string;
  voiceSample?: string;
  relationships?: { characterId: string; relationship: string }[];
}

export interface PlotPoint {
  id: string;
  act: 1 | 2 | 3;
  title: string;
  description: string;
  page?: number;
  type: 'inciting-incident' | 'plot-point-1' | 'midpoint' | 'plot-point-2' | 'climax' | 'resolution' | 'custom';
}

export interface ProjectStructure {
  id?: string;
  premise?: string;
  logline?: string;
  theme?: string;
  genre?: string;
  targetAudience?: string;
  act1: {
    setup: string;
    incitingIncident: string;
    plotPoint1: string;
    description?: string; // FIXED: Added optional description property
  };
  act2: {
    confrontation: string;
    midpoint: string;
    plotPoint2: string;
    description?: string; // FIXED: Added optional description property
  };
  act3: {
    climax: string;
    resolution: string;
    description?: string; // FIXED: Added optional description property
  };
  plotPoints?: PlotPoint[];
}

export interface ProjectBrainstorm {
  idea: string;
  genre: string;
  theme: string;
  setting: string;
  timeframe: string;
  tone: string;
  logline: string;
  premise: string;
  targetAudience: string;
  inspirations: string[];
  keywords: string[];
  // FIXED: Added missing properties that ScriptSidebar expects
  storyIdea?: string;
  mainCharacters?: string[];
}

export interface Project {
  id: string;
  title: string;
  type: 'feature-film' | 'tv-episode' | 'short-film';
  currentPhase: 'brainstorm' | 'structure' | 'characters' | 'writing';
  brainstorm?: ProjectBrainstorm;
  structure?: ProjectStructure;
  characters: Character[];
  content: string;
  createdAt: Date;
  lastModified: Date;
  wordCount: number;
  pageCount: number;
}

export interface AIContext {
  conversationHistory: { role: 'user' | 'assistant'; content: string }[];
  currentProject: Project;
  apiKey: string;
}
