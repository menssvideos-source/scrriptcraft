export interface Script {
  id: string;
  title: string;
  description?: string;
  template: 'feature-film' | 'tv-episode' | 'short-film';
  createdAt: Date;
  lastModified: Date;
  wordCount: number;
  pageCount: number;
  sceneCount: number; // Add scene count
  thumbnail?: string;
  isStarred?: boolean;
}

export interface ScriptTemplate {
  id: string;
  name: string;
  description: string;
  template: 'feature-film' | 'tv-episode' | 'short-film';
  icon: string;
  defaultTitle: string;
}

export interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export interface ScriptOperationResult {
  success: boolean;
  error?: string;
  data?: any;
}

export interface UndoRedoState {
  elements: ScriptElement[];
  description: string;
  timestamp: number;
}
