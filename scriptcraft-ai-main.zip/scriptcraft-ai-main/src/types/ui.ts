
export interface LoadingState {
  isLoading: boolean;
  message?: string;
  error?: string | null;
}

export interface UIState {
  activeElement: string;
  showProjectInfo: boolean;
  showSceneGenerator: boolean;
  isGenerating: boolean;
  selectedSceneType: string;
}

export interface ScriptEditorState extends UIState {
  hasMultipleScenes: boolean;
}

export interface ActionHandlers {
  handleAddNewElement: () => void;
  handleInsertCharacterName: (name: string) => void;
  generateFirstScene: () => void;
  generateNextScene: () => void;
}

export interface ScriptEditorActions extends ActionHandlers {
  setActiveElement: (id: string) => void;
  setShowProjectInfo: (show: boolean) => void;
  setShowSceneGenerator: (show: boolean) => void;
  setSelectedSceneType: (type: string) => void;
}
