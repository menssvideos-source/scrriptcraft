
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Grid, List } from 'lucide-react';
import { useIsMobile } from '../hooks/use-mobile';

interface ScriptSearchProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
  filterBy: string;
  onFilterChange: (filter: string) => void;
  viewMode: 'grid' | 'list';
  onViewModeChange: (mode: 'grid' | 'list') => void;
}

const ScriptSearch: React.FC<ScriptSearchProps> = ({
  searchQuery,
  onSearchChange,
  sortBy,
  onSortChange,
  filterBy,
  onFilterChange,
  viewMode,
  onViewModeChange
}) => {
  const { t, isRTL } = useLanguage();
  const isMobile = useIsMobile();

  return (
    <div className={`space-y-4 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      {/* Search Bar */}
      <div className="relative">
        <Search className={`absolute top-1/2 transform -translate-y-1/2 ${isRTL ? 'right-3' : 'left-3'} h-4 w-4 text-script-slate-400`} />
        <Input
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t('searchScriptsPlaceholder')}
          className={`${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} h-12 text-base`}
        />
      </div>

      {/* Filters and Controls */}
      <div className={`flex flex-col sm:flex-row sm:items-center gap-4 ${isRTL ? 'space-x-reverse' : ''}`}>
        {/* Sort and Filter Row */}
        <div className="flex flex-col sm:flex-row gap-4 flex-1">
          {/* Sort By */}
          <div className="flex items-center space-x-2 min-w-0">
            <label className="text-sm font-medium text-script-slate-700 whitespace-nowrap">{t('sortBy')}:</label>
            <Select value={sortBy} onValueChange={onSortChange}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lastModified">{t('lastModifiedSort')}</SelectItem>
                <SelectItem value="title">{t('title')}</SelectItem>
                <SelectItem value="created">{t('dateCreated')}</SelectItem>
                <SelectItem value="wordCount">{t('wordCount')}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filter By Template */}
          <div className="flex items-center space-x-2 min-w-0">
            <label className="text-sm font-medium text-script-slate-700 whitespace-nowrap">{t('filter')}:</label>
            <Select value={filterBy} onValueChange={onFilterChange}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allScripts')}</SelectItem>
                <SelectItem value="feature-film">{t('featureFilms')}</SelectItem>
                <SelectItem value="tv-episode">{t('tvEpisodes')}</SelectItem>
                <SelectItem value="short-film">{t('shortFilms')}</SelectItem>
                <SelectItem value="starred">{t('starred')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center space-x-1 justify-center sm:justify-end">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('grid')}
            className="min-w-[44px]"
          >
            <Grid className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('list')}
            className="min-w-[44px]"
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ScriptSearch;
