
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { 
  BookOpen,
  ChevronRight
} from 'lucide-react';
import { ProjectStructure } from '../../types/project';

interface StructureProgressProps {
  structure: ProjectStructure | null;
  currentAct: 1 | 2 | 3;
  actProgress: number;
  totalScenes: number;
}

const StructureProgress: React.FC<StructureProgressProps> = ({
  structure,
  currentAct,
  actProgress,
  totalScenes
}) => {
  const { t, isRTL } = useLanguage();

  if (!structure) {
    return (
      <div className="p-4 text-center text-script-slate-500">
        <BookOpen className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No structure defined</p>
        <p className="text-xs">Plan your story structure first</p>
      </div>
    );
  }

  const acts = [
    {
      number: 1,
      title: 'Setup',
      description: structure.act1?.setup || 'Character introduction and world building',
      expectedPercentage: 25
    },
    {
      number: 2,
      title: 'Confrontation',
      description: structure.act2?.confrontation || 'Rising action and obstacles',
      expectedPercentage: 50
    },
    {
      number: 3,
      title: 'Resolution',
      description: structure.act3?.climax || 'Climax and conclusion',
      expectedPercentage: 25
    }
  ];

  const getActStatus = (actNumber: number) => {
    if (actNumber < currentAct) return 'completed';
    if (actNumber === currentAct) return 'current';
    return 'upcoming';
  };

  const getActColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'current': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-4 py-2 border-b border-script-slate-200">
        <h3 className="font-semibold text-script-slate-900">Story Structure</h3>
        <Badge variant="secondary" className="text-xs">
          Act {currentAct}
        </Badge>
      </div>
      
      <div className="px-4">
        <div className="text-xs text-script-slate-600 mb-2">
          Overall Progress • {totalScenes} scenes written
        </div>
        <Progress value={(totalScenes / 30) * 100} className="h-2" />
        <div className="text-xs text-script-slate-500 mt-1">
          Target: ~30 scenes for feature script
        </div>
      </div>

      <div className="space-y-2 px-2">
        {acts.map((act, index) => {
          const status = getActStatus(act.number);
          const isCurrent = status === 'current';
          
          return (
            <div key={act.number} className={`border rounded-lg p-3 transition-colors ${getActColor(status)}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs font-mono">
                    Act {act.number}
                  </Badge>
                  <span className="font-medium text-sm">{act.title}</span>
                </div>
                {isCurrent && (
                  <Badge variant="secondary" className="text-xs">
                    Current
                  </Badge>
                )}
              </div>
              
              <p className="text-xs text-script-slate-600 mb-2 line-clamp-2">
                {act.description}
              </p>
              
              {isCurrent && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Act Progress</span>
                    <span>{Math.round(actProgress)}%</span>
                  </div>
                  <Progress value={actProgress} className="h-1" />
                </div>
              )}
              
              <div className="text-xs text-script-slate-500 mt-2">
                Expected: {act.expectedPercentage}% of script
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StructureProgress;
