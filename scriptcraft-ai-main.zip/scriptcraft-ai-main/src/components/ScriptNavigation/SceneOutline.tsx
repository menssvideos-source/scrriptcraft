
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  FileText,
  ChevronRight,
  MapPin,
  Clock,
  Play,
  Zap,
  Users,
  Swords,
  Eye,
  Crown,
  CheckCircle
} from 'lucide-react';
import { SceneAnalyzer } from '../../lib/sceneAnalyzer';
import { ScriptElement } from '../../types/script';

interface SceneOutlineProps {
  elements: ScriptElement[];
  currentSceneIndex: number;
  onSceneClick: (elementIndex: number) => void;
}

const SceneOutline: React.FC<SceneOutlineProps> = ({
  elements,
  currentSceneIndex,
  onSceneClick
}) => {
  const { t, isRTL } = useLanguage();

  const scenes = React.useMemo(() => {
    console.log('SceneOutline: Analyzing scenes with unified SceneAnalyzer');
    return SceneAnalyzer.analyzeScenes(elements);
  }, [elements]);

  const getSceneTypeIcon = (type: string) => {
    const iconMap = {
      opening: Play,
      inciting: Zap,
      character: Users,
      conflict: Swords,
      revelation: Eye,
      climax: Crown,
      resolution: CheckCircle,
      general: FileText
    };
    
    return iconMap[type as keyof typeof iconMap] || FileText;
  };

  const getSceneTypeColor = (type: string) => {
    const colorMap = {
      opening: 'bg-green-100 text-green-800',
      inciting: 'bg-yellow-100 text-yellow-800',
      character: 'bg-blue-100 text-blue-800',
      conflict: 'bg-red-100 text-red-800',
      revelation: 'bg-purple-100 text-purple-800',
      climax: 'bg-orange-100 text-orange-800',
      resolution: 'bg-teal-100 text-teal-800',
      general: 'bg-gray-100 text-gray-800'
    };
    
    return colorMap[type as keyof typeof colorMap] || colorMap.general;
  };

  if (scenes.length === 0) {
    return (
      <div className="p-4 text-center text-script-slate-500 animate-fade-in">
        <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No scenes yet</p>
        <p className="text-xs">Start writing to see scene outline</p>
      </div>
    );
  }

  return (
    <div className="space-y-2 animate-fade-in">
      <div className="flex items-center justify-between px-4 py-2 border-b border-script-slate-200">
        <h3 className="font-semibold text-script-slate-900">Scene Outline</h3>
        <Badge variant="secondary" className="text-xs">
          {scenes.length} {scenes.length === 1 ? 'Scene' : 'Scenes'}
        </Badge>
      </div>
      
      <div className="max-h-96 overflow-y-auto custom-scrollbar">
        {scenes.map((scene, index) => {
          const SceneIcon = getSceneTypeIcon(scene.type);
          const isCurrentScene = index === currentSceneIndex;
          const uniqueKey = `scene-${scene.number}-${scene.elementIndex}`;
          
          return (
            <Button
              key={uniqueKey}
              variant={isCurrentScene ? "secondary" : "ghost"}
              className={`w-full justify-start text-left p-3 h-auto transition-all duration-200 hover:scale-[1.02] ${isRTL ? 'flex-row-reverse' : ''} ${
                isCurrentScene ? 'bg-script-blue-50 border-script-blue-200' : ''
              }`}
              onClick={() => onSceneClick(scene.elementIndex)}
            >
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <div className="flex-shrink-0 flex items-center gap-2">
                  <Badge variant="outline" className="text-xs font-mono">
                    {scene.number}
                  </Badge>
                  <Badge className={`text-xs transition-colors ${getSceneTypeColor(scene.type)}`}>
                    <SceneIcon className="h-3 w-3 mr-1" />
                    {scene.type}
                  </Badge>
                </div>
                
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1 text-xs text-script-slate-600 mb-1">
                    <MapPin className="h-3 w-3" />
                    <span className="truncate">{scene.location}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-script-slate-500">
                    <Clock className="h-3 w-3" />
                    <span className="truncate">{scene.timeOfDay}</span>
                  </div>
                </div>
                
                <ChevronRight className={`h-4 w-4 text-script-slate-400 transition-transform ${isRTL ? 'rotate-180' : ''}`} />
              </div>
            </Button>
          );
        })}
      </div>
      
      {/* Scene type legend */}
      <div className="px-4 py-2 border-t border-script-slate-200">
        <p className="text-xs text-script-slate-500 mb-2">Scene Types:</p>
        <div className="grid grid-cols-2 gap-1 text-xs">
          <div className="flex items-center gap-1">
            <Play className="h-3 w-3 text-green-600" />
            <span>Opening</span>
          </div>
          <div className="flex items-center gap-1">
            <Zap className="h-3 w-3 text-yellow-600" />
            <span>Inciting</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3 text-blue-600" />
            <span>Character</span>
          </div>
          <div className="flex items-center gap-1">
            <Swords className="h-3 w-3 text-red-600" />
            <span>Conflict</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SceneOutline;
