
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { 
  Users,
  Quote,
  Target,
  TrendingUp
} from 'lucide-react';
import { Character } from '../../types/project';

interface CharacterReferenceProps {
  characters: Character[];
  onCharacterInsert: (name: string) => void;
}

const CharacterReference: React.FC<CharacterReferenceProps> = ({
  characters,
  onCharacterInsert
}) => {
  const { t, isRTL } = useLanguage();

  if (characters.length === 0) {
    return (
      <div className="p-4 text-center text-script-slate-500">
        <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No characters yet</p>
        <p className="text-xs">Develop characters first</p>
      </div>
    );
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'protagonist': return 'bg-green-100 text-green-800';
      case 'antagonist': return 'bg-red-100 text-red-800';
      case 'supporting': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-4 py-2 border-b border-script-slate-200">
        <h3 className="font-semibold text-script-slate-900">Characters</h3>
        <Badge variant="secondary" className="text-xs">
          {characters.length}
        </Badge>
      </div>
      
      <div className="max-h-96 overflow-y-auto custom-scrollbar space-y-1 px-2">
        {characters.map((character) => (
          <div key={character.id} className="border border-script-slate-200 rounded-lg p-3">
            <div className="flex items-start gap-3 mb-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="text-xs">
                  {character.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto p-0 font-semibold text-script-slate-900 hover:text-script-blue-600"
                    onClick={() => onCharacterInsert(character.name.toUpperCase())}
                  >
                    {character.name}
                  </Button>
                  <Badge className={`text-xs ${getRoleColor(character.role)}`}>
                    {character.role}
                  </Badge>
                </div>
                
                <p className="text-xs text-script-slate-600 line-clamp-2 mb-2">
                  {character.description}
                </p>
                
                {character.motivation && (
                  <div className="flex items-start gap-1 text-xs text-script-slate-500 mb-1">
                    <Target className="h-3 w-3 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-1">{character.motivation}</span>
                  </div>
                )}
                
                {character.arc && (
                  <div className="flex items-start gap-1 text-xs text-script-slate-500">
                    <TrendingUp className="h-3 w-3 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-1">{character.arc}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CharacterReference;
