
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { 
  FileText, 
  Users, 
  BarChart3,
  Download,
  Save,
  Lightbulb,
  Building,
  UserCheck,
  CheckCircle,
  Circle
} from 'lucide-react';
import SceneOutline from './ScriptNavigation/SceneOutline';
import CharacterReference from './ScriptNavigation/CharacterReference';
import StructureProgress from './ScriptNavigation/StructureProgress';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

interface ScriptSidebarProps {
  scriptId: string;
  elements: ScriptElement[];
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  currentSceneIndex: number;
  currentAct: 1 | 2 | 3;
  actProgress: number;
  onSceneJump: (elementIndex: number) => void;
  onCharacterInsert: (name: string) => void;
  onSaveScript: () => void;
  onDownloadScript: () => void;
  saving: boolean;
}

const ScriptSidebar: React.FC<ScriptSidebarProps> = ({
  scriptId,
  elements,
  brainstorm,
  structure,
  characters,
  currentSceneIndex,
  currentAct,
  actProgress,
  onSceneJump,
  onCharacterInsert,
  onSaveScript,
  onDownloadScript,
  saving
}) => {
  const { t, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('scenes');
  const navigate = useNavigate();

  const totalScenes = elements.filter(el => 
    el.type === 'scene-heading' && 
    el.content.trim() && 
    !el.content.includes('FADE')
  ).length;

  const workflowPhases = [
    {
      id: 'brainstorm',
      title: 'Story Foundation',
      description: 'Core idea, genre, characters',
      icon: Lightbulb,
      route: `/script/${scriptId}/brainstorm`,
      // FIXED: Use correct property names from ProjectBrainstorm type
      completed: !!(brainstorm?.idea && brainstorm?.genre && brainstorm?.logline)
    },
    {
      id: 'structure',
      title: 'Story Structure',
      description: 'Three-act breakdown, plot points',
      icon: Building,
      route: `/script/${scriptId}/structure-planning`,
      // FIXED: Use correct property names and handle optional description
      completed: !!(structure?.act1?.setup && structure?.act2?.confrontation && structure?.act3?.climax)
    },
    {
      id: 'characters',
      title: 'Character Development',
      description: 'Detailed character profiles',
      icon: UserCheck,
      route: `/script/${scriptId}/character-development`,
      completed: characters && characters.length > 0
    }
  ];

  return (
    <aside className={`w-full h-full bg-script-slate-50 border-r border-script-slate-200 ${isRTL ? 'font-arabic border-l border-r-0' : 'font-script'} flex flex-col`}>
      {/* Header with quick actions */}
      <div className="p-4 border-b border-script-slate-200 bg-white">
        <div className="space-y-3">
          <Button 
            onClick={onSaveScript}
            disabled={saving}
            className="w-full bg-script-blue-600 hover:bg-script-blue-700 text-white"
            size="sm"
          >
            <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {saving ? 'Saving...' : 'Save Script'}
          </Button>
          
          <Button 
            onClick={onDownloadScript}
            variant="outline" 
            className="w-full"
            size="sm"
          >
            <Download className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            Download PDF
          </Button>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="flex-1 min-h-0">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-4 m-2">
            <TabsTrigger value="scenes" className="text-xs">
              <FileText className="h-4 w-4 mr-1" />
              Scenes
            </TabsTrigger>
            <TabsTrigger value="characters" className="text-xs">
              <Users className="h-4 w-4 mr-1" />
              Cast
            </TabsTrigger>
            <TabsTrigger value="structure" className="text-xs">
              <BarChart3 className="h-4 w-4 mr-1" />
              Structure
            </TabsTrigger>
            <TabsTrigger value="workflow" className="text-xs">
              <Lightbulb className="h-4 w-4 mr-1" />
              Workflow
            </TabsTrigger>
          </TabsList>
          
          <div className="flex-1 min-h-0">
            <TabsContent value="scenes" className="h-full m-0">
              <ScrollArea className="h-full">
                <SceneOutline
                  elements={elements}
                  currentSceneIndex={currentSceneIndex}
                  onSceneClick={onSceneJump}
                />
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="characters" className="h-full m-0">
              <ScrollArea className="h-full">
                <CharacterReference
                  characters={characters}
                  onCharacterInsert={onCharacterInsert}
                />
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="structure" className="h-full m-0">
              <ScrollArea className="h-full">
                <StructureProgress
                  structure={structure}
                  currentAct={currentAct}
                  actProgress={actProgress}
                  totalScenes={totalScenes}
                />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="workflow" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="p-4 space-y-4">
                  <div className="text-center mb-6">
                    <h3 className="font-semibold text-script-slate-900 mb-2">Story Development</h3>
                    <p className="text-sm text-script-slate-600">Access and refine your story foundation anytime</p>
                  </div>
                  
                  {workflowPhases.map((phase) => {
                    const IconComponent = phase.icon;
                    const CompletionIcon = phase.completed ? CheckCircle : Circle;
                    
                    return (
                      <div key={phase.id} className="bg-white rounded-lg border border-script-slate-200 p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex-shrink-0">
                            <div className="w-10 h-10 bg-script-blue-100 rounded-full flex items-center justify-center">
                              <IconComponent className="h-5 w-5 text-script-blue-600" />
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="text-sm font-medium text-script-slate-900">{phase.title}</h4>
                              <CompletionIcon className={`h-4 w-4 ${phase.completed ? 'text-green-500' : 'text-script-slate-400'}`} />
                            </div>
                            <p className="text-xs text-script-slate-600 mb-3">{phase.description}</p>
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full text-xs"
                              onClick={() => navigate(phase.route)}
                            >
                              {phase.completed ? 'Edit & Refine' : 'Complete Setup'}
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </aside>
  );
};

export default ScriptSidebar;
