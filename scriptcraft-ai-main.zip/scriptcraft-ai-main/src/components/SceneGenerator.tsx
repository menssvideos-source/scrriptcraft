
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Wand2, Sparkles } from 'lucide-react';

const SCENE_TYPES = [
  { value: 'opening', label: 'Opening Scene', description: 'Introduce character in ordinary world' },
  { value: 'inciting', label: 'Inciting Incident', description: 'Event that disrupts normal life' },
  { value: 'character', label: 'Character Moment', description: 'Scene focusing on character development' },
  { value: 'conflict', label: 'Conflict Scene', description: 'Character faces obstacles' },
  { value: 'revelation', label: 'Revelation', description: 'Important information revealed' },
  { value: 'climax', label: 'Climactic Scene', description: 'Major confrontation or turning point' },
  { value: 'resolution', label: 'Resolution', description: 'Wrapping up story threads' }
];

interface SceneGeneratorProps {
  showSceneGenerator: boolean;
  selectedSceneType: string;
  setSelectedSceneType: (type: string) => void;
  isGenerating: boolean;
  generateNextScene: () => void;
  setShowSceneGenerator: (show: boolean) => void;
}

const SceneGenerator: React.FC<SceneGeneratorProps> = ({
  showSceneGenerator,
  selectedSceneType,
  setSelectedSceneType,
  isGenerating,
  generateNextScene,
  setShowSceneGenerator
}) => {
  const { isRTL } = useLanguage();

  if (!showSceneGenerator) return null;

  return (
    <div className="mt-4 p-4 bg-script-slate-50 rounded-lg border border-script-slate-200">
      <h3 className="font-semibold mb-3 flex items-center">
        <Sparkles className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
        Generate Next Scene
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">Scene Type</label>
          <Select value={selectedSceneType} onValueChange={setSelectedSceneType}>
            <SelectTrigger>
              <SelectValue placeholder="Choose scene type or leave blank for auto" />
            </SelectTrigger>
            <SelectContent>
              {SCENE_TYPES.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  <div>
                    <div className="font-medium">{type.label}</div>
                    <div className="text-xs text-script-slate-500">{type.description}</div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-end space-x-2">
          <Button
            onClick={generateNextScene}
            disabled={isGenerating}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            <Wand2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {isGenerating ? 'Generating...' : 'Generate Scene'}
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowSceneGenerator(false)}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SceneGenerator;
