
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Edit } from 'lucide-react';
import { useScript } from '../hooks/useScript';
import { useParams } from 'react-router-dom';
import { useAPIKeys } from '../contexts/APIKeyContext';
import { useStoryboardOperations } from '../hooks/useStoryboardOperations';
import { useAnalysisOperations } from '../hooks/useAnalysisOperations';
import EnhancedAPIKeyInput from './AIPanel/EnhancedAPIKeyInput';
import AnalysisPanel from './AIPanel/AnalysisPanel';
import StoryboardPanel from './AIPanel/StoryboardPanel';
import QuickActionsPanel from './AIPanel/QuickActionsPanel';

const AIPanel: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { id } = useParams();
  const { elements } = useScript(id || '');
  
  // Use the enhanced API key context
  const { textApiKey, effectiveImageApiKey, selectedImageModel } = useAPIKeys();
  const { analyzing, handleAnalyze } = useAnalysisOperations(textApiKey);
  
  // Use the simplified storyboard operations hook
  const {
    generatingStoryboard,
    loadingImages,
    generateCompleteStoryboard
  } = useStoryboardOperations(effectiveImageApiKey, elements || [], selectedImageModel);

  return (
    <div className={`w-80 bg-script-slate-50 border-l border-script-slate-200 ${isRTL ? 'font-arabic border-r border-l-0' : 'font-script'}`}>
      <div className="p-4">
        <div className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''} mb-4`}>
          <Edit className="h-5 w-5 text-script-blue-500" />
          <h3 className="font-semibold text-script-slate-900">{t('aiTools')}</h3>
          <Badge variant="secondary" className="text-xs">Beta</Badge>
        </div>

        <EnhancedAPIKeyInput />

        <Tabs defaultValue="analysis" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="analysis" className="text-xs">Analysis</TabsTrigger>
            <TabsTrigger value="storyboard" className="text-xs">Storyboard</TabsTrigger>
          </TabsList>

          <TabsContent value="analysis" className="space-y-4">
            <AnalysisPanel 
              apiKey={textApiKey}
              analyzing={analyzing}
              onAnalyze={handleAnalyze}
            />
          </TabsContent>

          <TabsContent value="storyboard" className="space-y-4">
            <StoryboardPanel
              apiKey={effectiveImageApiKey}
              imageModel={selectedImageModel}
              generatingStoryboard={generatingStoryboard}
              loadingImages={loadingImages}
              onGenerateCompleteStoryboard={generateCompleteStoryboard}
            />
          </TabsContent>
        </Tabs>

        <QuickActionsPanel apiKey={textApiKey} />
      </div>
    </div>
  );
};

export default AIPanel;
