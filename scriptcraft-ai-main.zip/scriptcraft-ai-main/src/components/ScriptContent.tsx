
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { supabase } from '../integrations/supabase/client';
import ScriptTitleEditor from './ScriptEditor/ScriptTitleEditor';
import ScriptMetadata from './ScriptEditor/ScriptMetadata';
import ScriptElementsList from './ScriptEditor/ScriptElementsList';
import { ProjectBrainstorm } from '../types/project';
import { ScriptElement } from '../types/script';

interface ScriptContentProps {
  brainstorm: ProjectBrainstorm | null;
  elements: ScriptElement[];
  setElements: (elements: ScriptElement[]) => void;
  activeElement: string;
  setActiveElement: (id: string) => void;
  addNewElement: () => void;
  saveScript: (elements: ScriptElement[]) => Promise<void>;
  script?: any;
  scriptTitle: string;
  setScriptTitle: (title: string) => void;
  onTitleSave: (title: string) => Promise<void>;
  isSavingTitle: boolean;
  titleSaved: boolean;
}

const ScriptContent: React.FC<ScriptContentProps> = ({
  brainstorm,
  elements,
  setElements,
  activeElement,
  setActiveElement,
  addNewElement,
  saveScript,
  script,
  scriptTitle,
  setScriptTitle,
  onTitleSave,
  isSavingTitle,
  titleSaved
}) => {
  const { isRTL } = useLanguage();
  const [userProfile, setUserProfile] = React.useState<any>(null);

  // Fetch user profile for author name
  React.useEffect(() => {
    const fetchUserProfile = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .single();
        
        setUserProfile(profile);
      }
    };
    
    fetchUserProfile();
  }, []);

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto p-4 sm:p-8">
        {/* Editable Title Section */}
        <div className="text-center mb-8 sm:mb-12 pb-6 sm:pb-8 border-b border-script-slate-200">
          <ScriptTitleEditor
            scriptTitle={scriptTitle}
            setScriptTitle={setScriptTitle}
            onTitleSave={onTitleSave}
            isSavingTitle={isSavingTitle}
            titleSaved={titleSaved}
            script={script}
          />
          
          <ScriptMetadata userProfile={userProfile} />
        </div>

        {/* Script Elements */}
        <ScriptElementsList
          elements={elements}
          setElements={setElements}
          activeElement={activeElement}
          setActiveElement={setActiveElement}
          addNewElement={addNewElement}
          saveScript={saveScript}
        />
      </div>
    </div>
  );
};

export default ScriptContent;
