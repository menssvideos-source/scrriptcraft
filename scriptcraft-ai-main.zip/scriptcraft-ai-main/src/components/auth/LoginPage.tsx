
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { GoogleLoginButton } from './GoogleLoginButton';
import { LoginForm } from './LoginForm';

interface LoginPageProps {
  isRTL: boolean;
  onEmailLogin: (email: string, password: string) => Promise<void>;
  onGoogleLogin: () => Promise<void>;
  isLoading: boolean;
  isGoogleLoading: boolean;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  isRTL,
  onEmailLogin,
  onGoogleLogin,
  isLoading,
  isGoogleLoading
}) => {
  return (
    <div className={`min-h-screen bg-gradient-to-br from-script-blue-50 to-script-slate-100 flex items-center justify-center p-4 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <div className="w-full max-w-md space-y-6">
        {/* Logo */}
        <div className="text-center">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-4">
            <span className="text-white font-bold text-xl">SA</span>
          </div>
          <h1 className="text-2xl font-bold text-script-slate-900">ScriptCraft AI</h1>
          <p className="text-script-slate-600 text-sm mt-1">AI-Powered Screenplay Writing</p>
        </div>

        {/* Login Form */}
        <Card className="shadow-xl border-0">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-xl">Welcome Back</CardTitle>
            <CardDescription>Sign in to your account to continue</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Google Login Button */}
            <div className="space-y-4 mb-6">
              <GoogleLoginButton
                onGoogleLogin={onGoogleLogin}
                disabled={isLoading || isGoogleLoading}
              />
              
              {/* Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-script-slate-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-script-slate-500">Or continue with email</span>
                </div>
              </div>
            </div>

            {/* Email Login Form */}
            <LoginForm
              onSubmit={onEmailLogin}
              isLoading={isLoading || isGoogleLoading}
              isRTL={isRTL}
            />

            {/* Sign Up Link */}
            <div className="mt-6 text-center text-sm">
              <span className="text-script-slate-600">Don't have an account? </span>
              <Link to="/signup" className="text-script-blue-600 hover:text-script-blue-700 font-medium">
                Sign up
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
