
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();

  console.log('ProtectedRoute: loading:', loading, 'user:', !!user);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-script-slate-50">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-8 h-8 border-2 border-script-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-script-slate-600">Checking authentication...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    console.log('ProtectedRoute: No user, redirecting to login');
    return <Navigate to="/login" replace />;
  }

  console.log('ProtectedRoute: User authenticated, rendering children');
  return <>{children}</>;
};

export default ProtectedRoute;
