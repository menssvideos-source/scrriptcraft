
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  LayoutDashboard, 
  FileText, 
  Settings,
  Book,
  BookOpen,
  Edit,
  Pen
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { 
      icon: LayoutDashboard, 
      label: t('dashboard'), 
      active: location.pathname === '/dashboard', 
      badge: null,
      path: '/dashboard'
    },
    { 
      icon: FileText, 
      label: t('myScripts'), 
      active: location.pathname === '/scripts', 
      badge: '12',
      path: '/scripts'
    },
    { 
      icon: Edit, 
      label: t('aiTools'), 
      active: false, 
      badge: 'New',
      path: '/ai-tools'
    },
    { 
      icon: Settings, 
      label: t('settings'), 
      active: false, 
      badge: null,
      path: '/settings'
    },
  ];

  return (
    <aside className={`w-full h-full bg-script-slate-50 border-r border-script-slate-200 ${isRTL ? 'font-arabic border-l border-r-0' : 'font-script'} overflow-y-auto custom-scrollbar`}>
      <div className="p-fluid-sm lg:p-fluid-md">
        {/* Quick Actions */}
        <div className="space-y-fluid-sm mb-fluid-md lg:mb-fluid-lg">
          <Button 
            className="w-full bg-gradient-to-r from-script-blue-500 to-script-blue-600 hover:from-script-blue-600 hover:to-script-blue-700 text-white shadow-lg text-fluid-sm lg:text-fluid-base"
            onClick={() => navigate('/new-script')}
          >
            <Pen className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            <span className="truncate">{t('createNewScript')}</span>
          </Button>
          <Button 
            variant="outline" 
            className="w-full text-fluid-sm lg:text-fluid-base"
            onClick={() => navigate('/scripts')}
          >
            <BookOpen className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            <span className="truncate">{t('openExisting')}</span>
          </Button>
        </div>

        {/* Navigation Menu */}
        <nav className="space-y-1 lg:space-y-2">
          {menuItems.map((item, index) => (
            <Button
              key={index}
              variant={item.active ? "secondary" : "ghost"}
              className={`w-full justify-start text-fluid-sm lg:text-fluid-base ${isRTL ? 'flex-row-reverse' : ''} ${
                item.active ? 'bg-script-blue-50 text-script-blue-700 border-script-blue-200' : ''
              }`}
              onClick={() => navigate(item.path)}
            >
              <item.icon className={`h-4 w-4 flex-shrink-0 ${isRTL ? 'ml-2 lg:ml-3' : 'mr-2 lg:mr-3'}`} />
              <span className="flex-1 text-left min-w-0 truncate">{item.label}</span>
              {item.badge && (
                <Badge 
                  variant={item.badge === 'New' ? 'default' : 'secondary'}
                  className={`${isRTL ? 'mr-2' : 'ml-2'} text-fluid-xs flex-shrink-0`}
                >
                  {item.badge}
                </Badge>
              )}
            </Button>
          ))}
        </nav>

        {/* Recent Projects */}
        <div className="mt-fluid-md lg:mt-fluid-lg">
          <h3 className={`text-fluid-sm font-semibold text-script-slate-600 mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t('recentProjects')}
          </h3>
          <div className="space-y-1 lg:space-y-2">
            {['The Last Stand', 'Desert Moon', 'City Lights'].map((project, index) => (
              <Button
                key={index}
                variant="ghost"
                className={`w-full justify-start text-fluid-xs lg:text-fluid-sm ${isRTL ? 'flex-row-reverse' : ''}`}
                onClick={() => navigate('/scripts')}
              >
                <Book className={`h-3 w-3 flex-shrink-0 ${isRTL ? 'ml-2' : 'mr-2'} text-script-slate-400`} />
                <span className="truncate min-w-0">{project}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
