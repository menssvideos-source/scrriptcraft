
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Settings } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface APIKeyInputProps {
  apiKey: string;
  onApiKeyChange: (key: string) => void;
}

const APIKeyInput: React.FC<APIKeyInputProps> = ({ apiKey, onApiKeyChange }) => {
  const { t, isRTL } = useLanguage();

  return (
    <Card className="mb-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center">
          <Settings className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          Privacy Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Input
          type="password"
          placeholder={t('apiKeyPlaceholder')}
          value={apiKey}
          onChange={(e) => onApiKeyChange(e.target.value)}
          className="text-sm"
        />
        <p className="text-xs text-script-slate-500">
          Your API key is never stored and only used for your requests
        </p>
      </CardContent>
    </Card>
  );
};

export default APIKeyInput;
