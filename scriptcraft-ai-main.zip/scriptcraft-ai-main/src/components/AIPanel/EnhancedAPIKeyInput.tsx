
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Settings, Key, Image, Zap, DollarSign, Star, Loader2 } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAPIKeys, AVAILABLE_IMAGE_MODELS, ImageModel } from '../../contexts/APIKeyContext';

const EnhancedAPIKeyInput: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const {
    textApiKey,
    setTextApiKey,
    imageApiKey,
    setImageApiKey,
    selectedImageModel,
    setSelectedImageModel,
    useSameKeyForImages,
    setUseSameKeyForImages,
    effectiveImageApiKey,
    isConfigurationValid,
    loading
  } = useAPIKeys();

  // Show loading state while API keys are being loaded
  if (loading) {
    return (
      <Card className="mb-4">
        <CardContent className="flex items-center justify-center py-6">
          <div className="flex items-center space-x-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm text-script-slate-500">Loading API configuration...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getCostColor = (cost: string) => {
    switch (cost) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'standard': return 'bg-blue-100 text-blue-800';
      case 'high': return 'bg-purple-100 text-purple-800';
      case 'ultra': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="mb-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center">
          <Settings className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          API Configuration
          {isConfigurationValid && (
            <Badge variant="default" className="ml-2 bg-green-600">
              Ready
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Text Operations API Key */}
        <div className="space-y-2">
          <Label className="text-xs font-medium flex items-center">
            <Key className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            Text Operations API Key
          </Label>
          <Input
            type="password"
            placeholder="sk-..."
            value={textApiKey}
            onChange={(e) => setTextApiKey(e.target.value)}
            className="text-sm"
          />
          <p className="text-xs text-script-slate-500">
            Used for script analysis, text generation, and AI suggestions
          </p>
        </div>

        {/* Same Key Toggle */}
        <div className="flex items-center justify-between">
          <Label className="text-xs font-medium">Use same key for images</Label>
          <Switch
            checked={useSameKeyForImages}
            onCheckedChange={setUseSameKeyForImages}
          />
        </div>

        {/* Separate Image API Key */}
        {!useSameKeyForImages && (
          <div className="space-y-2">
            <Label className="text-xs font-medium flex items-center">
              <Image className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
              Image Generation API Key
            </Label>
            <Input
              type="password"
              placeholder="sk-..."
              value={imageApiKey}
              onChange={(e) => setImageApiKey(e.target.value)}
              className="text-sm"
            />
            <p className="text-xs text-script-slate-500">
              Dedicated key for storyboard image generation (cost control)
            </p>
          </div>
        )}

        {/* Image Model Selection */}
        <div className="space-y-2">
          <Label className="text-xs font-medium flex items-center">
            <Zap className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            Image Generation Model
          </Label>
          <Select
            value={selectedImageModel.id}
            onValueChange={(value) => {
              const model = AVAILABLE_IMAGE_MODELS.find(m => m.id === value);
              if (model) setSelectedImageModel(model);
            }}
          >
            <SelectTrigger className="text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {AVAILABLE_IMAGE_MODELS.map((model) => (
                <SelectItem key={model.id} value={model.id}>
                  <div className="flex items-center space-x-2 w-full">
                    <span className="font-medium">{model.name}</span>
                    <div className="flex space-x-1">
                      <Badge variant="outline" className={`text-xs ${getCostColor(model.cost)}`}>
                        <DollarSign className="h-2 w-2 mr-1" />
                        {model.cost}
                      </Badge>
                      <Badge variant="outline" className={`text-xs ${getQualityColor(model.quality)}`}>
                        <Star className="h-2 w-2 mr-1" />
                        {model.quality}
                      </Badge>
                    </div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {/* Selected Model Info */}
          <div className="p-2 bg-script-slate-50 rounded-md">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium">{selectedImageModel.name}</span>
              <div className="flex space-x-1">
                <Badge variant="outline" className={`text-xs ${getCostColor(selectedImageModel.cost)}`}>
                  {selectedImageModel.cost} cost
                </Badge>
                <Badge variant="outline" className={`text-xs ${getQualityColor(selectedImageModel.quality)}`}>
                  {selectedImageModel.quality} quality
                </Badge>
              </div>
            </div>
            <p className="text-xs text-script-slate-600">{selectedImageModel.description}</p>
            <p className="text-xs text-script-slate-500 mt-1">
              Provider: {selectedImageModel.provider.toUpperCase()}
            </p>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-script-slate-500">Configuration Status:</span>
          <div className="flex items-center space-x-1">
            <div className={`w-2 h-2 rounded-full ${isConfigurationValid ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className={isConfigurationValid ? 'text-green-600' : 'text-red-600'}>
              {isConfigurationValid ? 'Ready' : 'Keys Required'}
            </span>
          </div>
        </div>

        <p className="text-xs text-script-slate-500 border-t pt-2">
          Your API keys are stored securely and isolated per user account. We never see or store them on our servers.
        </p>
      </CardContent>
    </Card>
  );
};

export default EnhancedAPIKeyInput;
