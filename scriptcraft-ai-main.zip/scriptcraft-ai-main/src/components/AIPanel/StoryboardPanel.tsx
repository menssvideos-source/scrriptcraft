
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Film } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { ImageModel } from '../../contexts/APIKeyContext';
import ModelInfoBadge from './StoryboardPanel/ModelInfoBadge';
import StoryboardActions from './StoryboardPanel/StoryboardActions';
import StoryboardStatus from './StoryboardPanel/StoryboardStatus';

interface StoryboardPanelProps {
  apiKey: string;
  imageModel?: ImageModel;
  generatingStoryboard: boolean;
  loadingImages?: boolean;
  onGenerateCompleteStoryboard: () => void;
}

const StoryboardPanel: React.FC<StoryboardPanelProps> = ({
  apiKey,
  imageModel,
  generatingStoryboard,
  loadingImages,
  onGenerateCompleteStoryboard
}) => {
  const { t, isRTL } = useLanguage();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center">
          <Film className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('generateStoryboard')}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <StoryboardStatus apiKey={apiKey} loadingImages={loadingImages} />
        
        <ModelInfoBadge imageModel={imageModel} />

        <StoryboardActions
          apiKey={apiKey}
          imageModel={imageModel}
          generatingStoryboard={generatingStoryboard}
          onGenerateCompleteStoryboard={onGenerateCompleteStoryboard}
        />
      </CardContent>
    </Card>
  );
};

export default StoryboardPanel;
