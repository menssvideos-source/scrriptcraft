
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { MessageSquare, BookOpen } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface QuickActionsPanelProps {
  apiKey: string;
}

const QuickActionsPanel: React.FC<QuickActionsPanelProps> = ({ apiKey }) => {
  const { isRTL } = useLanguage();

  return (
    <Card className="mt-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm">Quick AI Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <Button variant="outline" size="sm" className="w-full justify-start text-xs" disabled={!apiKey}>
          <MessageSquare className={`h-3 w-3 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          Improve Dialogue
        </Button>
        <Button variant="outline" size="sm" className="w-full justify-start text-xs" disabled={!apiKey}>
          <BookOpen className={`h-3 w-3 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          Check Format
        </Button>
      </CardContent>
    </Card>
  );
};

export default QuickActionsPanel;
