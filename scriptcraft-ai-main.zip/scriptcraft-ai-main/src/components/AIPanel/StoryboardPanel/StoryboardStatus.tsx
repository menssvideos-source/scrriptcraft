
import React from 'react';
import { Settings, AlertCircle } from 'lucide-react';

interface StoryboardStatusProps {
  apiKey: string;
  loadingImages?: boolean;
}

const StoryboardStatus: React.FC<StoryboardStatusProps> = ({ apiKey, loadingImages }) => {
  if (!apiKey.trim()) {
    return (
      <div className="flex items-center space-x-2 p-2 bg-amber-50 border border-amber-200 rounded-md">
        <Settings className="h-4 w-4 text-amber-600" />
        <span className="text-xs text-amber-700">Configure API keys above</span>
      </div>
    );
  }

  if (loadingImages) {
    return (
      <div className="flex items-center justify-center py-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-script-blue-600 mr-2"></div>
        <span className="text-xs text-script-slate-500">Loading storyboard data...</span>
      </div>
    );
  }

  return null;
};

export default StoryboardStatus;
