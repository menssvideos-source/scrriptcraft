
import React from 'react';
import { Badge } from '../../ui/badge';
import { ImageModel } from '../../../contexts/APIKeyContext';

interface ModelInfoBadgeProps {
  imageModel?: ImageModel;
}

const ModelInfoBadge: React.FC<ModelInfoBadgeProps> = ({ imageModel }) => {
  const getCostColor = (cost?: string) => {
    switch (cost) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!imageModel) return null;

  return (
    <div className="p-2 bg-script-slate-50 rounded-md">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-medium">Using: {imageModel.name}</span>
        <div className="flex space-x-1">
          <Badge variant="outline" className={`text-xs ${getCostColor(imageModel.cost)}`}>
            {imageModel.cost} cost
          </Badge>
        </div>
      </div>
      <p className="text-xs text-script-slate-600">{imageModel.description}</p>
    </div>
  );
};

export default ModelInfoBadge;
