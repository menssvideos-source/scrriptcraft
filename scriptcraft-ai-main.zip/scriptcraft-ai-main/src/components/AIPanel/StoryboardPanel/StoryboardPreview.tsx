
import React, { memo, useMemo } from 'react';
import { Card } from '../../ui/card';
import { Badge } from '../../ui/badge';
import { Camera, Image, Database, Sparkles } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { StoryboardFrame } from '../../../lib/storyboard';
import { toast } from '../../ui/sonner';

interface StoryboardPreviewProps {
  storyboardFrames: StoryboardFrame[];
}

const StoryboardPreview: React.FC<StoryboardPreviewProps> = memo(({ storyboardFrames }) => {
  const { isRTL } = useLanguage();

  // Memoize computed values to prevent recalculation
  const { framesWithImages, framesGenerating, isNewStoryboard, displayFrames } = useMemo(() => {
    const framesWithImages = storyboardFrames.filter(frame => frame.imageUrl);
    const framesGenerating = storyboardFrames.filter(frame => frame.isGeneratingImage);
    const isNewStoryboard = storyboardFrames.length > 0 && storyboardFrames.every(frame => !frame.imageUrl);
    const displayFrames = storyboardFrames.slice(0, 3);

    return { framesWithImages, framesGenerating, isNewStoryboard, displayFrames };
  }, [storyboardFrames]);

  // Memoize error handler to prevent recreation
  const handleImageError = React.useCallback((frameId: string, sceneNumber: number) => {
    console.error(`Image failed to load for frame: ${frameId}`);
    toast.error(`Image failed to load for scene ${sceneNumber}`);
  }, []);

  // Memoize load handler
  const handleImageLoad = React.useCallback((frameId: string) => {
    console.log(`Image loaded successfully for frame: ${frameId}`);
  }, []);

  if (storyboardFrames.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium flex items-center">
          <Camera className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
          Preview ({storyboardFrames.length} scenes)
        </h4>
        <div className="flex items-center space-x-1">
          {isNewStoryboard && (
            <Badge variant="default" className="text-xs bg-purple-600">
              <Sparkles className="h-2 w-2 mr-1" />
              Fresh
            </Badge>
          )}
          {framesWithImages.length > 0 && (
            <Badge variant="default" className="text-xs bg-green-600">
              <Database className="h-2 w-2 mr-1" />
              {framesWithImages.length} stored
            </Badge>
          )}
          {framesGenerating.length > 0 && (
            <Badge variant="default" className="text-xs bg-blue-600 animate-pulse">
              <div className="h-2 w-2 mr-1 rounded-full bg-white animate-pulse" />
              {framesGenerating.length} generating
            </Badge>
          )}
        </div>
      </div>
      <div className="max-h-48 overflow-y-auto space-y-2">
        {displayFrames.map((frame) => (
          <Card key={frame.id} className="p-2">
            <div className="flex items-start space-x-2">
              <div className="w-16 h-10 bg-script-slate-200 rounded flex items-center justify-center flex-shrink-0 overflow-hidden">
                {frame.imageUrl ? (
                  <img 
                    src={frame.imageUrl} 
                    alt={frame.title}
                    className="w-full h-full object-cover"
                    onError={() => handleImageError(frame.id, frame.sceneNumber)}
                    onLoad={() => handleImageLoad(frame.id)}
                  />
                ) : frame.isGeneratingImage ? (
                  <div className="flex flex-col items-center">
                    <div className="animate-spin rounded-full h-3 w-3 border-b border-script-blue-600 mb-1"></div>
                    <div className="text-xs text-script-slate-500">Gen...</div>
                  </div>
                ) : (
                  <Image className="h-3 w-3 text-script-slate-400" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h5 className="text-xs font-medium truncate">Scene #{frame.sceneNumber}: {frame.title}</h5>
                <p className="text-xs text-script-slate-600 line-clamp-1">{frame.visualDescription}</p>
                {frame.panelCount && (
                  <p className="text-xs text-script-slate-500">{frame.panelCount} panels</p>
                )}
                <div className="flex items-center space-x-1 mt-1">
                  {frame.imageUrl && (
                    <Badge variant="outline" className="text-xs">
                      <Database className="h-2 w-2 mr-1" />
                      Stored
                    </Badge>
                  )}
                  {frame.isGeneratingImage && (
                    <Badge variant="outline" className="text-xs bg-blue-50 animate-pulse">
                      <div className="h-2 w-2 mr-1 rounded-full bg-blue-600 animate-pulse" />
                      Generating
                    </Badge>
                  )}
                  {!frame.imageUrl && !frame.isGeneratingImage && (
                    <Badge variant="outline" className="text-xs bg-purple-50">
                      <Sparkles className="h-2 w-2 mr-1" />
                      Ready
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </Card>
        ))}
        {storyboardFrames.length > 3 && (
          <div className="text-xs text-script-slate-500 text-center py-1">
            +{storyboardFrames.length - 3} more scenes
          </div>
        )}
      </div>
    </div>
  );
});

StoryboardPreview.displayName = 'StoryboardPreview';

export default StoryboardPreview;
