
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '../../ui/button';
import { Wand2 } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { ImageModel } from '../../../contexts/APIKeyContext';
import { toast } from '../../ui/sonner';

interface StoryboardActionsProps {
  apiKey: string;
  imageModel?: ImageModel;
  generatingStoryboard: boolean;
  onGenerateCompleteStoryboard: () => void;
}

const StoryboardActions: React.FC<StoryboardActionsProps> = ({
  apiKey,
  imageModel,
  generatingStoryboard,
  onGenerateCompleteStoryboard
}) => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();
  const { id } = useParams();

  const handleGenerateCompleteStoryboard = () => {
    if (!apiKey.trim()) {
      toast.error('Please configure your API key first to generate storyboard');
      return;
    }
    
    if (!id) {
      toast.error('No script ID found');
      return;
    }

    console.log('Starting immediate navigation to storyboard view');
    
    // Navigate immediately to storyboard page
    navigate(`/script/${id}/storyboard?generating=true`);
    
    // Start generation process (will be handled on the storyboard page)
    setTimeout(() => {
      onGenerateCompleteStoryboard();
    }, 100);
  };

  return (
    <Button 
      onClick={handleGenerateCompleteStoryboard}
      disabled={generatingStoryboard || !apiKey.trim()}
      className="w-full text-sm bg-purple-600 hover:bg-purple-700" 
      size="sm"
    >
      <Wand2 className={`h-3 w-3 ${isRTL ? 'ml-2' : 'mr-2'}`} />
      {generatingStoryboard ? 'Starting Generation...' : `Generate Complete Storyboard (${imageModel?.name || 'AI'})`}
    </Button>
  );
};

export default StoryboardActions;
