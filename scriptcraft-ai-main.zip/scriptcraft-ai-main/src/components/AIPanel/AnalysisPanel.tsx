
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { useLanguage } from '../../contexts/LanguageContext';

interface AnalysisResult {
  type: string;
  score: number;
  feedback: string;
  suggestions: string[];
}

interface AnalysisPanelProps {
  apiKey: string;
  analyzing: boolean;
  onAnalyze: () => void;
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ apiKey, analyzing, onAnalyze }) => {
  const { t, isRTL } = useLanguage();

  const analysisResults: AnalysisResult[] = [
    {
      type: 'Structure',
      score: 85,
      feedback: 'Strong three-act structure with clear turning points',
      suggestions: ['Consider strengthening the midpoint reversal', 'Add more character development in Act 2']
    },
    {
      type: 'Character Development',
      score: 78,
      feedback: 'Good character arcs for main protagonists',
      suggestions: ['Develop supporting characters more', 'Add backstory for the antagonist']
    },
    {
      type: 'Dialogue',
      score: 92,
      feedback: 'Natural, engaging dialogue that serves the story',
      suggestions: ['Vary sentence length in longer speeches', 'Add more subtext to key scenes']
    }
  ];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm">{t('analyzeScript')}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button 
          onClick={onAnalyze} 
          disabled={analyzing || !apiKey}
          className="w-full text-sm"
          size="sm"
        >
          {analyzing ? 'Analyzing...' : 'Analyze Current Script'}
        </Button>
        
        {analysisResults.length > 0 && (
          <div className="space-y-3">
            {analysisResults.map((result, index) => (
              <Card key={index} className="p-3">
                <div className={`flex items-center justify-between ${isRTL ? 'space-x-reverse' : ''} mb-2`}>
                  <h4 className="text-sm font-medium">{result.type}</h4>
                  <Badge variant={result.score >= 85 ? 'default' : result.score >= 70 ? 'secondary' : 'destructive'}>
                    {result.score}%
                  </Badge>
                </div>
                <p className="text-xs text-script-slate-600 mb-2">{result.feedback}</p>
                <div className="space-y-1">
                  {result.suggestions.map((suggestion, i) => (
                    <p key={i} className="text-xs text-script-blue-600">• {suggestion}</p>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AnalysisPanel;
