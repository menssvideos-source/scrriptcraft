
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Camera, AlertCircle, RefreshCw, Database } from 'lucide-react';
import { StoryboardFrame as StoryboardFrameType } from '../../lib/storyboard';

interface StoryboardFrameProps {
  frame: StoryboardFrameType;
  index: number;
  hasImageError: boolean;
  onImageError: (frameId: string) => void;
  onImageLoad: (frameId: string) => void;
}

const StoryboardFrame: React.FC<StoryboardFrameProps> = ({
  frame,
  index,
  hasImageError,
  onImageError,
  onImageLoad
}) => {
  const [imageLoadAttempts, setImageLoadAttempts] = React.useState(0);

  const handleImageError = (error: any) => {
    console.error(`Image load error for frame ${frame.id}:`, error);
    console.error(`Image URL: ${frame.imageUrl}`);
    
    setImageLoadAttempts(prev => prev + 1);
    onImageError(frame.id);
  };

  const handleImageLoad = () => {
    console.log(`Image loaded successfully for frame ${frame.id}`);
    onImageLoad(frame.id);
  };

  const handleRetryImage = () => {
    console.log(`Retrying image load for frame ${frame.id}`);
    setImageLoadAttempts(0);
    
    // Force a reload by creating a new image element
    const img = new Image();
    img.onload = handleImageLoad;
    img.onerror = handleImageError;
    img.src = frame.imageUrl || '';
  };

  // Enhanced image source detection
  const isStoredImage = frame.imageUrl?.includes('supabase.co') || frame.imageUrl?.includes('storyboard-images');
  const isExpiredDalleUrl = frame.imageUrl?.includes('blob.core.windows.net') || frame.imageUrl?.includes('oaidalleapiprodscus');
  const hasValidImage = frame.imageUrl && !isExpiredDalleUrl && !hasImageError;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center">
            <span className="bg-script-blue-100 text-script-blue-800 px-2 py-1 rounded-full text-sm font-medium mr-2">
              {index + 1}
            </span>
            {frame.title}
          </CardTitle>
          <div className="flex items-center space-x-1">
            {isStoredImage && (
              <Badge variant="default" className="text-xs bg-green-600">
                <Database className="h-2 w-2 mr-1" />
                Stored
              </Badge>
            )}
            {isExpiredDalleUrl && (
              <Badge variant="destructive" className="text-xs">
                Expired
              </Badge>
            )}
            {frame.isGeneratingImage && (
              <Badge variant="default" className="text-xs bg-blue-600 animate-pulse">
                Generating
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Enhanced image display with better error handling */}
        <div className="aspect-video bg-script-slate-200 rounded-lg overflow-hidden relative">
          {hasValidImage ? (
            <>
              <img 
                src={frame.imageUrl} 
                alt={frame.title}
                className="w-full h-full object-cover"
                onError={handleImageError}
                onLoad={handleImageLoad}
              />
              <div className="absolute top-2 right-2">
                <Badge variant="default" className="text-xs bg-green-600">
                  <Database className="h-2 w-2 mr-1" />
                  Stored
                </Badge>
              </div>
            </>
          ) : frame.isGeneratingImage ? (
            <div className="w-full h-full flex flex-col items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-script-blue-600 mb-2"></div>
              <div className="text-script-slate-500 text-sm">Generating & storing image...</div>
              <div className="text-script-slate-400 text-xs mt-1">Using {frame.imageModel || 'OpenAI'}</div>
            </div>
          ) : hasImageError || frame.imageError || isExpiredDalleUrl ? (
            <div className="w-full h-full flex flex-col items-center justify-center bg-red-50">
              <AlertCircle className="h-8 w-8 text-red-400 mb-2" />
              <div className="text-red-600 text-sm text-center px-2 mb-2">
                {frame.imageError || (isExpiredDalleUrl ? 'Image URL expired - use "Fix Images"' : 'Image failed to load')}
              </div>
              {frame.imageUrl && !isExpiredDalleUrl && (
                <button
                  onClick={handleRetryImage}
                  className="flex items-center text-xs text-red-600 hover:text-red-800 mb-1"
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Retry ({imageLoadAttempts})
                </button>
              )}
              {isExpiredDalleUrl && (
                <div className="text-xs text-orange-600 px-2 text-center">
                  Use "Fix Images" to regenerate with permanent storage
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center">
              <Camera className="h-12 w-12 text-script-slate-400 mb-2" />
              <div className="text-script-slate-500 text-sm">No image generated</div>
              <div className="text-script-slate-400 text-xs mt-1">Click "Generate Images" to create</div>
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <h4 className="font-medium text-script-slate-900 mb-2">Visual Description</h4>
          <p className="text-script-slate-700 text-sm leading-relaxed">
            {frame.visualDescription}
          </p>
        </div>

        {/* Technical Details Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <h5 className="font-medium text-script-slate-900 text-xs mb-1">Shot Type</h5>
            <Badge variant="outline" className="text-xs">
              {frame.shotType}
            </Badge>
          </div>
          <div>
            <h5 className="font-medium text-script-slate-900 text-xs mb-1">Camera Angle</h5>
            <Badge variant="outline" className="text-xs">
              {frame.cameraAngle}
            </Badge>
          </div>
          <div>
            <h5 className="font-medium text-script-slate-900 text-xs mb-1">Mood</h5>
            <Badge variant="outline" className="text-xs">
              {frame.mood}
            </Badge>
          </div>
          <div>
            <h5 className="font-medium text-script-slate-900 text-xs mb-1">Lighting</h5>
            <Badge variant="outline" className="text-xs">
              {frame.lighting}
            </Badge>
          </div>
        </div>

        {/* Composition Details */}
        <div>
          <h5 className="font-medium text-script-slate-900 text-xs mb-1">Composition</h5>
          <p className="text-script-slate-600 text-xs">
            {frame.composition}
          </p>
        </div>

        {/* Enhanced Debug Information */}
        {frame.imageUrl && (
          <div className="border-t pt-2">
            <h5 className="font-medium text-script-slate-900 text-xs mb-1">Image Info</h5>
            <div className="text-xs text-script-slate-500 space-y-1">
              <div>ID: {frame.id}</div>
              <div>Model: {frame.imageModel || 'OpenAI'}</div>
              <div>Source: {isStoredImage ? 'Supabase Storage (Permanent)' : isExpiredDalleUrl ? 'Expired DALL-E URL' : 'External'}</div>
              <div>Status: {frame.imageError ? 'Error' : hasImageError ? 'Load Failed' : hasValidImage ? 'OK' : 'Invalid'}</div>
              {imageLoadAttempts > 0 && (
                <div className="text-orange-500">Retry attempts: {imageLoadAttempts}</div>
              )}
              {isExpiredDalleUrl && (
                <div className="text-red-500 font-medium">⚠️ Expired URL - needs regeneration</div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StoryboardFrame;
