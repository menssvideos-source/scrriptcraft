
import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { 
  X, 
  Play, 
  AlertCircle, 
  CheckCircle, 
  Camera,
  Zap,
  RotateCcw
} from 'lucide-react';
import { useStoryboardGeneration } from '../../contexts/StoryboardGenerationContext';
import { toast } from '../ui/sonner';

const StoryboardProgressIndicator: React.FC = () => {
  const { 
    progress, 
    cancelGeneration, 
    resumeGeneration, 
    clearGeneration,
    isGenerating 
  } = useStoryboardGeneration();

  const progressPercentage = progress.totalScenes > 0 
    ? (progress.currentScene / progress.totalScenes) * 100 
    : 0;

  const getStepIcon = () => {
    switch (progress.currentStep) {
      case 'analyzing':
        return <Zap className="h-4 w-4 animate-pulse text-blue-500" />;
      case 'generating':
        return <Camera className="h-4 w-4 animate-pulse text-purple-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'cancelled':
        return <X className="h-4 w-4 text-orange-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Camera className="h-4 w-4" />;
    }
  };

  const getStepColor = () => {
    switch (progress.currentStep) {
      case 'analyzing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'generating':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'error':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleRetryFailed = () => {
    const failedCount = Object.keys(progress.errors).length;
    if (failedCount > 0) {
      toast.info(`Retrying ${failedCount} failed scenes...`);
      resumeGeneration();
    }
  };

  if (!isGenerating && progress.currentStep === 'analyzing' && progress.totalScenes === 0) {
    return null;
  }

  return (
    <Card className="mb-6 border-2 border-dashed">
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Status Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {getStepIcon()}
              <Badge variant="outline" className={getStepColor()}>
                {progress.currentStep.charAt(0).toUpperCase() + progress.currentStep.slice(1)}
              </Badge>
              <span className="text-sm font-medium">
                Scene {progress.currentScene}/{progress.totalScenes}
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              {progress.canResume && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={resumeGeneration}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Play className="h-3 w-3 mr-1" />
                  Resume
                </Button>
              )}
              
              {Object.keys(progress.errors).length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRetryFailed}
                  className="text-orange-600 hover:text-orange-700"
                >
                  <RotateCcw className="h-3 w-3 mr-1" />
                  Retry Failed ({Object.keys(progress.errors).length})
                </Button>
              )}
              
              {isGenerating && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={cancelGeneration}
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
              )}
              
              {!isGenerating && progress.currentStep !== 'analyzing' && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearGeneration}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-3 w-3 mr-1" />
                  Clear
                </Button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <Progress value={progressPercentage} className="h-2" />
            <div className="flex justify-between text-xs text-gray-500">
              <span>{progress.message}</span>
              <span>{Math.round(progressPercentage)}% complete</span>
            </div>
          </div>

          {/* Error Summary */}
          {Object.keys(progress.errors).length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3">
              <div className="flex items-center space-x-2 text-red-800 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{Object.keys(progress.errors).length} scenes failed to generate</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StoryboardProgressIndicator;
