
import React from 'react';
import { StoryboardFrame as StoryboardFrameType } from '../../lib/storyboard';
import StoryboardFrame from './StoryboardFrame';

interface StoryboardGridProps {
  frames: StoryboardFrameType[];
  imageErrors: Set<string>;
  onImageError: (frameId: string) => void;
  onImageLoad: (frameId: string) => void;
}

const StoryboardGrid: React.FC<StoryboardGridProps> = ({
  frames,
  imageErrors,
  onImageError,
  onImageLoad
}) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      {frames.map((frame, index) => (
        <StoryboardFrame
          key={frame.id}
          frame={frame}
          index={index}
          hasImageError={imageErrors.has(frame.id)}
          onImageError={onImageError}
          onImageLoad={onImageLoad}
        />
      ))}
    </div>
  );
};

export default StoryboardGrid;
