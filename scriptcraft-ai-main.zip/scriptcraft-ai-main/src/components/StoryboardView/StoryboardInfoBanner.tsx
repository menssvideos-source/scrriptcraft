
import React from 'react';
import { AlertCircle } from 'lucide-react';

interface StoryboardInfoBannerProps {
  framesWithErrors: number;
}

const StoryboardInfoBanner: React.FC<StoryboardInfoBannerProps> = ({
  framesWithErrors
}) => {
  if (framesWithErrors === 0) return null;

  return (
    <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
      <div className="flex items-center">
        <AlertCircle className="h-5 w-5 text-orange-600 mr-2" />
        <div>
          <h3 className="font-medium text-orange-800">Some images failed to load</h3>
          <p className="text-sm text-orange-700 mt-1">
            AI-generated image URLs expire after 1 hour. Click "Fix Images" to regenerate them.
          </p>
        </div>
      </div>
    </div>
  );
};

export default StoryboardInfoBanner;
