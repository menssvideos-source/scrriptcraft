
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Camera } from 'lucide-react';

interface EmptyStoryboardProps {
  scriptId: string;
}

const EmptyStoryboard: React.FC<EmptyStoryboardProps> = ({ scriptId }) => {
  const navigate = useNavigate();

  return (
    <Card className="text-center py-12">
      <CardContent>
        <Camera className="h-16 w-16 text-script-slate-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-script-slate-600 mb-2">
          No Storyboard Generated
        </h3>
        <p className="text-script-slate-500 mb-4">
          Generate a storyboard from the AI panel in the script editor to view it here.
        </p>
        <Button onClick={() => navigate(`/script/${scriptId}`)}>
          Go to Script Editor
        </Button>
      </CardContent>
    </Card>
  );
};

export default EmptyStoryboard;
