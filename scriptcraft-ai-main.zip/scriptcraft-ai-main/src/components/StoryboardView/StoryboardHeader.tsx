
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  ArrowLeft, 
  RefreshCw, 
  Download, 
  Wand2,
  Home,
  Edit,
  AlertCircle
} from 'lucide-react';

interface StoryboardHeaderProps {
  scriptId: string;
  onRefresh: () => void;
  onRegenerateImages: () => void;
  onDownloadImages: () => void;
  regeneratingImages: boolean;
  totalFrames: number;
  framesWithImages: number;
  framesWithErrors: number;
  framesGenerating: number;
  hasFailedImages: boolean;
}

const StoryboardHeader: React.FC<StoryboardHeaderProps> = ({
  scriptId,
  onRefresh,
  onRegenerateImages,
  onDownloadImages,
  regeneratingImages,
  totalFrames,
  framesWithImages,
  framesWithErrors,
  framesGenerating,
  hasFailedImages
}) => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();

  const getStatusBadge = () => {
    if (framesGenerating > 0) {
      return (
        <Badge className="bg-blue-100 text-blue-800">
          <Wand2 className="h-3 w-3 mr-1" />
          Generating ({framesGenerating})
        </Badge>
      );
    }
    
    if (framesWithErrors > 0) {
      return (
        <Badge className="bg-red-100 text-red-800">
          <AlertCircle className="h-3 w-3 mr-1" />
          {framesWithErrors} Errors
        </Badge>
      );
    }
    
    if (framesWithImages === totalFrames && totalFrames > 0) {
      return (
        <Badge className="bg-green-100 text-green-800">
          Complete ({totalFrames})
        </Badge>
      );
    }
    
    if (framesWithImages > 0) {
      return (
        <Badge className="bg-yellow-100 text-yellow-800">
          Partial ({framesWithImages}/{totalFrames})
        </Badge>
      );
    }
    
    return (
      <Badge className="bg-gray-100 text-gray-800">
        No Images
      </Badge>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-script-slate-200 p-4 sm:p-6">
      <div className={`flex flex-col space-y-4 ${isRTL ? 'space-x-reverse' : ''}`}>
        {/* Header Row */}
        <div className={`flex items-center justify-between ${isRTL ? 'space-x-reverse' : ''}`}>
          <div className={`flex items-center space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
            <h1 className="text-xl sm:text-2xl font-bold text-script-slate-900">
              Storyboard View
            </h1>
            {getStatusBadge()}
          </div>
          
          {/* Navigation Buttons */}
          <div className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''}`}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/dashboard')}
              className="hidden sm:flex"
            >
              <Home className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              Dashboard
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/script/${scriptId}`)}
            >
              <Edit className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              Edit Script
            </Button>
          </div>
        </div>

        {/* Stats and Actions Row */}
        <div className={`flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0 ${isRTL ? 'sm:space-x-reverse' : ''}`}>
          <div className={`flex items-center space-x-6 text-sm text-script-slate-600 ${isRTL ? 'space-x-reverse' : ''}`}>
            <span>Total Frames: {totalFrames}</span>
            <span>Generated: {framesWithImages}</span>
            {framesWithErrors > 0 && (
              <span className="text-red-600">Errors: {framesWithErrors}</span>
            )}
          </div>
          
          {/* Action Buttons */}
          <div className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''}`}>
            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              disabled={regeneratingImages}
            >
              <RefreshCw className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              Refresh
            </Button>
            
            {hasFailedImages && (
              <Button
                variant="outline"
                size="sm"
                onClick={onRegenerateImages}
                disabled={regeneratingImages}
                className="text-orange-600 border-orange-200 hover:bg-orange-50"
              >
                <Wand2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                {regeneratingImages ? 'Regenerating...' : 'Fix Errors'}
              </Button>
            )}
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/script/${scriptId}/storyboard?generating=true`)}
              className="text-purple-600 border-purple-200 hover:bg-purple-50"
            >
              <Wand2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              Regenerate All
            </Button>
            
            {framesWithImages > 0 && (
              <Button
                size="sm"
                onClick={onDownloadImages}
                className="bg-script-blue-600 hover:bg-script-blue-700"
              >
                <Download className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                Download ({framesWithImages})
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryboardHeader;
