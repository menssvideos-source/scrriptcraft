import React from 'react';
import { StoryboardFrame } from '../../lib/storyboard';
import { ImageStorageService } from '../../lib/imageStorage';
import { StoryboardGenerator } from '../../lib/storyboard';
import { AVAILABLE_IMAGE_MODELS } from '../../contexts/APIKeyContext';

interface StoryboardLoaderProps {
  scriptId: string;
  onFramesLoaded: (frames: StoryboardFrame[]) => void;
  onLoadingChange: (loading: boolean) => void;
}

interface StoryboardLoaderReturn {
  loadStoryboardData: () => Promise<void>;
}

export const useStoryboardLoader = ({ 
  scriptId, 
  onFramesLoaded, 
  onLoadingChange 
}: StoryboardLoaderProps): StoryboardLoaderReturn => {
  const loadStoryboardData = React.useCallback(async () => {
    if (!scriptId) return;
    
    onLoadingChange(true);
    
    try {
      console.log('Loading storyboard data for script:', scriptId);
      
      // First check Supabase for stored images
      const imageStorage = new ImageStorageService();
      const storedImages = await imageStorage.getStoredImages(scriptId);
      
      if (storedImages.length > 0) {
        console.log(`Found ${storedImages.length} stored images in Supabase`);
        
        // Convert stored images back to frames
        const frames: StoryboardFrame[] = storedImages.map(img => ({
          id: img.frame_id,
          sceneId: img.frame_id,
          sceneNumber: img.scene_number,
          title: img.title,
          visualDescription: 'Generated storyboard frame',
          shotType: 'Multi-Panel Layout',
          cameraAngle: 'Various Angles',
          mood: 'Cinematic',
          lighting: 'Dynamic',
          composition: '3-panel storyboard layout',
          panelCount: 3,
          keyMoments: [],
          imageUrl: ''
        }));
        
        // Load actual stored images
        const apiKey = localStorage.getItem('openai-api-key') || 'temp';
        const defaultImageModel = AVAILABLE_IMAGE_MODELS[0]; // Use the complete DALL-E 3 model
        const generator = new StoryboardGenerator(apiKey, defaultImageModel);
        const framesWithStoredImages = await generator.loadStoredImages(scriptId, frames);
        onFramesLoaded(framesWithStoredImages);
        
        // Update localStorage to match current state
        localStorage.setItem(`storyboard-${scriptId}`, JSON.stringify(framesWithStoredImages));
      } else {
        // No stored images, check localStorage for frames metadata
        const savedStoryboard = localStorage.getItem(`storyboard-${scriptId}`);
        if (savedStoryboard) {
          try {
            const parsedStoryboard = JSON.parse(savedStoryboard);
            
            // Check if this contains old expired URLs
            const hasExpiredImages = parsedStoryboard.some((frame: StoryboardFrame) => 
              frame.imageUrl && frame.imageUrl.includes('oaidalleapiprodscus')
            );
            
            if (hasExpiredImages) {
              console.log('Detected old storyboard with expired URLs, clearing cache');
              localStorage.removeItem(`storyboard-${scriptId}`);
              onFramesLoaded([]);
            } else {
              console.log(`Loaded ${parsedStoryboard.length} frames from localStorage`);
              onFramesLoaded(parsedStoryboard);
            }
          } catch (error) {
            console.error('Failed to parse storyboard data:', error);
            localStorage.removeItem(`storyboard-${scriptId}`);
            onFramesLoaded([]);
          }
        } else {
          onFramesLoaded([]);
        }
      }
    } catch (error) {
      console.error('Failed to load storyboard data:', error);
      onFramesLoaded([]);
    } finally {
      onLoadingChange(false);
    }
  }, [scriptId, onFramesLoaded, onLoadingChange]);

  return { loadStoryboardData };
};
