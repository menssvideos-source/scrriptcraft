
import React from 'react';
import { Badge } from '../ui/badge';

interface StoryboardStatsProps {
  totalFrames: number;
  framesWithImages: number;
  framesWithErrors: number;
  framesGenerating: number;
}

const StoryboardStats: React.FC<StoryboardStatsProps> = ({
  totalFrames,
  framesWithImages,
  framesWithErrors,
  framesGenerating
}) => {
  return (
    <>
      <Badge variant="secondary" className="text-sm">
        {totalFrames} Total Frames
      </Badge>
      
      {framesWithImages > 0 && (
        <Badge variant="default" className="text-sm bg-green-600">
          {framesWithImages} With Images
        </Badge>
      )}
      
      {framesWithErrors > 0 && (
        <Badge variant="outline" className="text-sm border-red-200 text-red-700">
          {framesWithErrors} Failed
        </Badge>
      )}
      
      {framesGenerating > 0 && (
        <Badge variant="outline" className="text-sm animate-pulse">
          {framesGenerating} Generating...
        </Badge>
      )}
    </>
  );
};

export default StoryboardStats;
