
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { ArrowLeft, ArrowRight, FileText } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface StructureNavigationProps {
  projectId: string;
  onBack: () => void;
  onNext: () => void;
  canProceed: boolean;
}

const StructureNavigation: React.FC<StructureNavigationProps> = ({
  projectId,
  onBack,
  onNext,
  canProceed
}) => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      {/* Workflow Navigation */}
      <div className={`flex items-center justify-between ${isRTL ? 'space-x-reverse' : ''}`}>
        <Button 
          variant="outline" 
          onClick={onBack}
        >
          <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('backToBrainstorm')}
        </Button>
        
        <Button 
          onClick={onNext}
          disabled={!canProceed}
          className="bg-script-blue-500 hover:bg-script-blue-600"
        >
          {t('continueToCharacters')}
          <ArrowRight className={`h-4 w-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
        </Button>
      </div>

      {/* Return to Script Navigation */}
      <div className="pt-4 border-t border-script-slate-200">
        <div className="flex items-center justify-between">
          <div className="text-sm text-script-slate-600">
            Ready to start writing? You can always return here to refine your structure.
          </div>
          <Button 
            variant="outline"
            onClick={() => navigate(`/script/${projectId}`)}
            className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
          >
            <FileText className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            Continue to Script
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StructureNavigation;
