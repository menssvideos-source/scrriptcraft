import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Script } from '../types/script';
import { ScriptElement } from '../types/script';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Calendar, 
  FileText, 
  MoreVertical, 
  Star,
  Copy,
  Trash2,
  Edit,
  Clock,
  Film
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface ScriptCardProps {
  script: Script & { 
    elements?: ScriptElement[];
    content?: any[];
  };
  onOpen: (scriptId: string) => void;
  onDuplicate: (scriptId: string) => void;
  onDelete: (scriptId: string) => void;
  onToggleStar: (scriptId: string) => void;
}

const ScriptCard: React.FC<ScriptCardProps> = ({
  script,
  onOpen,
  onDuplicate,
  onDelete,
  onToggleStar
}) => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();

  // Enhanced statistics calculations - prioritize script.content over script.elements over database fields
  const calculateEnhancedStats = () => {
    // Try to get elements from script.content first (database jsonb), then script.elements
    let elements: ScriptElement[] = [];
    
    if (script.content && Array.isArray(script.content) && script.content.length > 0) {
      elements = script.content;
    } else if (script.elements && Array.isArray(script.elements) && script.elements.length > 0) {
      elements = script.elements;
    }

    // If we have elements, calculate from them
    if (elements.length > 0) {
      // Better scene counting (exclude FADE transitions)
      const sceneCount = elements.filter(el => 
        el.type === 'scene-heading' && 
        el.content && 
        el.content.trim() && 
        !el.content.toUpperCase().includes('FADE')
      ).length;

      // Enhanced word counting
      const wordCount = elements
        .filter(el => el.content && el.content.trim())
        .reduce((total, el) => {
          const words = el.content.trim().split(/\s+/).filter(word => word.length > 0);
          return total + words.length;
        }, 0);

      // Industry standard page calculation with scene consideration
      const basePageCount = Math.ceil(wordCount / 250);
      const sceneBasedPages = Math.ceil(sceneCount / 2); // Rough estimate: 2 scenes per page
      const pageCount = Math.max(1, Math.max(basePageCount, sceneBasedPages));

      // Reading time calculation
      const readingTime = Math.ceil(wordCount / 250);

      return { sceneCount, wordCount, pageCount, readingTime };
    }

    // Fallback to existing script properties if no elements available
    return {
      sceneCount: script.sceneCount || 0,
      wordCount: script.wordCount || 0,
      pageCount: script.pageCount || 1,
      readingTime: Math.ceil((script.wordCount || 0) / 250)
    };
  };

  const stats = calculateEnhancedStats();

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const getTemplateColor = (template: string) => {
    switch (template) {
      case 'feature-film':
        return 'bg-blue-100 text-blue-800';
      case 'tv-episode':
        return 'bg-green-100 text-green-800';
      case 'short-film':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getScriptLengthStatus = () => {
    if (script.template === 'short-film') {
      if (stats.pageCount > 30) return { color: 'text-amber-600', label: 'Long for short film' };
      return { color: 'text-green-600', label: 'Good length' };
    }
    
    if (script.template === 'tv-episode') {
      if (stats.pageCount < 22) return { color: 'text-blue-600', label: 'Short episode' };
      if (stats.pageCount > 60) return { color: 'text-red-600', label: 'Long episode' };
      return { color: 'text-green-600', label: 'Good length' };
    }
    
    // Feature film
    if (stats.pageCount < 90) return { color: 'text-yellow-600', label: 'Short feature' };
    if (stats.pageCount > 120) return { color: 'text-red-600', label: 'Long feature' };
    return { color: 'text-green-600', label: 'Good length' };
  };

  const lengthStatus = getScriptLengthStatus();

  const handleViewStoryboard = () => {
    navigate(`/script/${script.id}/storyboard`);
  };

  const handleGenerateStoryboard = () => {
    navigate(`/script/${script.id}`, { state: { openAIPanel: true } });
  };

  return (
    <Card className={`group hover:shadow-lg transition-all duration-200 cursor-pointer hover:scale-[1.02] ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <CardHeader className={`pb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
        <div className={`flex items-start justify-between ${isRTL ? 'space-x-reverse' : ''}`}>
          <div className="flex-1 min-w-0" onClick={() => onOpen(script.id)}>
            <div className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''} mb-2`}>
              <h3 className="font-semibold text-lg text-script-slate-900 truncate">
                {script.title}
              </h3>
              {script.isStarred && (
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
              )}
            </div>
            <p className="text-sm text-script-slate-600 line-clamp-2 mb-3">
              {script.description || 'No description available'}
            </p>
            <div className={`flex flex-wrap items-center gap-2 mb-3 ${isRTL ? 'space-x-reverse' : ''}`}>
              <Badge className={`text-xs ${getTemplateColor(script.template)}`}>
                {script.template.split('-').map(word => 
                  word.charAt(0).toUpperCase() + word.slice(1)
                ).join(' ')}
              </Badge>
              <Badge variant="outline" className={`text-xs ${lengthStatus.color}`}>
                {lengthStatus.label}
              </Badge>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onOpen(script.id)}>
                <Edit className="h-4 w-4 mr-2" />
                {t('open')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onToggleStar(script.id)}>
                <Star className="h-4 w-4 mr-2" />
                {script.isStarred ? t('unstar') : t('star')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDuplicate(script.id)}>
                <Copy className="h-4 w-4 mr-2" />
                {t('duplicate')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDelete(script.id)} className="text-red-600">
                <Trash2 className="h-4 w-4 mr-2" />
                {t('delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        {/* Storyboard Status Section - Simplified without automatic API calls */}
        <div className="mb-4 p-3 bg-script-slate-50 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Film className="h-4 w-4 text-script-slate-500" />
              <span className="text-sm text-script-slate-600">Storyboard</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleGenerateStoryboard();
              }}
              className="text-xs"
            >
              Check Status
            </Button>
          </div>
        </div>
        
        {/* Enhanced Script Metadata */}
        <div className={`grid grid-cols-2 gap-4 text-sm text-script-slate-600 mb-3 ${isRTL ? 'space-x-reverse' : ''}`} onClick={() => onOpen(script.id)}>
          <div className={`flex items-center space-x-1 ${isRTL ? 'space-x-reverse' : ''}`}>
            <FileText className="h-3 w-3" />
            <span>{stats.pageCount} {stats.pageCount === 1 ? 'page' : 'pages'}</span>
          </div>
          <div className={`flex items-center space-x-1 ${isRTL ? 'space-x-reverse' : ''}`}>
            <Film className="h-3 w-3" />
            <span>{stats.sceneCount} {stats.sceneCount === 1 ? 'scene' : 'scenes'}</span>
          </div>
          <div className={`flex items-center space-x-1 ${isRTL ? 'space-x-reverse' : ''}`}>
            <span className="font-medium">{stats.wordCount.toLocaleString()}</span>
            <span>words</span>
          </div>
          <div className={`flex items-center space-x-1 ${isRTL ? 'space-x-reverse' : ''}`}>
            <Clock className="h-3 w-3" />
            <span>~{stats.readingTime} min read</span>
          </div>
        </div>
        
        {/* Last Modified */}
        <div className={`flex items-center space-x-1 text-xs text-script-slate-500 ${isRTL ? 'space-x-reverse' : ''}`} onClick={() => onOpen(script.id)}>
          <Calendar className="h-3 w-3" />
          <span>Last modified {formatDate(script.lastModified)}</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScriptCard;
