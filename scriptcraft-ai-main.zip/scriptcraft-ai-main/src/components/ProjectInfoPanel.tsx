
import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Users } from 'lucide-react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { useLanguage } from '../contexts/LanguageContext';

interface ProjectInfoPanelProps {
  showProjectInfo: boolean;
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  insertCharacterName: (name: string) => void;
}

const ProjectInfoPanel: React.FC<ProjectInfoPanelProps> = ({
  showProjectInfo,
  brainstorm,
  structure,
  characters,
  insertCharacterName
}) => {
  const { isRTL } = useLanguage();

  if (!showProjectInfo || (!brainstorm && !structure && characters.length === 0)) {
    return null;
  }

  return (
    <div className="bg-script-slate-50 border-b border-script-slate-200 p-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Characters */}
        {characters.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center">
                <Users className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                Characters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {characters.slice(0, 3).map((character) => (
                <Button
                  key={character.id}
                  variant="outline"
                  size="sm"
                  className="w-full justify-start text-xs"
                  onClick={() => insertCharacterName(character.name)}
                >
                  {character.name} ({character.role})
                </Button>
              ))}
              {characters.length > 3 && (
                <p className="text-xs text-script-slate-500">
                  +{characters.length - 3} more
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Structure */}
        {structure && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1 text-xs">
                <p><strong>Genre:</strong> {structure.genre}</p>
                <p><strong>Theme:</strong> {structure.theme}</p>
                {structure.logline && (
                  <p><strong>Logline:</strong> {structure.logline.substring(0, 60)}...</p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Brainstorm */}
        {brainstorm && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Project Info</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1 text-xs">
                <p><strong>Setting:</strong> {brainstorm.setting}</p>
                <p><strong>Tone:</strong> {brainstorm.tone}</p>
                <p><strong>Audience:</strong> {brainstorm.targetAudience}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ProjectInfoPanel;
