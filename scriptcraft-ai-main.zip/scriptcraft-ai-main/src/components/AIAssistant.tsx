
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Bot, 
  Lightbulb, 
  MessageSquare, 
  Settings,
  Send,
  Wand2,
  Key
} from 'lucide-react';

interface AIAssistantProps {
  context: 'brainstorm' | 'structure' | 'characters' | 'writing';
  projectData: any;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ context, projectData }) => {
  const { t, isRTL } = useLanguage();
  const [apiKey, setApiKey] = useState('');
  const [message, setMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [conversation, setConversation] = useState<{ role: 'user' | 'assistant'; content: string }[]>([]);

  // Load API key from localStorage on component mount - always start empty for new users
  useEffect(() => {
    const savedApiKey = localStorage.getItem('openai-api-key');
    if (savedApiKey) {
      setApiKey(savedApiKey);
      console.log('Loaded existing API key from localStorage');
    } else {
      console.log('No API key found - user needs to enter their own key');
    }
  }, []);

  // Save API key to localStorage whenever it changes
  const handleApiKeyChange = (value: string) => {
    setApiKey(value);
    if (value.trim()) {
      localStorage.setItem('openai-api-key', value);
      console.log('API key saved to localStorage');
    } else {
      localStorage.removeItem('openai-api-key');
      console.log('API key removed from localStorage');
    }
  };

  const contextPrompts = {
    brainstorm: [
      "Help me develop this story idea further",
      "Suggest themes that would work with this genre", 
      "What makes a compelling logline?",
      "Generate location ideas for my story"
    ],
    structure: [
      "Help me strengthen my inciting incident",
      "What should happen at the midpoint?",
      "Suggest plot points for Act II",
      "How can I raise the stakes?"
    ],
    characters: [
      "Help me develop this character's backstory",
      "Create a compelling character arc",
      "Suggest dialogue that fits this character",
      "What relationships should this character have?"
    ],
    writing: [
      "Improve this scene's dialogue",
      "Help with character voice consistency", 
      "Suggest action line improvements",
      "Check screenplay formatting"
    ]
  };

  const createContextualPrompt = (userMessage: string) => {
    let contextInfo = '';
    
    if (context === 'brainstorm' && projectData) {
      contextInfo = `Project Context:
Story Idea: ${projectData.idea || 'Not specified'}
Genre: ${projectData.genre || 'Not specified'}
Tone: ${projectData.tone || 'Not specified'}
Theme: ${projectData.theme || 'Not specified'}
Setting: ${projectData.setting || 'Not specified'}
Logline: ${projectData.logline || 'Not specified'}
Premise: ${projectData.premise || 'Not specified'}

`;
    }
    
    return `${contextInfo}User Question: ${userMessage}

Please provide specific, actionable advice for this ${context} phase of screenplay development, taking into account the project details provided above.`;
  };

  const callOpenAI = async (prompt: string) => {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          {
            role: 'system',
            content: `You are a professional screenplay writing assistant. Help the user with their ${context} phase of screenplay development. Be specific, practical, and reference industry standards.`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !apiKey.trim()) {
      alert('Please enter both your message and API key');
      return;
    }

    setIsProcessing(true);
    const userMessage = message;
    setMessage('');

    // Add user message to conversation
    setConversation(prev => [...prev, { role: 'user', content: userMessage }]);

    try {
      const contextualPrompt = createContextualPrompt(userMessage);
      const response = await callOpenAI(contextualPrompt);
      
      setConversation(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error('AI request failed:', error);
      const errorMessage = `Sorry, I couldn't process your request. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`;
      setConversation(prev => [...prev, { role: 'assistant', content: errorMessage }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    setMessage(prompt);
  };

  const generateSuggestions = async () => {
    if (!apiKey.trim()) {
      alert('Please enter your API key first');
      return;
    }

    setIsProcessing(true);
    
    try {
      let contextualPrompt = '';
      
      switch (context) {
        case 'brainstorm':
          contextualPrompt = createContextualPrompt('Based on my project details, provide 3 specific suggestions to improve my story concept, focusing on character development, plot structure, and thematic depth.');
          break;
        case 'structure':
          contextualPrompt = createContextualPrompt('Analyze my story structure and suggest improvements for pacing and plot development.');
          break;
        case 'characters':
          contextualPrompt = createContextualPrompt('Help me develop stronger character arcs and relationships for my story.');
          break;
        case 'writing':
          contextualPrompt = createContextualPrompt('Provide writing tips specific to my genre and story type.');
          break;
      }

      const response = await callOpenAI(contextualPrompt);
      setConversation(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error('AI suggestion failed:', error);
      const errorMessage = `Sorry, I couldn't generate suggestions. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`;
      setConversation(prev => [...prev, { role: 'assistant', content: errorMessage }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center">
          <Bot className={`h-4 w-4 text-script-blue-500 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          AI Assistant
          <Badge variant="secondary" className="ml-2 text-xs">
            BYOK
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* API Key Input - Always visible and starts empty */}
        <div className="space-y-2">
          <label className="text-xs font-medium flex items-center">
            <Key className="h-3 w-3 mr-1" />
            Your OpenAI API Key
          </label>
          <Input
            type="password"
            placeholder="sk-..."
            value={apiKey}
            onChange={(e) => handleApiKeyChange(e.target.value)}
            className="text-xs"
          />
          <p className="text-xs text-script-slate-500">
            🔒 Your key stays in your browser - complete privacy
          </p>
          {!apiKey && (
            <p className="text-xs text-amber-600">
              ⚠️ Enter your API key to use AI features
            </p>
          )}
        </div>

        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="chat" className="text-xs">
              Chat
            </TabsTrigger>
            <TabsTrigger value="suggestions" className="text-xs">
              Quick Help
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="space-y-3">
            {/* Conversation */}
            <div className="max-h-48 overflow-y-auto space-y-2 p-2 bg-script-slate-50 rounded">
              {conversation.length === 0 ? (
                <div className="text-xs text-script-slate-500 text-center py-4">
                  {!apiKey ? (
                    <div>
                      <p className="mb-2">🔑 Add your OpenAI API key above</p>
                      <p>Then start chatting with the AI assistant</p>
                    </div>
                  ) : (
                    <p>Start a conversation with the AI assistant</p>
                  )}
                </div>
              ) : (
                conversation.map((msg, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded text-xs ${
                      msg.role === 'user'
                        ? 'bg-script-blue-100 ml-4'
                        : 'bg-white mr-4'
                    }`}
                  >
                    <p className="font-medium text-xs mb-1">
                      {msg.role === 'user' ? 'You' : 'AI'}
                    </p>
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>
                ))
              )}
              {isProcessing && (
                <div className="bg-white mr-4 p-2 rounded text-xs">
                  <p className="font-medium text-xs mb-1">
                    AI
                  </p>
                  <p className="text-script-slate-500">
                    Thinking...
                  </p>
                </div>
              )}
            </div>

            {/* Message Input */}
            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask for help..."
                className="text-xs"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <Button 
                size="sm" 
                onClick={handleSendMessage}
                disabled={!message.trim() || !apiKey.trim() || isProcessing}
              >
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-3">
            <Button 
              onClick={generateSuggestions}
              disabled={!apiKey.trim() || isProcessing}
              className="w-full text-xs"
              size="sm"
            >
              <Wand2 className={`h-3 w-3 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              {isProcessing ? 'Generating...' : 'Get AI Suggestions'}
            </Button>

            <div className="space-y-2">
              <p className="text-xs font-medium">
                Quick Prompts:
              </p>
              {contextPrompts[context].map((prompt, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="w-full text-xs justify-start h-auto p-2"
                  onClick={() => handleQuickPrompt(prompt)}
                >
                  {prompt}
                </Button>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AIAssistant;
