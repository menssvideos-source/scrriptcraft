
import React from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TabsContent } from './ui/tabs';
import { Target, Zap, BookOpen, Wand2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface ActField {
  key: string;
  label: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
}

interface ActCardProps {
  actNumber: 1 | 2 | 3;
  tabValue: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  fields: ActField[];
  onAIAssist: (fieldKey: string) => void;
  isGenerating: boolean;
}

const ActCard: React.FC<ActCardProps> = ({ 
  actNumber, 
  tabValue, 
  title, 
  subtitle, 
  icon, 
  fields, 
  onAIAssist, 
  isGenerating 
}) => {
  const { isRTL } = useLanguage();

  return (
    <TabsContent value={tabValue} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <span className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`}>
                {icon}
              </span>
              {title} ({subtitle})
            </div>
            {/* Generate all fields for the act */}
            <Button 
              onClick={() => onAIAssist(`act${actNumber}`)} 
              disabled={isGenerating}
              variant="default"
              size="sm"
              className="flex items-center gap-2"
            >
              <Wand2 className="h-4 w-4" />
              {isGenerating ? 'Generating...' : `Generate All ${actNumber === 1 ? 'Act 1' : actNumber === 2 ? 'Act 2' : 'Act 3'} Fields`}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {fields.map((field) => (
            <div key={field.key}>
              <label className="block text-sm font-medium mb-2">{field.label}</label>
              <Textarea
                value={field.value}
                onChange={(e) => field.onChange(e.target.value)}
                placeholder={field.placeholder}
                className="min-h-24"
              />
            </div>
          ))}
        </CardContent>
      </Card>
    </TabsContent>
  );
};

export default ActCard;
