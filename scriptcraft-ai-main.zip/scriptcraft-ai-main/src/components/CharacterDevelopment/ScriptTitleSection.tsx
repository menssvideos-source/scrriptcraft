
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Save, Check, Wand2 } from 'lucide-react';

interface ScriptTitleSectionProps {
  localTitle: string;
  scriptTitle: string;
  isSavingTitle: boolean;
  titleSaved: boolean;
  onTitleChange: (value: string) => void;
  onTitleSave: (title: string) => Promise<void>;
  onTitleKeyPress: (e: React.KeyboardEvent) => void;
  onGenerateTitle?: () => void;
  isGeneratingTitle?: boolean;
}

const ScriptTitleSection: React.FC<ScriptTitleSectionProps> = ({
  localTitle,
  scriptTitle,
  isSavingTitle,
  titleSaved,
  onTitleChange,
  onTitleSave,
  onTitleKeyPress,
  onGenerateTitle,
  isGeneratingTitle = false
}) => {
  const { t } = useLanguage();

  const handleSave = async () => {
    if (localTitle.trim()) {
      await onTitleSave(localTitle.trim());
    }
  };

  const displayTitle = scriptTitle || 'Enter your script title...';
  const hasTitle = scriptTitle && scriptTitle.trim() !== '';

  return (
    <div className="bg-white rounded-lg shadow-sm border border-script-slate-200 p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-script-slate-900">Script Title</h2>
        <Badge variant="secondary">{t('phaseThreeOfFour')}</Badge>
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center space-x-3">
          <Input
            value={localTitle}
            onChange={(e) => onTitleChange(e.target.value)}
            onKeyPress={onTitleKeyPress}
            placeholder="Enter your script title..."
            className="flex-1 text-lg font-medium"
          />
          <Button
            onClick={handleSave}
            disabled={isSavingTitle || !localTitle.trim()}
            size="sm"
            variant="outline"
          >
            {titleSaved ? (
              <Check className="h-4 w-4 text-green-600" />
            ) : (
              <Save className={`h-4 w-4 ${isSavingTitle ? 'animate-spin' : ''}`} />
            )}
            {isSavingTitle ? 'Saving...' : titleSaved ? 'Saved' : 'Save'}
          </Button>
        </div>
        
        {onGenerateTitle && (
          <div className="flex items-center space-x-2">
            <Button
              onClick={onGenerateTitle}
              disabled={isGeneratingTitle}
              size="sm"
              variant="ghost"
              className="text-script-blue-600 hover:text-script-blue-700"
            >
              <Wand2 className={`h-4 w-4 mr-2 ${isGeneratingTitle ? 'animate-spin' : ''}`} />
              {isGeneratingTitle ? 'Generating...' : 'Generate Title Suggestions'}
            </Button>
          </div>
        )}
        
        {hasTitle && (
          <p className="text-sm text-script-slate-600">
            Current title: <span className="font-medium">{displayTitle}</span>
          </p>
        )}
        
        {!hasTitle && (
          <p className="text-sm text-amber-600">
            Please enter a title for your script to continue
          </p>
        )}
      </div>
    </div>
  );
};

export default ScriptTitleSection;
