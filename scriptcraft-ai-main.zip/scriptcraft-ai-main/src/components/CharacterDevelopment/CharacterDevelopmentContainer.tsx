
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { useCharacterOperations } from '../../hooks/useCharacterOperations';
import { useScriptTitle } from '../../hooks/useScriptTitle';
import { useWorkflowData } from '../../hooks/useWorkflowData';
import { characterGenerationService } from '../../services/characterGenerationService';
import CharacterDevelopmentNavigation from './CharacterDevelopmentNavigation';
import CharacterDevelopmentContent from './CharacterDevelopmentContent';
import CharacterDevelopmentFooter from './CharacterDevelopmentFooter';
import { supabase } from '../../integrations/supabase/client';

interface CharacterDevelopmentContainerProps {
  projectId: string;
}

const CharacterDevelopmentContainer: React.FC<CharacterDevelopmentContainerProps> = ({ projectId }) => {
  const navigate = useNavigate();
  const { isRTL } = useLanguage();
  
  const {
    characters,
    selectedCharacter,
    setSelectedCharacter,
    addCharacter,
    updateCharacter,
    deleteCharacter,
    replaceAllCharacters,
    saveCharacters,
    loadCharacters
  } = useCharacterOperations();

  const {
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    loadScript,
    saveScriptTitle
  } = useScriptTitle();

  const { brainstorm, structure } = useWorkflowData(projectId);

  const [isGenerating, setIsGenerating] = useState(false);
  const [localTitle, setLocalTitle] = useState('');
  const [hasInitialized, setHasInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isGeneratingTitle, setIsGeneratingTitle] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  // Check if projectId is a timestamp (legacy) or UUID
  const isTimestampId = (id: string): boolean => {
    return /^\d{13}$/.test(id);
  };

  const isValidUUID = (id: string): boolean => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(id);
  };

  // Load data on component mount
  useEffect(() => {
    if (projectId && !hasInitialized) {
      console.log('CharacterDevelopmentContainer: Initializing for ID:', projectId);
      setIsLoading(true);
      
      Promise.all([
        loadCharacters(projectId),
        loadScript(projectId)
      ]).finally(() => {
        setHasInitialized(true);
        setIsLoading(false);
      });
    }
  }, [projectId, loadCharacters, loadScript, hasInitialized]);

  // Update local title when script title changes
  useEffect(() => {
    setLocalTitle(scriptTitle || '');
  }, [scriptTitle]);

  // Auto-save characters when they change (but not on initial load)
  useEffect(() => {
    if (projectId && characters.length > 0 && hasInitialized) {
      const timeoutId = setTimeout(() => {
        saveCharacters(projectId);
      }, 500);

      return () => clearTimeout(timeoutId);
    }
  }, [characters, projectId, saveCharacters, hasInitialized]);

  const handleTitleChange = useCallback((value: string) => {
    setLocalTitle(value);
  }, []);

  const handleTitleSave = useCallback(async (title: string) => {
    if (title.trim() && projectId) {
      console.log('CharacterDevelopmentContainer: Saving title:', title);
      await saveScriptTitle(projectId, title);
    }
  }, [projectId, saveScriptTitle]);

  const handleTitleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && localTitle.trim()) {
      handleTitleSave(localTitle.trim());
    }
  }, [handleTitleSave, localTitle]);

  const handleGenerateTitle = useCallback(async () => {
    if (!brainstorm || isGeneratingTitle) return;
    
    setIsGeneratingTitle(true);
    try {
      // Simple title generation based on project data
      const genre = brainstorm.genre || 'story';
      const mainConcept = brainstorm.idea || brainstorm.logline || '';
      
      // Extract key words from idea/logline
      const words = mainConcept.split(' ').filter(word => 
        word.length > 3 && !['the', 'and', 'but', 'for', 'are', 'with', 'they', 'have', 'this', 'that'].includes(word.toLowerCase())
      );
      
      const keyWords = words.slice(0, 3);
      const suggestedTitle = keyWords.length > 0 
        ? keyWords.join(' ').replace(/[^\w\s]/gi, '').trim()
        : `My ${genre.charAt(0).toUpperCase() + genre.slice(1)}`;
      
      setLocalTitle(suggestedTitle);
    } catch (error) {
      console.error('Title generation failed:', error);
    } finally {
      setIsGeneratingTitle(false);
    }
  }, [brainstorm, isGeneratingTitle]);

  const handleGenerateCharacters = useCallback(async () => {
    if (!projectId || isGenerating) {
      console.log('Cannot generate - missing ID or already generating');
      return;
    }
    
    try {
      setIsGenerating(true);
      console.log('Starting character generation...');
      
      const generatedCharacters = await characterGenerationService.generateCharacterSuggestions(brainstorm, structure);
      console.log('Characters generated successfully:', generatedCharacters.length);
      
      replaceAllCharacters(generatedCharacters);
      
    } catch (error) {
      console.error('Character generation failed:', error);
      alert(error instanceof Error ? error.message : 'Character generation failed');
    } finally {
      setIsGenerating(false);
    }
  }, [projectId, brainstorm, structure, replaceAllCharacters, isGenerating]);

  const canProceed = localTitle.trim() !== '' && characters.length > 0;

  const createScriptForLegacyProject = async (legacyProjectId: string, title: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Create a new script in the database
      const { data: newScript, error: createError } = await supabase
        .from('scripts')
        .insert({
          title: title.trim(),
          description: 'Script created from workflow',
          genre: 'feature-film',
          user_id: user.id,
          content: []
        })
        .select()
        .single();

      if (createError) {
        console.error('CharacterDevelopmentContainer: Error creating script:', createError);
        throw createError;
      }

      console.log('CharacterDevelopmentContainer: Created new script for legacy project:', newScript.id);
      return newScript.id;
    } catch (error) {
      console.error('CharacterDevelopmentContainer: Failed to create script for legacy project:', error);
      throw error;
    }
  };

  const handleNext = useCallback(async () => {
    if (!canProceed || isNavigating) return;

    setIsNavigating(true);
    try {
      console.log('CharacterDevelopmentContainer: Starting navigation process for ID:', projectId);
      
      let targetScriptId = projectId;

      // Handle legacy timestamp IDs by creating a proper script
      if (isTimestampId(projectId)) {
        console.log('CharacterDevelopmentContainer: Converting legacy timestamp ID to script');
        try {
          targetScriptId = await createScriptForLegacyProject(projectId, localTitle.trim() || 'Untitled Script');
          console.log('CharacterDevelopmentContainer: Created script with UUID:', targetScriptId);
        } catch (error) {
          console.error('CharacterDevelopmentContainer: Failed to create script for legacy project:', error);
          alert('Failed to create script. Please try again.');
          return;
        }
      } else if (isValidUUID(projectId)) {
        // For UUID projects, save the title if it has changed
        if (localTitle.trim() && localTitle !== scriptTitle) {
          console.log('CharacterDevelopmentContainer: Saving title before navigation:', localTitle);
          await saveScriptTitle(projectId, localTitle.trim());
        }
      }
      
      // Save characters
      console.log('CharacterDevelopmentContainer: Saving characters before navigation');
      await saveCharacters(projectId);
      
      // Small delay to ensure everything is saved
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log('CharacterDevelopmentContainer: Navigating to script editor with ID:', targetScriptId);
      navigate(`/script/${targetScriptId}`);
    } catch (error) {
      console.error('CharacterDevelopmentContainer: Navigation failed:', error);
      alert('Failed to save data before navigation. Please try again.');
    } finally {
      setIsNavigating(false);
    }
  }, [projectId, canProceed, localTitle, scriptTitle, saveScriptTitle, saveCharacters, navigate, isNavigating]);

  const handleBack = useCallback(() => {
    navigate(`/script/${projectId}/structure-planning`);
  }, [navigate, projectId]);

  if (isLoading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-script-blue-600 mx-auto mb-4"></div>
          <div className="text-script-slate-600">Loading character development...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <CharacterDevelopmentNavigation onBack={handleBack} />
      
      <CharacterDevelopmentContent
        localTitle={localTitle}
        scriptTitle={scriptTitle}
        isSavingTitle={isSavingTitle}
        titleSaved={titleSaved}
        isGenerating={isGenerating}
        isGeneratingTitle={isGeneratingTitle}
        characters={characters}
        selectedCharacter={selectedCharacter}
        brainstorm={brainstorm}
        structure={structure}
        canProceed={canProceed}
        onTitleChange={handleTitleChange}
        onTitleSave={handleTitleSave}
        onTitleKeyPress={handleTitleKeyPress}
        onGenerateTitle={handleGenerateTitle}
        onGenerateCharacters={handleGenerateCharacters}
        onSelectCharacter={setSelectedCharacter}
        onAddCharacter={addCharacter}
        onUpdateCharacter={updateCharacter}
        onDeleteCharacter={deleteCharacter}
      />

      <CharacterDevelopmentFooter
        onBack={handleBack}
        onNext={handleNext}
        canProceed={canProceed && !isNavigating}
      />
      
      {isNavigating && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-script-blue-600 mx-auto mb-4"></div>
            <div className="text-script-slate-600">Saving and navigating to script editor...</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CharacterDevelopmentContainer;
