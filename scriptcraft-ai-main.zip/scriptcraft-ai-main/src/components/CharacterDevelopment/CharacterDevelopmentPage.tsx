
import React from 'react';
import { useParams } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import Header from '../Header';
import CharacterDevelopmentContainer from './CharacterDevelopmentContainer';

const CharacterDevelopmentPage: React.FC = () => {
  const { id } = useParams();
  const { isRTL } = useLanguage();

  if (!id) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center`}>
        <div className="text-center">
          <div className="text-script-slate-600">Invalid project ID</div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      <CharacterDevelopmentContainer projectId={id} />
    </div>
  );
};

export default CharacterDevelopmentPage;
