
import React from 'react';
import { Character, ProjectBrainstorm, ProjectStructure } from '../../types/project';
import ScriptTitleSection from './ScriptTitleSection';
import CharacterDevelopmentHeader from './CharacterDevelopmentHeader';
import CharacterList from './CharacterList';
import CharacterDetails from './CharacterDetails';
import AIAssistant from '../AIAssistant';

interface CharacterDevelopmentContentProps {
  localTitle: string;
  scriptTitle: string;
  isSavingTitle: boolean;
  titleSaved: boolean;
  isGenerating: boolean;
  isGeneratingTitle: boolean;
  characters: Character[];
  selectedCharacter: string | null;
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  canProceed: boolean;
  onTitleChange: (value: string) => void;
  onTitleSave: (title: string) => Promise<void>;
  onTitleKeyPress: (e: React.KeyboardEvent) => void;
  onGenerateTitle: () => void;
  onGenerateCharacters: () => void;
  onSelectCharacter: (id: string) => void;
  onAddCharacter: () => void;
  onUpdateCharacter: (id: string, updates: Partial<Character>) => void;
  onDeleteCharacter: (id: string) => void;
}

const CharacterDevelopmentContent: React.FC<CharacterDevelopmentContentProps> = ({
  localTitle,
  scriptTitle,
  isSavingTitle,
  titleSaved,
  isGenerating,
  isGeneratingTitle,
  characters,
  selectedCharacter,
  brainstorm,
  structure,
  canProceed,
  onTitleChange,
  onTitleSave,
  onTitleKeyPress,
  onGenerateTitle,
  onGenerateCharacters,
  onSelectCharacter,
  onAddCharacter,
  onUpdateCharacter,
  onDeleteCharacter
}) => {
  const currentCharacter = characters.find(char => char.id === selectedCharacter);

  return (
    <>
      <ScriptTitleSection
        localTitle={localTitle}
        scriptTitle={scriptTitle}
        isSavingTitle={isSavingTitle}
        titleSaved={titleSaved}
        onTitleChange={onTitleChange}
        onTitleSave={onTitleSave}
        onTitleKeyPress={onTitleKeyPress}
        onGenerateTitle={onGenerateTitle}
        isGeneratingTitle={isGeneratingTitle}
      />

      <CharacterDevelopmentHeader
        isGenerating={isGenerating}
        onGenerateCharacters={onGenerateCharacters}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <CharacterList
            characters={characters}
            selectedCharacter={selectedCharacter}
            onSelectCharacter={onSelectCharacter}
            onAddCharacter={onAddCharacter}
            onDeleteCharacter={onDeleteCharacter}
          />
        </div>

        <div className="lg:col-span-1">
          {currentCharacter && (
            <CharacterDetails
              character={currentCharacter}
              onUpdateCharacter={onUpdateCharacter}
            />
          )}
        </div>
        
        <div className="lg:col-span-1">
          <AIAssistant 
            context="characters" 
            projectData={{ brainstorm, structure, characters }} 
          />
        </div>
      </div>
    </>
  );
};

export default CharacterDevelopmentContent;
