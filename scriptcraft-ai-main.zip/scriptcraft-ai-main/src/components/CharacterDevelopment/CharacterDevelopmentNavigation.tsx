
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { ArrowLeft } from 'lucide-react';

interface CharacterDevelopmentNavigationProps {
  onBack: () => void;
}

const CharacterDevelopmentNavigation: React.FC<CharacterDevelopmentNavigationProps> = ({
  onBack
}) => {
  const { t, isRTL } = useLanguage();

  return (
    <Button 
      variant="ghost" 
      onClick={onBack}
      className={`mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}
    >
      <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
      {t('backToStructure')}
    </Button>
  );
};

export default CharacterDevelopmentNavigation;
