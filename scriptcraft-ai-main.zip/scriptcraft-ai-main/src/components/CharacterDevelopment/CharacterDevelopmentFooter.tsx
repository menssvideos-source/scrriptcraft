
import React from 'react';
import { Button } from '../ui/button';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface CharacterDevelopmentFooterProps {
  onBack: () => void;
  onNext: () => void;
  canProceed: boolean;
}

const CharacterDevelopmentFooter: React.FC<CharacterDevelopmentFooterProps> = ({
  onBack,
  onNext,
  canProceed
}) => {
  const { t, isRTL } = useLanguage();

  return (
    <div className={`flex items-center justify-between mt-8 pt-6 border-t border-script-slate-200 ${isRTL ? 'space-x-reverse' : ''}`}>
      <Button 
        variant="outline" 
        onClick={onBack}
        className="flex items-center gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Structure
      </Button>
      
      <div className="text-center">
        {!canProceed && (
          <p className="text-sm text-amber-600 mb-2">
            Please enter a script title and add at least one character to continue
          </p>
        )}
      </div>
      
      <Button 
        onClick={onNext}
        disabled={!canProceed}
        className="bg-script-blue-500 hover:bg-script-blue-600 disabled:opacity-50 flex items-center gap-2"
      >
        Continue to Script
        <ArrowRight className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default CharacterDevelopmentFooter;
