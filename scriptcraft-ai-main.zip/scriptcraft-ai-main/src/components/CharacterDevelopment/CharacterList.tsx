
import React from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Plus, Users, Trash2 } from 'lucide-react';
import { Character } from '../../types/project';

interface CharacterListProps {
  characters: Character[];
  selectedCharacter: string | null;
  onSelectCharacter: (id: string) => void;
  onAddCharacter: () => void;
  onDeleteCharacter: (id: string) => void;
}

const CharacterList: React.FC<CharacterListProps> = ({
  characters,
  selectedCharacter,
  onSelectCharacter,
  onAddCharacter,
  onDeleteCharacter
}) => {
  const roleColors = {
    protagonist: 'bg-green-100 text-green-800',
    antagonist: 'bg-red-100 text-red-800',
    supporting: 'bg-blue-100 text-blue-800',
    minor: 'bg-gray-100 text-gray-800'
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-script-slate-200 p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center">
          <Users className="h-4 w-4 mr-2" />
          Characters
        </h3>
        <Button size="sm" variant="outline" onClick={onAddCharacter}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="space-y-2">
        {characters.map((character) => (
          <div
            key={character.id}
            className={`p-3 rounded border cursor-pointer transition-colors ${
              selectedCharacter === character.id 
                ? 'bg-script-blue-50 border-script-blue-200' 
                : 'bg-script-slate-50 border-script-slate-200 hover:bg-script-slate-100'
            }`}
            onClick={() => onSelectCharacter(character.id)}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="font-medium">{character.name || 'Unnamed Character'}</h4>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge className={`text-xs ${roleColors[character.role]}`}>
                    {character.role}
                  </Badge>
                  {character.age && (
                    <span className="text-xs text-script-slate-500">Age {character.age}</span>
                  )}
                  {character.gender && (
                    <span className="text-xs text-script-slate-500">{character.gender}</span>
                  )}
                </div>
              </div>
              {characters.length > 1 && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteCharacter(character.id);
                  }}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CharacterList;
