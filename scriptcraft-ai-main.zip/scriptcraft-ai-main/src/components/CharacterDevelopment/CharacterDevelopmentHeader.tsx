
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Wand2 } from 'lucide-react';

interface CharacterDevelopmentHeaderProps {
  isGenerating: boolean;
  onGenerateCharacters: () => void;
}

const CharacterDevelopmentHeader: React.FC<CharacterDevelopmentHeaderProps> = ({
  isGenerating,
  onGenerateCharacters
}) => {
  const { t, isRTL } = useLanguage();

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">{t('characterDevelopment')}</h1>
          <p className="text-script-slate-600">Create and develop your story's characters</p>
        </div>
        <Badge variant="secondary">{t('phaseThreeOfFour')}</Badge>
      </div>
      
      <Button 
        onClick={onGenerateCharacters}
        disabled={isGenerating}
        className="bg-script-blue-500 hover:bg-script-blue-600"
      >
        <Wand2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
        {isGenerating ? 'Generating...' : 'Generate Character Suggestions'}
      </Button>
    </div>
  );
};

export default CharacterDevelopmentHeader;
