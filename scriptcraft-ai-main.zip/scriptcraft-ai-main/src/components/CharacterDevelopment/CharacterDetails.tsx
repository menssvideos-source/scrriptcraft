
import React from 'react';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Character } from '../../types/project';

interface CharacterDetailsProps {
  character: Character;
  onUpdateCharacter: (id: string, updates: Partial<Character>) => void;
}

const CharacterDetails: React.FC<CharacterDetailsProps> = ({
  character,
  onUpdateCharacter
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-script-slate-200 p-6">
      <h3 className="font-semibold mb-4">Character Details</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <Input
            value={character.name}
            onChange={(e) => onUpdateCharacter(character.id, { name: e.target.value })}
            placeholder="Character name"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium mb-1">Age</label>
            <Input
              type="number"
              value={character.age || ''}
              onChange={(e) => onUpdateCharacter(character.id, { age: e.target.value ? parseInt(e.target.value) : undefined })}
              placeholder="Age"
              min="1"
              max="150"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Gender</label>
            <Select
              value={character.gender || ''}
              onValueChange={(value) => onUpdateCharacter(character.id, { gender: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Male">Male</SelectItem>
                <SelectItem value="Female">Female</SelectItem>
                <SelectItem value="Non-binary">Non-binary</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
                <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Role</label>
          <Select
            value={character.role}
            onValueChange={(value: any) => onUpdateCharacter(character.id, { role: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="protagonist">Protagonist</SelectItem>
              <SelectItem value="antagonist">Antagonist</SelectItem>
              <SelectItem value="supporting">Supporting</SelectItem>
              <SelectItem value="minor">Minor</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Physical Description</label>
          <Textarea
            value={character.physicalDescription || ''}
            onChange={(e) => onUpdateCharacter(character.id, { physicalDescription: e.target.value })}
            placeholder="Height, build, hair color, eye color, distinctive features, clothing style..."
            rows={3}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Personality & Background</label>
          <Textarea
            value={character.description}
            onChange={(e) => onUpdateCharacter(character.id, { description: e.target.value })}
            placeholder="Describe the character's personality, motivations, background, and key traits..."
            rows={3}
          />
        </div>
      </div>
    </div>
  );
};

export default CharacterDetails;
