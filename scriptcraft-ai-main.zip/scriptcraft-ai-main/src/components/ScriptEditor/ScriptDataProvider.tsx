
import React, { createContext, useContext, ReactNode, useMemo, useCallback } from 'react';
import { useScriptData } from '../../hooks/useScriptData';
import { useScriptUI } from '../../hooks/useScriptUI';
import { ScriptElement } from '../../types/script';
import { ProjectBrainstorm, ProjectStructure, Character } from '../../types/project';

interface ScriptDataContextType {
  // Script data
  script: any;
  elements: ScriptElement[];
  setElements: (elements: ScriptElement[]) => void;
  loading: boolean;
  saving: boolean;
  error: string | null;
  
  // Workflow data - simplified to null/empty for now
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  
  // Title management
  scriptTitle: string;
  setScriptTitle: (title: string) => void;
  isSavingTitle: boolean;
  titleSaved: boolean;
  saveError: string | null;
  handleTitleSave: (title: string) => Promise<void>;
  
  // UI state
  activeElement: string;
  setActiveElement: (id: string) => void;
  hasMultipleScenes: boolean;
  
  // Actions
  handleSaveScript: () => Promise<void>;
}

const ScriptDataContext = createContext<ScriptDataContextType | undefined>(undefined);

interface ScriptDataProviderProps {
  scriptId: string;
  children: ReactNode;
}

export const ScriptDataProvider: React.FC<ScriptDataProviderProps> = ({ scriptId, children }) => {
  const scriptData = useScriptData(scriptId);
  const uiState = useScriptUI(scriptData.elements);

  // ✅ Memoize the context value to prevent unnecessary re-renders
  const contextValue = useMemo<ScriptDataContextType>(() => ({
    // Script data
    script: scriptData.script,
    elements: scriptData.elements,
    setElements: scriptData.setElements,
    loading: scriptData.loading,
    saving: scriptData.saving,
    error: scriptData.error,
    
    // Workflow data - simplified to null/empty for now
    brainstorm: null,
    structure: null,
    characters: [],
    
    // Title management
    scriptTitle: scriptData.scriptTitle,
    setScriptTitle: scriptData.setScriptTitle,
    isSavingTitle: scriptData.isSavingTitle,
    titleSaved: scriptData.titleSaved,
    saveError: scriptData.saveError,
    handleTitleSave: scriptData.handleTitleSave,
    
    // UI state
    activeElement: uiState.activeElement,
    setActiveElement: uiState.setActiveElement,
    hasMultipleScenes: uiState.hasMultipleScenes,
    
    // Actions
    handleSaveScript: scriptData.handleSaveScript
  }), [
    scriptData.script,
    scriptData.elements,
    scriptData.setElements,
    scriptData.loading,
    scriptData.saving,
    scriptData.error,
    scriptData.scriptTitle,
    scriptData.setScriptTitle,
    scriptData.isSavingTitle,
    scriptData.titleSaved,
    scriptData.saveError,
    scriptData.handleTitleSave,
    scriptData.handleSaveScript,
    uiState.activeElement,
    uiState.setActiveElement,
    uiState.hasMultipleScenes
  ]);

  return (
    <ScriptDataContext.Provider value={contextValue}>
      {children}
    </ScriptDataContext.Provider>
  );
};

export const useScriptDataContext = (): ScriptDataContextType => {
  const context = useContext(ScriptDataContext);
  if (!context) {
    throw new Error('useScriptDataContext must be used within a ScriptDataProvider');
  }
  return context;
};
