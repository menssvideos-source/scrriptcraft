
import React, { useState, useRef, useCallback, memo } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Edit2, Save, Check, AlertCircle } from 'lucide-react';

interface ScriptTitleEditorProps {
  scriptTitle: string;
  setScriptTitle: (title: string) => void;
  onTitleSave: (title: string) => Promise<void>;
  isSavingTitle: boolean;
  titleSaved: boolean;
  script?: any;
}

const ScriptTitleEditor: React.FC<ScriptTitleEditorProps> = memo(({
  scriptTitle,
  setScriptTitle,
  onTitleSave,
  isSavingTitle,
  titleSaved,
  script
}) => {
  const { t } = useLanguage();
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [tempTitle, setTempTitle] = useState(scriptTitle || '');
  const [saveError, setSaveError] = useState<string | null>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);

  // Update temp title when script title changes - memoized
  React.useEffect(() => {
    setTempTitle(scriptTitle || '');
  }, [scriptTitle]);

  const handleTitleEdit = useCallback(() => {
    console.log('ScriptTitleEditor: Starting title edit');
    setTempTitle(scriptTitle || '');
    setIsEditingTitle(true);
    setSaveError(null);
    
    // Use setTimeout to ensure the input is rendered before focusing
    setTimeout(() => {
      titleInputRef.current?.focus();
      titleInputRef.current?.select();
    }, 0);
  }, [scriptTitle]);

  const handleTitleSave = useCallback(async () => {
    console.log('ScriptTitleEditor: Attempting to save title:', tempTitle.trim());
    setIsEditingTitle(false);
    setSaveError(null);
    
    const trimmedTitle = tempTitle.trim();
    if (trimmedTitle && trimmedTitle !== scriptTitle) {
      try {
        setScriptTitle(trimmedTitle);
        await onTitleSave(trimmedTitle);
        console.log('ScriptTitleEditor: Title saved successfully');
      } catch (error) {
        console.error('ScriptTitleEditor: Error saving title:', error);
        setSaveError('Failed to save title. Please try again.');
        // Revert the title if save failed
        setScriptTitle(scriptTitle || '');
        setTempTitle(scriptTitle || '');
      }
    } else if (!trimmedTitle) {
      // Handle empty title case
      setTempTitle(scriptTitle || '');
    }
  }, [tempTitle, scriptTitle, setScriptTitle, onTitleSave]);

  const handleTitleCancel = useCallback(() => {
    console.log('ScriptTitleEditor: Cancelling title edit');
    setTempTitle(scriptTitle || '');
    setIsEditingTitle(false);
    setSaveError(null);
  }, [scriptTitle]);

  const handleTitleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleTitleSave();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      handleTitleCancel();
    }
  }, [handleTitleSave, handleTitleCancel]);

  const handleTempTitleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setTempTitle(e.target.value);
  }, []);

  // Memoize display title to avoid recalculation
  const displayTitle = React.useMemo(() => {
    return scriptTitle && scriptTitle.trim() !== '' ? scriptTitle.toUpperCase() : 'UNTITLED SCRIPT';
  }, [scriptTitle]);

  return (
    <div className="relative group">
      {isEditingTitle ? (
        <div className="flex items-center justify-center gap-2 mb-2">
          <input
            ref={titleInputRef}
            type="text"
            value={tempTitle}
            onChange={handleTempTitleChange}
            onBlur={handleTitleSave}
            onKeyDown={handleTitleKeyPress}
            className="text-2xl sm:text-3xl font-bold text-center bg-transparent border-b-2 border-script-blue-500 focus:outline-none focus:border-script-blue-600 min-w-0 max-w-full px-2"
            placeholder="Enter script title..."
            disabled={isSavingTitle}
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={handleTitleSave}
            disabled={isSavingTitle}
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            {isSavingTitle ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-script-blue-600"></div>
            ) : titleSaved ? (
              <Check className="h-4 w-4 text-green-600" />
            ) : (
              <Save className="h-4 w-4" />
            )}
          </Button>
        </div>
      ) : (
        <div 
          className="cursor-pointer hover:bg-script-slate-50 rounded-lg p-2 transition-colors group"
          onClick={handleTitleEdit}
        >
          <h1 className="text-2xl sm:text-3xl font-bold mb-2">
            {displayTitle}
          </h1>
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1 text-script-slate-500 text-sm">
            <Edit2 className="h-3 w-3" />
            <span>Click to edit title</span>
          </div>
        </div>
      )}
      
      {saveError && (
        <div className="flex items-center justify-center gap-1 text-red-500 text-sm mt-2">
          <AlertCircle className="h-3 w-3" />
          <span>{saveError}</span>
        </div>
      )}
    </div>
  );
});

ScriptTitleEditor.displayName = 'ScriptTitleEditor';

export default ScriptTitleEditor;
