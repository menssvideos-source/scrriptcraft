
import React, { useCallback, useMemo, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Plus, Undo2, Redo2 } from 'lucide-react';
import { useScriptUndo } from '../../hooks/useScriptUndo';
import { useDebouncedSave } from '../../hooks/useDebouncedSave';
import OptimizedScriptElementEditor from './OptimizedScriptElementEditor';
import { ScriptElement } from '../../types/script';

interface OptimizedScriptElementsListProps {
  elements: ScriptElement[];
  setElements: (elements: ScriptElement[]) => void;
  activeElement: string;
  setActiveElement: (id: string) => void;
  addNewElement: () => void;
  saveScript: (elements: ScriptElement[]) => Promise<void>;
}

const OptimizedScriptElementsList: React.FC<OptimizedScriptElementsListProps> = ({
  elements,
  setElements,
  activeElement,
  setActiveElement,
  addNewElement,
  saveScript
}) => {
  const { t, isRTL } = useLanguage();
  const { saveState, undo, redo, canUndo, canRedo } = useScriptUndo(elements);

  // ✅ Debounced auto-save with error handling
  const { debouncedSave, flushSave } = useDebouncedSave({
    delay: 2000,
    onSave: saveScript,
    onError: (error) => {
      console.error('Auto-save failed:', error);
      // You could show a toast notification here
    }
  });

  // ✅ Memoized element change handler
  const handleElementChange = useCallback((id: string, updates: Partial<ScriptElement>) => {
    const newElements = elements.map(el => 
      el.id === id ? { ...el, ...updates } : el
    );
    setElements(newElements);
    debouncedSave(newElements);
  }, [elements, setElements, debouncedSave]);

  // ✅ Memoized delete handler
  const handleDeleteElement = useCallback((elementId: string) => {
    saveState(elements, 'delete element');
    
    const newElements = elements.filter(el => el.id !== elementId);
    setElements(newElements);
    
    // Set active element to the next one or previous one
    const deletedIndex = elements.findIndex(el => el.id === elementId);
    if (newElements.length > 0) {
      const nextElement = newElements[deletedIndex] || newElements[deletedIndex - 1];
      if (nextElement) {
        setActiveElement(nextElement.id);
      }
    }
    
    debouncedSave(newElements);
  }, [elements, setElements, setActiveElement, saveState, debouncedSave]);

  // ✅ Memoized duplicate handler
  const handleDuplicateElement = useCallback((elementId: string) => {
    saveState(elements, 'duplicate element');
    
    const elementToDuplicate = elements.find(el => el.id === elementId);
    if (!elementToDuplicate) return;
    
    const newElement: ScriptElement = {
      ...elementToDuplicate,
      id: crypto.randomUUID(),
    };
    
    const elementIndex = elements.findIndex(el => el.id === elementId);
    const newElements = [
      ...elements.slice(0, elementIndex + 1),
      newElement,
      ...elements.slice(elementIndex + 1)
    ];
    
    setElements(newElements);
    setActiveElement(newElement.id);
    debouncedSave(newElements);
  }, [elements, setElements, setActiveElement, saveState, debouncedSave]);

  // ✅ Memoized move handler
  const handleMoveElement = useCallback((elementId: string, direction: 'up' | 'down') => {
    saveState(elements, `move element ${direction}`);
    
    const elementIndex = elements.findIndex(el => el.id === elementId);
    if (elementIndex === -1) return;
    
    const newIndex = direction === 'up' ? elementIndex - 1 : elementIndex + 1;
    if (newIndex < 0 || newIndex >= elements.length) return;
    
    const newElements = [...elements];
    [newElements[elementIndex], newElements[newIndex]] = [newElements[newIndex], newElements[elementIndex]];
    
    setElements(newElements);
    debouncedSave(newElements);
  }, [elements, setElements, saveState, debouncedSave]);

  // ✅ Memoized undo/redo handlers
  const handleUndo = useCallback(async () => {
    const previousElements = undo();
    if (previousElements) {
      setElements(previousElements);
      await flushSave(previousElements);
    }
  }, [undo, setElements, flushSave]);

  const handleRedo = useCallback(async () => {
    const nextElements = redo();
    if (nextElements) {
      setElements(nextElements);
      await flushSave(nextElements);
    }
  }, [redo, setElements, flushSave]);

  // ✅ Memoized add new element handler
  const handleAddNewElementWithUndo = useCallback(() => {
    saveState(elements, 'add new element');
    addNewElement();
  }, [saveState, elements, addNewElement]);

  // ✅ Flush save on unmount
  useEffect(() => {
    return () => {
      flushSave(elements);
    };
  }, [elements, flushSave]);

  // ✅ Memoized rendered elements to prevent unnecessary re-renders
  const renderedElements = useMemo(() => {
    return elements.map((element) => (
      <OptimizedScriptElementEditor
        key={element.id}
        element={element}
        isActive={activeElement === element.id}
        onElementChange={handleElementChange}
        onSetActive={setActiveElement}
        onDeleteElement={handleDeleteElement}
        onDuplicateElement={handleDuplicateElement}
        onMoveElement={handleMoveElement}
      />
    ));
  }, [
    elements,
    activeElement,
    handleElementChange,
    setActiveElement,
    handleDeleteElement,
    handleDuplicateElement,
    handleMoveElement
  ]);

  return (
    <div className="space-y-3 sm:space-y-4 font-mono text-xs sm:text-sm leading-relaxed">
      {/* Undo/Redo Controls */}
      <div className={`flex items-center gap-2 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Button
          variant="outline"
          size="sm"
          onClick={handleUndo}
          disabled={!canUndo}
          className="flex items-center gap-1 transition-all duration-200 hover:scale-105"
          aria-label="Undo last action"
        >
          <Undo2 className="h-3 w-3" />
          Undo
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRedo}
          disabled={!canRedo}
          className="flex items-center gap-1 transition-all duration-200 hover:scale-105"
          aria-label="Redo last action"
        >
          <Redo2 className="h-3 w-3" />
          Redo
        </Button>
      </div>

      {renderedElements}
      
      {/* Add New Element Button */}
      <div className="text-center py-4">
        <Button 
          variant="ghost" 
          onClick={handleAddNewElementWithUndo} 
          className="text-script-slate-500 transition-all duration-200 hover:scale-105"
          aria-label="Add new script element"
        >
          <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('addNewElement')}
        </Button>
      </div>
    </div>
  );
};

export default OptimizedScriptElementsList;
