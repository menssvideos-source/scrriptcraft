
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { RefreshCw, AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
}

class ScriptErrorBoundaryClass extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Script Editor Error:', error, errorInfo);
    this.setState({
      error,
      errorInfo
    });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return <ScriptErrorFallback error={this.state.error} onRetry={this.handleRetry} />;
    }

    return this.props.children;
  }
}

interface ErrorFallbackProps {
  error?: Error;
  onRetry: () => void;
}

const ScriptErrorFallback: React.FC<ErrorFallbackProps> = ({ error, onRetry }) => {
  const { isRTL } = useLanguage();

  return (
    <div className={`flex-1 bg-white ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center p-fluid-md`}>
      <div className="text-center max-w-md">
        <div className="flex justify-center mb-4">
          <AlertTriangle className="h-12 w-12 text-red-500" />
        </div>
        <h2 className="text-fluid-lg font-semibold text-script-slate-900 mb-2">
          Script Editor Error
        </h2>
        <p className="text-script-slate-600 mb-4 text-fluid-sm">
          Something went wrong while loading the script editor. This might be a temporary issue.
        </p>
        {error && (
          <details className="mb-4 text-left">
            <summary className="cursor-pointer text-script-slate-500 text-xs mb-2">
              Technical Details
            </summary>
            <pre className="text-xs bg-script-slate-100 p-2 rounded overflow-auto max-h-32">
              {error.message}
            </pre>
          </details>
        )}
        <div className="space-y-2">
          <Button onClick={onRetry} className="w-full">
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
          <Button 
            variant="outline" 
            onClick={() => window.location.reload()}
            className="w-full"
          >
            Reload Page
          </Button>
        </div>
      </div>
    </div>
  );
};

export const ScriptErrorBoundary: React.FC<Props> = ({ children, fallback }) => {
  return (
    <ScriptErrorBoundaryClass fallback={fallback}>
      {children}
    </ScriptErrorBoundaryClass>
  );
};

export default ScriptErrorBoundary;
