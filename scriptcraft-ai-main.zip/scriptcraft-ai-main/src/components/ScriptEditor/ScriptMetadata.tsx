
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { supabase } from '../../integrations/supabase/client';

interface ScriptMetadataProps {
  userProfile?: any;
}

const ScriptMetadata: React.FC<ScriptMetadataProps> = ({ userProfile }) => {
  const { t } = useLanguage();

  // Get author name
  const getAuthorName = () => {
    if (userProfile?.full_name) {
      return userProfile.full_name;
    }
    return 'Anonymous Writer';
  };

  // Get current date in a nice format
  const getCurrentDate = () => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long'
    };
    return now.toLocaleDateString('en-US', options);
  };

  return (
    <>
      <p className="text-script-slate-600 mb-4">{t('writtenBy')}</p>
      <p className="text-base sm:text-lg font-semibold">{getAuthorName()}</p>
      <div className="mt-6 sm:mt-8 text-xs sm:text-sm text-script-slate-500">
        <p>{t('firstDraft')}</p>
        <p>{getCurrentDate()}</p>
      </div>
    </>
  );
};

export default ScriptMetadata;
