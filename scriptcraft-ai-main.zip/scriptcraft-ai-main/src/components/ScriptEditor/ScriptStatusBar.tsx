
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Check, Loader, Save } from 'lucide-react';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

interface ScriptStatusBarProps {
  saving?: boolean;
  elements?: ScriptElement[];
  error?: string | null;
  onManualSave?: () => void;
}

const ScriptStatusBar: React.FC<ScriptStatusBarProps> = ({ 
  saving = false, 
  elements = [],
  error = null,
  onManualSave
}) => {
  const { t, isRTL } = useLanguage();

  // Calculate real-time statistics with improved logic
  const sceneCount = elements.filter(el => 
    el.type === 'scene-heading' && 
    el.content.trim() && 
    !el.content.toUpperCase().includes('FADE')
  ).length;

  const wordCount = elements
    .filter(el => el.content.trim())
    .reduce((total, el) => {
      const words = el.content.trim().split(/\s+/).filter(word => word.length > 0);
      return total + words.length;
    }, 0);

  // Industry standard calculation with scene consideration
  const basePageCount = Math.ceil(wordCount / 250);
  const sceneBasedPages = Math.ceil(sceneCount / 2); // Rough estimate: 2 scenes per page
  const pageCount = Math.max(1, Math.max(basePageCount, sceneBasedPages));

  // Character count for dialogue
  const dialogueElements = elements.filter(el => el.type === 'dialogue');
  const dialogueWordCount = dialogueElements.reduce((total, el) => {
    return total + el.content.trim().split(/\s+/).filter(word => word.length > 0).length;
  }, 0);

  // Estimated reading time (250 words per minute)
  const readingTime = Math.ceil(wordCount / 250);

  // Action vs dialogue ratio
  const actionElements = elements.filter(el => el.type === 'action');
  const actionWordCount = actionElements.reduce((total, el) => {
    return total + el.content.trim().split(/\s+/).filter(word => word.length > 0).length;
  }, 0);

  const getScriptLengthStatus = () => {
    // More nuanced status based on both pages and scenes
    if (pageCount < 10 && sceneCount < 5) return { status: 'very-short', color: 'text-gray-600' };
    if (pageCount < 90) return { status: 'short', color: 'text-yellow-600' };
    if (pageCount > 120) return { status: 'long', color: 'text-red-600' };
    return { status: 'good', color: 'text-green-600' };
  };

  const lengthStatus = getScriptLengthStatus();

  const getBalanceText = () => {
    if (wordCount === 0) return 'No content yet';
    
    const dialogueRatio = Math.round((dialogueWordCount / wordCount) * 100);
    const actionRatio = Math.round((actionWordCount / wordCount) * 100);
    
    if (dialogueRatio > 70) return `${dialogueRatio}% dialogue (dialogue-heavy)`;
    if (actionRatio > 70) return `${actionRatio}% action (action-heavy)`;
    return `${dialogueRatio}% dialogue, ${actionRatio}% action`;
  };

  const getSaveStatus = () => {
    if (error) {
      return {
        icon: <div className="w-2 h-2 rounded-full bg-red-500"></div>,
        text: 'Save failed',
        color: 'text-red-600'
      };
    }
    
    if (saving) {
      return {
        icon: <Loader className="w-3 h-3 animate-spin text-yellow-600" />,
        text: 'Saving...',
        color: 'text-yellow-600'
      };
    }
    
    return {
      icon: <Check className="w-3 h-3 text-green-600" />,
      text: 'Auto-saved',
      color: 'text-green-600'
    };
  };

  const saveStatus = getSaveStatus();

  return (
    <div className="border-t border-script-slate-200 px-4 py-2 bg-script-slate-50">
      <div className={`flex items-center justify-between text-xs text-script-slate-500 ${isRTL ? 'space-x-reverse' : ''}`}>
        <div className={`flex items-center space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
          <span className={lengthStatus.color}>
            {pageCount} {pageCount === 1 ? 'page' : 'pages'}
          </span>
          <span>
            {sceneCount} {sceneCount === 1 ? 'scene' : 'scenes'}
          </span>
          <span>
            {wordCount.toLocaleString()} words
          </span>
          <span className="hidden sm:inline">
            ~{readingTime} min read
          </span>
        </div>
        
        <div className={`flex items-center space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
          <span className="hidden md:inline">
            {getBalanceText()}
          </span>
          
          {/* Enhanced Save Status with Manual Save Button */}
          <div className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''}`}>
            {saveStatus.icon}
            <span className={saveStatus.color}>{saveStatus.text}</span>
            
            {/* Manual Save Button - visible when not auto-saving */}
            {!saving && onManualSave && (
              <button
                onClick={onManualSave}
                className="ml-2 p-1 hover:bg-script-slate-200 rounded transition-colors"
                title="Save manually"
              >
                <Save className="w-3 h-3 text-script-slate-600 hover:text-script-blue-600" />
              </button>
            )}
          </div>
        </div>
      </div>
      
      {pageCount > 0 && (
        <div className="mt-1 text-xs text-script-slate-400">
          {lengthStatus.status === 'very-short' && 'Just getting started'}
          {lengthStatus.status === 'short' && 'Feature scripts typically run 90-120 pages'}
          {lengthStatus.status === 'long' && 'Consider trimming - scripts over 120 pages may be too long'}
          {lengthStatus.status === 'good' && 'Good length for a feature screenplay'}
        </div>
      )}
      
      {/* Error Message Display */}
      {error && (
        <div className="mt-1 text-xs text-red-600">
          Error: {error}
        </div>
      )}
    </div>
  );
};

export default ScriptStatusBar;
