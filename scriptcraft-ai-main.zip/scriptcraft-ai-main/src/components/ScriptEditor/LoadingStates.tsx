
import React from 'react';
import { Skeleton } from '../ui/skeleton';
import { useLanguage } from '../../contexts/LanguageContext';

interface LoadingStatesProps {
  type: 'script' | 'elements' | 'title' | 'saving';
  message?: string;
}

export const ScriptLoadingState: React.FC = () => {
  const { isRTL } = useLanguage();
  
  return (
    <div className={`flex-1 bg-white ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center p-fluid-md`}>
      <div className="flex flex-col items-center space-y-4 max-w-md text-center">
        <div className="animate-spin rounded-full h-8 w-8 lg:h-10 lg:w-10 border-b-2 border-script-blue-600"></div>
        <div className="animate-pulse text-script-slate-500 text-fluid-base">Loading script...</div>
      </div>
    </div>
  );
};

export const ElementsLoadingState: React.FC = () => {
  return (
    <div className="space-y-4">
      <Skeleton className="h-8 w-3/4" />
      <Skeleton className="h-6 w-full" />
      <Skeleton className="h-6 w-5/6" />
      <Skeleton className="h-8 w-2/3" />
      <Skeleton className="h-6 w-full" />
      <Skeleton className="h-6 w-4/5" />
    </div>
  );
};

export const TitleLoadingState: React.FC = () => {
  return (
    <div className="text-center mb-8 sm:mb-12 pb-6 sm:pb-8 border-b border-script-slate-200">
      <Skeleton className="h-12 w-96 mx-auto mb-4" />
      <Skeleton className="h-4 w-48 mx-auto" />
    </div>
  );
};

export const SavingIndicator: React.FC<{ message?: string }> = ({ message = 'Saving...' }) => {
  return (
    <div className="fixed bottom-4 right-4 bg-script-blue-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center space-x-2 z-50">
      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
      <span className="text-sm">{message}</span>
    </div>
  );
};

const LoadingStates: React.FC<LoadingStatesProps> = ({ type, message }) => {
  switch (type) {
    case 'script':
      return <ScriptLoadingState />;
    case 'elements':
      return <ElementsLoadingState />;
    case 'title':
      return <TitleLoadingState />;
    case 'saving':
      return <SavingIndicator message={message} />;
    default:
      return <ScriptLoadingState />;
  }
};

export default LoadingStates;
