
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { ScriptLoadingState } from './LoadingStates';
import { AlertTriangle } from 'lucide-react';

interface ScriptEditorStatesProps {
  loading: boolean;
  error: string | null;
  scriptId?: string;
}

const ScriptEditorStates: React.FC<ScriptEditorStatesProps> = ({ loading, error, scriptId }) => {
  const { isRTL } = useLanguage();

  if (!scriptId) {
    return (
      <div className={`flex-1 bg-white ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center p-fluid-md`}>
        <div className="text-script-slate-500 text-center max-w-md">
          <div className="text-fluid-lg mb-2">No script ID provided</div>
          <div className="text-fluid-sm">Please select a script to edit</div>
        </div>
      </div>
    );
  }

  if (loading) {
    return <ScriptLoadingState />;
  }

  if (error) {
    return (
      <div className={`flex-1 bg-white ${isRTL ? 'font-arabic' : 'font-script'} flex items-center justify-center p-fluid-md`}>
        <div className="text-center max-w-md">
          <div className="flex justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <div className="text-red-500 mb-4 text-fluid-lg font-medium">Error loading script</div>
          <div className="text-script-slate-500 text-fluid-sm break-words">{error}</div>
        </div>
      </div>
    );
  }

  return null;
};

export default ScriptEditorStates;
