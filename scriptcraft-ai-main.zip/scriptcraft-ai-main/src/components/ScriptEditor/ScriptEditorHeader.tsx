
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Info,
  Wand2,
  Save,
  PanelLeftOpen,
  PanelLeftClose
} from 'lucide-react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../../types/project';

interface ScriptEditorHeaderProps {
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  scriptTitle: string;
  showProjectInfo: boolean;
  setShowProjectInfo: (show: boolean) => void;
  showSceneGenerator: boolean;
  setShowSceneGenerator: (show: boolean) => void;
  isGenerating: boolean;
  generateFirstScene: () => void;
  saveScript: () => Promise<void>;
  hasMultipleScenes: boolean;
  elementsLength: number;
  saving: boolean;
  showSidebar: boolean;
  setShowSidebar: (show: boolean) => void;
}

const ScriptEditorHeader: React.FC<ScriptEditorHeaderProps> = ({
  brainstorm,
  structure,
  characters,
  scriptTitle,
  showProjectInfo,
  setShowProjectInfo,
  showSceneGenerator,
  setShowSceneGenerator,
  isGenerating,
  generateFirstScene,
  saveScript,
  hasMultipleScenes,
  elementsLength,
  saving,
  showSidebar,
  setShowSidebar
}) => {
  const { t, isRTL } = useLanguage();

  const hasWorkflowData = brainstorm || structure || (characters && characters.length > 0);
  const canGenerateScene = hasWorkflowData && !isGenerating;

  return (
    <div className="bg-white border-b border-script-slate-200 px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {/* Sidebar Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSidebar(!showSidebar)}
            className="text-script-slate-600 hover:text-script-slate-900"
          >
            {showSidebar ? (
              <PanelLeftClose className="h-4 w-4" />
            ) : (
              <PanelLeftOpen className="h-4 w-4" />
            )}
          </Button>

          {/* Project Info Button */}
          {hasWorkflowData && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowProjectInfo(!showProjectInfo)}
              className={`text-script-slate-600 hover:text-script-slate-900 ${showProjectInfo ? 'bg-script-slate-100' : ''}`}
            >
              <Info className="h-4 w-4 mr-2" />
              Project Info
            </Button>
          )}

          {/* Scene Generator Button */}
          {canGenerateScene && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSceneGenerator(!showSceneGenerator)}
              className={`text-script-blue-600 hover:text-script-blue-700 ${showSceneGenerator ? 'bg-script-blue-50' : ''}`}
            >
              <Wand2 className="h-4 w-4 mr-2" />
              AI Scene Generator
            </Button>
          )}

          {/* Generate First Scene for Empty Scripts */}
          {canGenerateScene && elementsLength === 0 && (
            <Button
              size="sm"
              onClick={generateFirstScene}
              disabled={isGenerating}
              className="bg-script-blue-600 hover:bg-script-blue-700 text-white"
            >
              <Wand2 className="h-4 w-4 mr-2" />
              {isGenerating ? 'Generating...' : 'Generate Opening Scene'}
            </Button>
          )}
        </div>

        <div className="flex items-center space-x-3">
          {/* Workflow Status Badges */}
          {brainstorm && (
            <Badge variant="secondary" className="bg-green-100 text-green-700">
              Story Foundation Complete
            </Badge>
          )}
          
          {structure && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              Structure Planned
            </Badge>
          )}
          
          {characters && characters.length > 0 && (
            <Badge variant="secondary" className="bg-purple-100 text-purple-700">
              {characters.length} Character{characters.length !== 1 ? 's' : ''} Developed
            </Badge>
          )}

          {/* Save Button */}
          <Button
            size="sm"
            onClick={saveScript}
            disabled={saving}
            className="bg-script-blue-600 hover:bg-script-blue-700 text-white"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ScriptEditorHeader;
