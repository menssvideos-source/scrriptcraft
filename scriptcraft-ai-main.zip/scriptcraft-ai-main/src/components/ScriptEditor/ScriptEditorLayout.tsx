
import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import ScriptEditorHeader from './ScriptEditorHeader';
import SceneGenerator from '../SceneGenerator';
import ProjectInfoPanel from '../ProjectInfoPanel';
import ScriptContent from '../ScriptContent';
import ScriptStatusBar from './ScriptStatusBar';
import ScriptSidebar from '../ScriptSidebar';
import { ProjectBrainstorm, ProjectStructure, Character } from '../../types/project';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

interface ScriptEditorLayoutProps {
  scriptId: string;
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  elements: ScriptElement[];
  setElements: (elements: ScriptElement[]) => void;
  activeElement: string;
  setActiveElement: (id: string) => void;
  showProjectInfo: boolean;
  setShowProjectInfo: (show: boolean) => void;
  showSceneGenerator: boolean;
  setShowSceneGenerator: (show: boolean) => void;
  isGenerating: boolean;
  selectedSceneType: string | null;
  setSelectedSceneType: (type: string | null) => void;
  generateFirstScene: () => void;
  generateNextScene: () => void;
  handleSaveScript: () => Promise<void>;
  handleAddNewElement: () => void;
  handleInsertCharacterName: (name: string) => void;
  hasMultipleScenes: boolean;
  saving: boolean;
  isSavingTitle: boolean;
  script: any;
  scriptTitle: string;
  setScriptTitle: (title: string) => void;
  onTitleSave: (newTitle: string) => Promise<void>;
  titleSaved: boolean;
  showSidebar: boolean;
  setShowSidebar: (show: boolean) => void;
  onDownloadScript: () => void;
}

const ScriptEditorLayout: React.FC<ScriptEditorLayoutProps> = ({
  scriptId,
  brainstorm,
  structure,
  characters,
  elements,
  setElements,
  activeElement,
  setActiveElement,
  showProjectInfo,
  setShowProjectInfo,
  showSceneGenerator,
  setShowSceneGenerator,
  isGenerating,
  selectedSceneType,
  setSelectedSceneType,
  generateFirstScene,
  generateNextScene,
  handleSaveScript,
  handleAddNewElement,
  handleInsertCharacterName,
  hasMultipleScenes,
  saving,
  isSavingTitle,
  script,
  scriptTitle,
  setScriptTitle,
  onTitleSave,
  titleSaved,
  showSidebar,
  setShowSidebar,
  onDownloadScript
}) => {
  const { isRTL } = useLanguage();

  return (
    <div className={`flex-1 ${isRTL ? 'font-arabic' : 'font-script'} flex min-h-0`}>
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-80 flex-shrink-0">
          <ScriptSidebar
            scriptId={scriptId}
            elements={elements}
            brainstorm={brainstorm}
            structure={structure}
            characters={characters}
            currentSceneIndex={0}
            currentAct={1}
            actProgress={0}
            onSceneJump={() => {}}
            onCharacterInsert={handleInsertCharacterName}
            onSaveScript={handleSaveScript}
            onDownloadScript={onDownloadScript}
            saving={saving}
          />
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 bg-white flex flex-col min-h-0">
        <div className="flex-shrink-0">
          <ScriptEditorHeader
            brainstorm={brainstorm}
            structure={structure}
            characters={characters}
            scriptTitle={scriptTitle}
            showProjectInfo={showProjectInfo}
            setShowProjectInfo={setShowProjectInfo}
            showSceneGenerator={showSceneGenerator}
            setShowSceneGenerator={setShowSceneGenerator}
            isGenerating={isGenerating}
            generateFirstScene={generateFirstScene}
            saveScript={handleSaveScript}
            hasMultipleScenes={hasMultipleScenes}
            elementsLength={elements.length}
            saving={saving}
            showSidebar={showSidebar}
            setShowSidebar={setShowSidebar}
          />

          <SceneGenerator
            showSceneGenerator={showSceneGenerator}
            selectedSceneType={selectedSceneType}
            setSelectedSceneType={setSelectedSceneType}
            isGenerating={isGenerating}
            generateNextScene={generateNextScene}
            setShowSceneGenerator={setShowSceneGenerator}
          />

          <ProjectInfoPanel
            showProjectInfo={showProjectInfo}
            brainstorm={brainstorm}
            structure={structure}
            characters={characters}
            insertCharacterName={handleInsertCharacterName}
          />
        </div>

        <div className="flex-1 min-h-0">
          <ScriptContent
            brainstorm={brainstorm}
            elements={elements}
            setElements={setElements}
            activeElement={activeElement}
            setActiveElement={setActiveElement}
            addNewElement={handleAddNewElement}
            saveScript={handleSaveScript}
            script={script}
            scriptTitle={scriptTitle}
            setScriptTitle={setScriptTitle}
            onTitleSave={onTitleSave}
            isSavingTitle={isSavingTitle}
            titleSaved={titleSaved}
          />
        </div>

        <div className="flex-shrink-0">
          <ScriptStatusBar saving={saving || isSavingTitle} elements={elements} />
        </div>
      </div>
    </div>
  );
};

export default ScriptEditorLayout;
