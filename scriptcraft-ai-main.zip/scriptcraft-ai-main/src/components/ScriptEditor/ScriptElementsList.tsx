import React, { useEffect, useCallback, memo, useMemo } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Plus, Undo2, Redo2 } from 'lucide-react';
import { useScriptUndo } from '../../hooks/useScriptUndo';
import ScriptElementEditor from './ScriptElementEditor';
import { ScriptElement } from '../../types/script';

interface ScriptElementsListProps {
  elements: ScriptElement[];
  setElements: (elements: ScriptElement[]) => void;
  activeElement: string;
  setActiveElement: (id: string) => void;
  addNewElement: () => void;
  saveScript: (elements: ScriptElement[]) => Promise<void>;
}

const ScriptElementsList: React.FC<ScriptElementsListProps> = memo(({
  elements,
  setElements,
  activeElement,
  setActiveElement,
  addNewElement,
  saveScript
}) => {
  const { t, isRTL } = useLanguage();
  const { saveState, undo, redo, canUndo, canRedo } = useScriptUndo(elements);

  // Memoize element change handler to prevent unnecessary re-renders
  const handleElementChange = useCallback((updatedElement: ScriptElement) => {
    setElements(elements.map(el => 
      el.id === updatedElement.id ? updatedElement : el
    ));
  }, [elements, setElements]);

  // Memoize delete handler
  const handleDeleteElement = useCallback((elementId: string) => {
    saveState(elements, 'delete element');
    
    const newElements = elements.filter(el => el.id !== elementId);
    setElements(newElements);
    
    // Set active element to the next one or previous one
    const deletedIndex = elements.findIndex(el => el.id === elementId);
    if (newElements.length > 0) {
      const nextElement = newElements[deletedIndex] || newElements[deletedIndex - 1];
      if (nextElement) {
        setActiveElement(nextElement.id);
      }
    }
  }, [elements, setElements, setActiveElement, saveState]);

  // Memoize duplicate handler
  const handleDuplicateElement = useCallback((elementId: string) => {
    saveState(elements, 'duplicate element');
    
    const elementToDuplicate = elements.find(el => el.id === elementId);
    if (!elementToDuplicate) return;
    
    const newElement: ScriptElement = {
      ...elementToDuplicate,
      id: crypto.randomUUID(),
    };
    
    const elementIndex = elements.findIndex(el => el.id === elementId);
    const newElements = [
      ...elements.slice(0, elementIndex + 1),
      newElement,
      ...elements.slice(elementIndex + 1)
    ];
    
    setElements(newElements);
    setActiveElement(newElement.id);
  }, [elements, setElements, setActiveElement, saveState]);

  // Memoize move handler
  const handleMoveElement = useCallback((elementId: string, direction: 'up' | 'down') => {
    saveState(elements, `move element ${direction}`);
    
    const elementIndex = elements.findIndex(el => el.id === elementId);
    if (elementIndex === -1) return;
    
    const newIndex = direction === 'up' ? elementIndex - 1 : elementIndex + 1;
    if (newIndex < 0 || newIndex >= elements.length) return;
    
    const newElements = [...elements];
    [newElements[elementIndex], newElements[newIndex]] = [newElements[newIndex], newElements[elementIndex]];
    
    setElements(newElements);
  }, [elements, setElements, saveState]);

  // Memoize undo/redo handlers
  const handleUndo = useCallback(async () => {
    const previousElements = undo();
    if (previousElements) {
      setElements(previousElements);
      
      if (saveScript) {
        try {
          await saveScript(previousElements);
        } catch (error) {
          console.error('Failed to save after undo:', error);
        }
      }
    }
  }, [undo, setElements, saveScript]);

  const handleRedo = useCallback(async () => {
    const nextElements = redo();
    if (nextElements) {
      setElements(nextElements);
      
      if (saveScript) {
        try {
          await saveScript(nextElements);
        } catch (error) {
          console.error('Failed to save after redo:', error);
        }
      }
    }
  }, [redo, setElements, saveScript]);

  // Memoize add new element handler
  const handleAddNewElementWithUndo = useCallback(() => {
    saveState(elements, 'add new element');
    addNewElement();
  }, [saveState, elements, addNewElement]);

  // Memoized auto-save with proper cleanup
  useEffect(() => {
    if (elements.length === 0 || !saveScript) return;
    
    const timer = setTimeout(async () => {
      try {
        console.log('Auto-saving script with', elements.length, 'elements');
        await saveScript(elements);
        console.log('Auto-save completed successfully');
        saveState(elements, 'auto-save');
      } catch (error) {
        console.error('Auto-save failed:', error);
      }
    }, 1000);
    
    return () => {
      clearTimeout(timer);
    };
  }, [elements, saveScript, saveState]);

  // Memoize rendered elements to prevent unnecessary re-renders
  const renderedElements = useMemo(() => {
    return elements.map((element) => (
      <ScriptElementEditor
        key={element.id}
        element={element}
        isActive={activeElement === element.id}
        onElementChange={handleElementChange}
        onSetActive={setActiveElement}
        onDeleteElement={handleDeleteElement}
        onDuplicateElement={handleDuplicateElement}
        onMoveElement={handleMoveElement}
        allElements={elements}
      />
    ));
  }, [
    elements,
    activeElement,
    handleElementChange,
    setActiveElement,
    handleDeleteElement,
    handleDuplicateElement,
    handleMoveElement
  ]);

  return (
    <div className="space-y-3 sm:space-y-4 font-mono text-xs sm:text-sm leading-relaxed">
      {/* Undo/Redo Controls */}
      <div className={`flex items-center gap-2 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Button
          variant="outline"
          size="sm"
          onClick={handleUndo}
          disabled={!canUndo}
          className="flex items-center gap-1 transition-all duration-200 hover:scale-105"
          aria-label="Undo last action"
        >
          <Undo2 className="h-3 w-3" />
          Undo
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRedo}
          disabled={!canRedo}
          className="flex items-center gap-1 transition-all duration-200 hover:scale-105"
          aria-label="Redo last action"
        >
          <Redo2 className="h-3 w-3" />
          Redo
        </Button>
      </div>

      {renderedElements}
      
      {/* Add New Element Button */}
      <div className="text-center py-4">
        <Button 
          variant="ghost" 
          onClick={handleAddNewElementWithUndo} 
          className="text-script-slate-500 transition-all duration-200 hover:scale-105"
          aria-label="Add new script element"
        >
          <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('addNewElement')}
        </Button>
      </div>
    </div>
  );
});

ScriptElementsList.displayName = 'ScriptElementsList';

export default ScriptElementsList;
