
// Clean exports for ScriptEditor components
export { default as ScriptEditorCore } from './ScriptEditorCore';
export { default as ScriptEditorHeader } from './ScriptEditorHeader';
export { default as ScriptStatusBar } from './ScriptStatusBar';
export { default as ScriptEditorStates } from './ScriptEditorStates';
export { default as ScriptEditorLayout } from './ScriptEditorLayout';

// FIXED: Remove duplicate default export that was causing duplicate identifier error
export { default } from './ScriptEditorCore';
