
import React, { useCallback, memo } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Button } from '../ui/button';
import { X, Copy, ArrowUp, ArrowDown } from 'lucide-react';
import { useIsMobile } from '../../hooks/use-mobile';
import { ScriptElement } from '../../types/script';

interface OptimizedScriptElementEditorProps {
  element: ScriptElement;
  isActive: boolean;
  onElementChange: (id: string, updates: Partial<ScriptElement>) => void;
  onSetActive: (id: string) => void;
  onDeleteElement?: (id: string) => void;
  onDuplicateElement?: (id: string) => void;
  onMoveElement?: (id: string, direction: 'up' | 'down') => void;
}

const OptimizedScriptElementEditor = memo(({
  element,
  isActive,
  onElementChange,
  onSetActive,
  onDeleteElement,
  onDuplicateElement,
  onMoveElement
}: OptimizedScriptElementEditorProps) => {
  const { t, isRTL } = useLanguage();
  const isMobile = useIsMobile();

  const elementTypes = [
    { value: 'scene-heading', label: t('sceneHeading'), style: 'font-bold uppercase' },
    { value: 'action', label: t('action'), style: '' },
    { value: 'character', label: t('character'), style: 'font-semibold uppercase text-center' },
    { value: 'dialogue', label: t('dialogue'), style: 'ml-4 mr-4 sm:ml-8 sm:mr-8' },
    { value: 'parenthetical', label: t('parenthetical'), style: 'ml-6 mr-6 sm:ml-12 sm:mr-12 italic' },
    { value: 'transition', label: t('transition'), style: 'font-bold uppercase text-right' },
  ];

  // ✅ Memoized handlers to prevent parent re-renders
  const handleContentChange = useCallback((newContent: string) => {
    onElementChange(element.id, { content: newContent });
  }, [element.id, onElementChange]);

  const handleTypeChange = useCallback((newType: string) => {
    onElementChange(element.id, { type: newType as any });
  }, [element.id, onElementChange]);

  const handleSetActive = useCallback(() => {
    onSetActive(element.id);
  }, [element.id, onSetActive]);

  const handleDelete = useCallback(() => {
    onDeleteElement?.(element.id);
  }, [element.id, onDeleteElement]);

  const handleDuplicate = useCallback(() => {
    onDuplicateElement?.(element.id);
  }, [element.id, onDuplicateElement]);

  const handleMoveUp = useCallback(() => {
    onMoveElement?.(element.id, 'up');
  }, [element.id, onMoveElement]);

  const handleMoveDown = useCallback(() => {
    onMoveElement?.(element.id, 'down');
  }, [element.id, onMoveElement]);

  const getElementStyle = (type: string) => {
    const elementType = elementTypes.find(et => et.value === type);
    return elementType?.style || '';
  };

  const getPlaceholder = (type: string) => {
    switch (type) {
      case 'scene-heading':
        return t('enterSceneHeading');
      case 'action':
        return t('enterAction');
      case 'character':
        return t('enterCharacter');
      case 'dialogue':
        return t('enterDialogue');
      case 'parenthetical':
        return t('enterParenthetical');
      case 'transition':
        return t('enterTransition');
      default:
        return '';
    }
  };

  return (
    <div
      className={`group relative transition-all duration-200 ${isActive ? 'bg-script-blue-50 rounded-lg p-2' : 'p-2'} hover:bg-script-slate-50`}
      onClick={handleSetActive}
    >
      {/* Element Controls - Mobile */}
      {isActive && isMobile && (
        <div className="mb-2 flex items-center gap-2 animate-fade-in">
          <Select value={element.type} onValueChange={handleTypeChange}>
            <SelectTrigger className="h-8 text-xs flex-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {elementTypes.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {onDeleteElement && (
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleDelete();
              }}
              className="h-8 w-8 p-0 text-red-500 hover:text-red-700 transition-colors"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      {/* Element Controls - Desktop */}
      {isActive && !isMobile && (
        <>
          <div className="absolute -left-40 top-0 w-36 animate-fade-in">
            <Select value={element.type} onValueChange={handleTypeChange}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {elementTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="absolute -right-32 top-0 flex items-center gap-1">
            {onMoveElement && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleMoveUp();
                  }}
                  className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
                >
                  <ArrowUp className="h-3 w-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleMoveDown();
                  }}
                  className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
                >
                  <ArrowDown className="h-3 w-3" />
                </Button>
              </>
            )}
            
            {onDuplicateElement && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDuplicate();
                }}
                className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
              >
                <Copy className="h-3 w-3" />
              </Button>
            )}
            
            {onDeleteElement && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete();
                }}
                className="h-7 w-7 p-0 text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-all duration-200"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        </>
      )}

      {/* Editable Content */}
      <textarea
        value={element.content}
        onChange={(e) => handleContentChange(e.target.value)}
        className={`w-full bg-transparent border-none outline-none resize-none transition-all duration-200 ${getElementStyle(element.type)} ${
          isRTL ? 'text-right' : 'text-left'
        }`}
        style={{ minHeight: '1.5rem' }}
        placeholder={getPlaceholder(element.type)}
        rows={1}
        aria-label={`${element.type} element`}
      />
    </div>
  );
}, (prevProps, nextProps) => {
  // ✅ Custom comparison - only re-render if this specific element changed
  return (
    prevProps.element.id === nextProps.element.id &&
    prevProps.element.content === nextProps.element.content &&
    prevProps.element.type === nextProps.element.type &&
    prevProps.isActive === nextProps.isActive
  );
});

OptimizedScriptElementEditor.displayName = 'OptimizedScriptElementEditor';

export default OptimizedScriptElementEditor;
