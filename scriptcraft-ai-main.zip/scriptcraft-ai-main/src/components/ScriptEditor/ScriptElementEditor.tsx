import React, { useRef, useEffect, memo } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Button } from '../ui/button';
import { X, Copy, ArrowUp, ArrowDown } from 'lucide-react';
import { useIsMobile } from '../../hooks/use-mobile';
import { SceneNumbering } from '../../lib/sceneNumbering';
import { ScriptElement } from '../../types/script';

interface ScriptElementEditorProps {
  element: ScriptElement;
  isActive: boolean;
  onElementChange: (element: ScriptElement) => void;
  onSetActive: (id: string) => void;
  onDeleteElement?: (id: string) => void;
  onDuplicateElement?: (id: string) => void;
  onMoveElement?: (id: string, direction: 'up' | 'down') => void;
  allElements?: ScriptElement[];
}

const ScriptElementEditor: React.FC<ScriptElementEditorProps> = memo(({
  element,
  isActive,
  onElementChange,
  onSetActive,
  onDeleteElement,
  onDuplicateElement,
  onMoveElement,
  allElements = []
}) => {
  const { t, isRTL } = useLanguage();
  const isMobile = useIsMobile();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const elementTypes = [
    { value: 'scene-heading', label: t('sceneHeading'), style: 'font-bold uppercase' },
    { value: 'action', label: t('action'), style: '' },
    { value: 'character', label: t('character'), style: 'font-semibold uppercase text-center' },
    { value: 'dialogue', label: t('dialogue'), style: 'ml-4 mr-4 sm:ml-8 sm:mr-8' },
    { value: 'parenthetical', label: t('parenthetical'), style: 'ml-6 mr-6 sm:ml-12 sm:mr-12 italic' },
    { value: 'transition', label: t('transition'), style: 'font-bold uppercase text-right' },
  ];

  // Get scene number for scene headings
  const getSceneNumber = () => {
    if (element.type !== 'scene-heading' || !element.content.trim() || element.content.includes('FADE')) {
      return null;
    }

    const scenes = SceneNumbering.detectScenes(allElements);
    const sceneInfo = scenes.find(scene => scene.heading === element.content);
    return sceneInfo?.number || null;
  };

  const sceneNumber = getSceneNumber();

  const getElementStyle = (type: string) => {
    const elementType = elementTypes.find(et => et.value === type);
    return elementType?.style || '';
  };

  const getPlaceholder = (type: string) => {
    switch (type) {
      case 'scene-heading':
        return t('enterSceneHeading');
      case 'action':
        return t('enterAction');
      case 'character':
        return t('enterCharacter');
      case 'dialogue':
        return t('enterDialogue');
      case 'parenthetical':
        return t('enterParenthetical');
      case 'transition':
        return t('enterTransition');
      default:
        return '';
    }
  };

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isActive) return;
      
      // Delete element
      if (e.key === 'Delete' && e.ctrlKey && onDeleteElement) {
        e.preventDefault();
        onDeleteElement(element.id);
      }
      
      // Duplicate element
      if (e.key === 'd' && e.ctrlKey && onDuplicateElement) {
        e.preventDefault();
        onDuplicateElement(element.id);
      }
    };

    if (isActive) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isActive, element.id, onDeleteElement, onDuplicateElement]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.max(24, textareaRef.current.scrollHeight) + 'px';
    }
  }, [element.content]);

  return (
    <div
      className={`group relative transition-all duration-200 ${isActive ? 'bg-script-blue-50 rounded-lg p-2' : 'p-2'} hover:bg-script-slate-50`}
      onClick={() => onSetActive(element.id)}
    >
      {/* Scene Number Badge for Scene Headings */}
      {element.type === 'scene-heading' && sceneNumber && (
        <div className="absolute -left-8 top-2 w-6 h-6 bg-script-blue-600 text-white text-xs font-bold rounded flex items-center justify-center animate-fade-in z-10">
          {sceneNumber}
        </div>
      )}

      {/* Element Controls - Mobile */}
      {isActive && isMobile && (
        <div className="mb-2 flex items-center gap-2 animate-fade-in">
          <Select
            value={element.type}
            onValueChange={(value) => {
              onElementChange({ ...element, type: value as any });
            }}
          >
            <SelectTrigger className="h-8 text-xs flex-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {elementTypes.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {onDeleteElement && (
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onDeleteElement(element.id);
              }}
              className="h-8 w-8 p-0 text-red-500 hover:text-red-700 transition-colors"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      {/* Element Controls - Desktop */}
      {isActive && !isMobile && (
        <>
          <div className="absolute -left-40 top-0 w-36 animate-fade-in">
            <Select
              value={element.type}
              onValueChange={(value) => {
                onElementChange({ ...element, type: value as any });
              }}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {elementTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Action buttons */}
          <div className="absolute -right-32 top-0 flex items-center gap-1">
            {onMoveElement && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onMoveElement(element.id, 'up');
                  }}
                  className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
                >
                  <ArrowUp className="h-3 w-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onMoveElement(element.id, 'down');
                  }}
                  className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
                >
                  <ArrowDown className="h-3 w-3" />
                </Button>
              </>
            )}
            
            {onDuplicateElement && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onDuplicateElement(element.id);
                }}
                className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200"
              >
                <Copy className="h-3 w-3" />
              </Button>
            )}
            
            {onDeleteElement && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteElement(element.id);
                }}
                className="h-7 w-7 p-0 text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-all duration-200"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        </>
      )}

      {/* Editable Content */}
      <textarea
        ref={textareaRef}
        value={element.content}
        onChange={(e) => {
          onElementChange({ ...element, content: e.target.value });
        }}
        className={`w-full bg-transparent border-none outline-none resize-none transition-all duration-200 ${getElementStyle(element.type)} ${
          isRTL ? 'text-right' : 'text-left'
        }`}
        style={{ minHeight: '1.5rem' }}
        placeholder={getPlaceholder(element.type)}
        rows={1}
        aria-label={`${element.type} element`}
      />
    </div>
  );
});

ScriptElementEditor.displayName = 'ScriptElementEditor';

export default ScriptElementEditor;
