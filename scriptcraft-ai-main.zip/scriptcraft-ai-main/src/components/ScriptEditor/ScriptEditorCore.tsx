
import React, { useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { ScriptDataProvider } from './ScriptDataProvider';
import { useScriptDataContext } from './ScriptDataProvider';
import ScriptEditorLayout from './ScriptEditorLayout';
import { useScriptEditor } from '../../hooks/useScriptEditor';
import { useWorkflowData } from '../../hooks/useWorkflowData';
import { useScriptActions } from '../../hooks/useScriptActions';
import LoadingStates from './LoadingStates';

interface ScriptEditorCoreProps {
  onTitleChange?: (title: string) => void;
}

const ScriptEditorInner: React.FC<ScriptEditorCoreProps> = ({ onTitleChange }) => {
  const { id: scriptId } = useParams();
  const [showSidebar, setShowSidebar] = useState(true);
  const [showProjectInfo, setShowProjectInfo] = useState(false);
  const [showSceneGenerator, setShowSceneGenerator] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedSceneType, setSelectedSceneType] = useState<string>('next');

  // FIXED: Use script data from context - now includes activeElement and setActiveElement
  const {
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    handleTitleSave,
    handleSaveScript,
    activeElement,
    setActiveElement,
    hasMultipleScenes
  } = useScriptDataContext();

  // Load workflow data
  const {
    brainstorm,
    structure,
    characters,
    loading: workflowLoading
  } = useWorkflowData(scriptId);

  // Script actions
  const {
    handleAddNewElement,
    handleInsertCharacterName,
    generateFirstScene,
    generateNextScene
  } = useScriptActions(
    elements,
    setElements,
    brainstorm,
    structure,
    characters,
    handleSaveScript,
    setIsGenerating,
    setShowSceneGenerator,
    setSelectedSceneType,
    selectedSceneType
  );

  // Handle title changes for parent component
  React.useEffect(() => {
    if (onTitleChange && scriptTitle) {
      onTitleChange(scriptTitle);
    }
  }, [scriptTitle, onTitleChange]);

  const handleDownloadScript = useCallback(() => {
    // TODO: Implement PDF download functionality
    console.log('Download script as PDF');
  }, []);

  if (!scriptId) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-script-slate-600">No script ID provided</p>
      </div>
    );
  }

  if (loading || workflowLoading) {
    return <LoadingStates type="script" />;
  }

  if (error) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-2">Error loading script</p>
          <p className="text-script-slate-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <ScriptEditorLayout
      scriptId={scriptId}
      brainstorm={brainstorm}
      structure={structure}
      characters={characters}
      elements={elements}
      setElements={setElements}
      activeElement={activeElement}
      setActiveElement={setActiveElement}
      showProjectInfo={showProjectInfo}
      setShowProjectInfo={setShowProjectInfo}
      showSceneGenerator={showSceneGenerator}
      setShowSceneGenerator={setShowSceneGenerator}
      isGenerating={isGenerating}
      selectedSceneType={selectedSceneType}
      setSelectedSceneType={setSelectedSceneType}
      generateFirstScene={generateFirstScene}
      generateNextScene={generateNextScene}
      handleSaveScript={handleSaveScript}
      handleAddNewElement={handleAddNewElement}
      handleInsertCharacterName={handleInsertCharacterName}
      hasMultipleScenes={hasMultipleScenes}
      saving={saving}
      isSavingTitle={isSavingTitle}
      script={script}
      scriptTitle={scriptTitle}
      setScriptTitle={setScriptTitle}
      onTitleSave={handleTitleSave}
      titleSaved={titleSaved}
      showSidebar={showSidebar}
      setShowSidebar={setShowSidebar}
      onDownloadScript={handleDownloadScript}
    />
  );
};

const ScriptEditorCore: React.FC<ScriptEditorCoreProps> = (props) => {
  const { id: scriptId } = useParams();

  if (!scriptId) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-script-slate-600">No script ID provided</p>
      </div>
    );
  }

  return (
    <ScriptDataProvider scriptId={scriptId}>
      <ScriptEditorInner {...props} />
    </ScriptDataProvider>
  );
};

export default ScriptEditorCore;
