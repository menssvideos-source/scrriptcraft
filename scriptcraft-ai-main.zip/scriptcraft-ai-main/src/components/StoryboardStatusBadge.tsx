
import React from 'react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Film, Wand2, Eye, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { StoryboardStatus } from '../hooks/useStoryboardStatus';

interface StoryboardStatusBadgeProps {
  status: StoryboardStatus;
  onViewStoryboard?: () => void;
  onGenerateStoryboard?: () => void;
  compact?: boolean;
  showButton?: boolean;
}

const StoryboardStatusBadge: React.FC<StoryboardStatusBadgeProps> = ({
  status,
  onViewStoryboard,
  onGenerateStoryboard,
  compact = false,
  showButton = true
}) => {
  const { t, isRTL } = useLanguage();

  const getStatusConfig = () => {
    switch (status.storyboardStatus) {
      case 'complete':
        return {
          label: t('storyboardComplete'),
          color: 'bg-green-100 text-green-800',
          icon: Film,
          buttonLabel: t('viewStoryboard'),
          buttonAction: onViewStoryboard,
          buttonIcon: Eye,
          buttonColor: 'bg-green-600 hover:bg-green-700'
        };
      case 'partial':
        return {
          label: t('storyboardPartial'),
          color: 'bg-yellow-100 text-yellow-800',
          icon: AlertCircle,
          buttonLabel: t('viewStoryboard'),
          buttonAction: onViewStoryboard,
          buttonIcon: Eye,
          buttonColor: 'bg-yellow-600 hover:bg-yellow-700'
        };
      case 'generating':
        return {
          label: t('generating'),
          color: 'bg-blue-100 text-blue-800',
          icon: Wand2,
          buttonLabel: t('viewProgress'),
          buttonAction: onViewStoryboard,
          buttonIcon: Eye,
          buttonColor: 'bg-blue-600 hover:bg-blue-700'
        };
      default:
        return {
          label: t('noStoryboard'),
          color: 'bg-gray-100 text-gray-800',
          icon: Film,
          buttonLabel: t('generateStoryboard'),
          buttonAction: onGenerateStoryboard,
          buttonIcon: Wand2,
          buttonColor: 'bg-purple-600 hover:bg-purple-700'
        };
    }
  };

  const config = getStatusConfig();
  const IconComponent = config.icon;
  const ButtonIcon = config.buttonIcon;

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Badge className={`text-xs ${config.color}`}>
          <IconComponent className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
          {config.label}
          {status.imageCount > 0 && ` (${status.imageCount})`}
        </Badge>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
      <Badge className={`${config.color} flex items-center gap-1`}>
        <IconComponent className="h-3 w-3" />
        {config.label}
        {status.imageCount > 0 && ` (${status.imageCount})`}
      </Badge>
      
      {showButton && config.buttonAction && (
        <Button
          size="sm"
          onClick={config.buttonAction}
          className={`text-white ${config.buttonColor} text-xs`}
        >
          <ButtonIcon className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
          {config.buttonLabel}
        </Button>
      )}
    </div>
  );
};

export default StoryboardStatusBadge;
