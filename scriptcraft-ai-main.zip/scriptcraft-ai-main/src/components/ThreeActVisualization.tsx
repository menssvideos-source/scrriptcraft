
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface ActProgress {
  act: number;
  title: string;
  color: string;
  completion: number;
}

const ThreeActVisualization: React.FC = () => {
  const { t } = useLanguage();

  const actProgress: ActProgress[] = [
    { act: 1, title: t('setupPages'), color: 'bg-green-500', completion: 25 },
    { act: 2, title: t('confrontationPages'), color: 'bg-blue-500', completion: 50 },
    { act: 3, title: t('resolutionPages'), color: 'bg-purple-500', completion: 25 }
  ];

  return (
    <div className="bg-white rounded-lg p-6 border border-script-slate-200">
      <div className="flex items-center justify-between mb-4">
        {actProgress.map((act) => (
          <div key={act.act} className="flex-1 text-center">
            <div className={`h-4 mx-2 rounded ${act.color}`}></div>
            <p className="text-sm font-medium mt-2">
              {act.act === 1 ? t('act1Setup') : 
               act.act === 2 ? t('act2Confrontation') : 
               t('act3Resolution')}
            </p>
            <p className="text-xs text-script-slate-500">{act.title}</p>
            <p className="text-xs text-script-slate-400">{act.completion}%</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ThreeActVisualization;
