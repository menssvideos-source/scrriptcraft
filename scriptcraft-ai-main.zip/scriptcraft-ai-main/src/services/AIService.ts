import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { ScriptElement } from '../types/script';
import { ContextService, StoryContext } from './ContextService';

export interface AIServiceConfig {
  apiKey: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface SceneGenerationContext {
  brainstorm?: ProjectBrainstorm | null;
  structure?: ProjectStructure | null;
  characters: Character[];
  existingElements: ScriptElement[];
  sceneType: string;
  nextSceneNumber: number;
}

export class AIService {
  private config: AIServiceConfig;

  constructor(config: AIServiceConfig) {
    this.config = {
      model: 'gpt-4.1-2025-04-14',
      temperature: 0.7,
      maxTokens: 150,
      ...config
    };
  }

  // Extract character names from text for consistency
  private extractCharacterNames(text: string): string[] {
    if (!text) return [];
    
    const namePatterns = [
      /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g, // Capitalized names
      /\b([A-Z]{2,})\b/g, // All caps names/abbreviations
    ];
    
    const names = new Set<string>();
    namePatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          const commonWords = ['THE', 'AND', 'OR', 'BUT', 'IF', 'WHEN', 'WHERE', 'ACT', 'SCENE', 'INT', 'EXT', 'FADE', 'CUT'];
          if (!commonWords.includes(match.toUpperCase()) && match.length > 2) {
            names.add(match);
          }
        });
      }
    });
    
    return Array.from(names).slice(0, 10);
  }

  // Enhanced context building with story awareness
  private buildComprehensiveContext(context: SceneGenerationContext, scriptTitle?: string): string {
    const storyContext = ContextService.buildStoryContext(
      context.brainstorm,
      context.structure,
      context.characters,
      context.existingElements,
      scriptTitle
    );

    let contextInfo = `STORY UNIVERSE:
Title: "${storyContext.scriptTitle}"
Genre: ${storyContext.genre}
Main Character: ${storyContext.mainCharacter?.name || 'Protagonist'}

CHARACTER DEVELOPMENT:
`;

    // Enhanced character context with voice samples
    if (context.characters.length > 0) {
      context.characters.forEach(char => {
        contextInfo += `${char.name} (${char.role}): ${char.description}\n`;
        if (char.motivation) contextInfo += `  Motivation: ${char.motivation}\n`;
        if (char.arc) contextInfo += `  Character Arc: ${char.arc}\n`;
        
        // Add voice samples if available
        const voiceSamples = storyContext.characterVoiceSamples[char.name];
        if (voiceSamples && voiceSamples.length > 0) {
          contextInfo += `  Voice Examples: ${voiceSamples.map(v => `"${v}"`).join(', ')}\n`;
        }
      });
    }

    // Enhanced story structure context
    contextInfo += `\nSTORY STRUCTURE:
Current Act: ${storyContext.currentAct} - ${storyContext.actDescription}
`;

    if (context.structure) {
      if (storyContext.currentAct === 1 && context.structure.act1) {
        if (context.structure.act1.setup) contextInfo += `Setup: ${context.structure.act1.setup}\n`;
        if (context.structure.act1.incitingIncident) contextInfo += `Inciting Incident: ${context.structure.act1.incitingIncident}\n`;
        if (context.structure.act1.plotPoint1) contextInfo += `Plot Point 1: ${context.structure.act1.plotPoint1}\n`;
      } else if (storyContext.currentAct === 2 && context.structure.act2) {
        if (context.structure.act2.confrontation) contextInfo += `Confrontation: ${context.structure.act2.confrontation}\n`;
        if (context.structure.act2.midpoint) contextInfo += `Midpoint: ${context.structure.act2.midpoint}\n`;
        if (context.structure.act2.plotPoint2) contextInfo += `Plot Point 2: ${context.structure.act2.plotPoint2}\n`;
      } else if (storyContext.currentAct === 3 && context.structure.act3) {
        if (context.structure.act3.climax) contextInfo += `Climax: ${context.structure.act3.climax}\n`;
        if (context.structure.act3.resolution) contextInfo += `Resolution: ${context.structure.act3.resolution}\n`;
      }
    }

    // Add recent story context for continuity
    if (storyContext.recentScenes.length > 0) {
      contextInfo += `\nRECENT SCENES:\n${storyContext.recentScenes.join('\n')}\n`;
    }

    // Add plot threads
    if (storyContext.plotThreads.length > 0) {
      contextInfo += `\nESTABLISHED PLOT THREADS:\n${storyContext.plotThreads.join('; ')}\n`;
    }

    // Add current scene context
    contextInfo += `\nCURRENT SITUATION: ${storyContext.currentSceneContext}\n`;

    return contextInfo;
  }

  async callOpenAI(prompt: string, systemMessage?: string, storyContext?: StoryContext): Promise<string> {
    if (!this.config.apiKey?.trim()) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    const enhancedSystemMessage = systemMessage || this.buildEnhancedSystemMessage(storyContext);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: this.config.model,
        messages: [
          {
            role: 'system',
            content: enhancedSystemMessage
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: this.config.temperature,
        max_tokens: this.config.maxTokens,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  buildScenePrompt(context: SceneGenerationContext, scriptTitle?: string): string {
    const contextInfo = this.buildComprehensiveContext(context, scriptTitle);
    
    // Get main character name for personalized prompts
    const mainCharacterName = context.characters.find(c => c.role === 'protagonist')?.name || 
                             this.extractCharacterNames(contextInfo)[0] || 
                             'the protagonist';

    const storyContext = ContextService.buildStoryContext(
      context.brainstorm,
      context.structure,
      context.characters,
      context.existingElements,
      scriptTitle
    );

    let prompt = contextInfo;
    prompt += `\nScene Number: ${context.nextSceneNumber}\n`;
    
    // Enhanced scene type instructions with story context
    const SCENE_TYPES = {
      'first': `opening scene that introduces ${mainCharacterName} in their ordinary world, establishing the ${storyContext.genre} tone and ${storyContext.scriptTitle} story concept`,
      'opening': `opening scene that establishes ${mainCharacterName} and the setting of "${storyContext.scriptTitle}", building on the established ${storyContext.genre} elements`,
      'inciting': `inciting incident scene for ${mainCharacterName} that disrupts their normal world and starts the main story of "${storyContext.scriptTitle}"`,
      'character': `character development scene focusing on ${mainCharacterName} that reveals personality, backstory, or relationships, advancing their character arc in "${storyContext.scriptTitle}"`,
      'conflict': `conflict scene where ${mainCharacterName} faces obstacles or opposition, building tension in the ${storyContext.genre} story "${storyContext.scriptTitle}"`,
      'revelation': `revelation scene where ${mainCharacterName} discovers important information, advancing the plot of "${storyContext.scriptTitle}"`,
      'climax': `climactic scene with ${mainCharacterName} facing major confrontation, building toward the resolution of "${storyContext.scriptTitle}"`,
      'resolution': `resolution scene that wraps up ${mainCharacterName}'s story threads in "${storyContext.scriptTitle}", maintaining character consistency`,
      'next': `next logical scene that continues ${mainCharacterName}'s story progression in "${storyContext.scriptTitle}", building on recent events`
    };

    const sceneDescription = SCENE_TYPES[context.sceneType as keyof typeof SCENE_TYPES] || SCENE_TYPES.next;
    
    prompt += `Continue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write Scene ${context.nextSceneNumber}: ${sceneDescription}. `;
    
    // Add character voice consistency instruction
    const characterVoice = storyContext.characterVoiceSamples[mainCharacterName];
    if (characterVoice && characterVoice.length > 0) {
      prompt += `When writing dialogue for ${mainCharacterName}, maintain consistency with their established voice: ${characterVoice.slice(0, 2).map(v => `"${v}"`).join(', ')}. `;
    }

    prompt += `Build on established story elements and maintain character consistency. Reference previous events naturally. Start with a properly formatted scene heading.`;

    prompt += `\n\nFormat: Scene heading (INT./EXT. LOCATION - TIME) followed by action description. Use established character names and maintain story consistency with "${storyContext.scriptTitle}". Keep it concise and cinematic, appropriate for the ${storyContext.genre} genre.`;

    return prompt;
  }

  private buildEnhancedSystemMessage(storyContext?: StoryContext): string {
    let systemMessage = `You are an intelligent screenplay writing partner`;
    
    if (storyContext) {
      systemMessage += ` working on "${storyContext.scriptTitle}" - a ${storyContext.genre} story.

STORY CONTEXT:
- Main Character: ${storyContext.mainCharacter?.name || 'Protagonist'} - ${storyContext.mainCharacter?.description || 'Character in development'}
- Character Arc: ${storyContext.mainCharacter?.arc || 'Character journey in progress'}
- Current Act: ${storyContext.currentAct} - ${storyContext.actDescription}
- Story Themes: ${storyContext.themes.join(', ') || 'Themes developing'}

WRITING GUIDELINES:
- Maintain character voice and consistency for ${storyContext.mainCharacter?.name || 'the protagonist'}
- Build on established plot threads: ${storyContext.plotThreads.join('; ') || 'Story elements developing'}
- Use proper screenplay format (scene headings, action, dialogue)
- Keep scenes focused and under 100 words
- Reference previous events naturally from: ${storyContext.recentScenes.slice(-1)[0] || 'story beginning'}
- Advance the character's emotional journey in this ${storyContext.genre} story

Generate the next scene that logically follows from the established story context of "${storyContext.scriptTitle}".`;
    } else {
      systemMessage += `. Generate properly formatted screenplay scenes that maintain character consistency and build on established story elements. Use established character names and continue the ongoing story. Use proper screenplay format: scene headings in ALL CAPS (e.g., "INT. KITCHEN - MORNING"), followed by action description. Keep scenes focused and under 100 words total.`;
    }

    return systemMessage;
  }

  parseSceneContent(sceneContent: string): ScriptElement[] {
    const lines = sceneContent.split('\n').filter(line => line.trim());
    const elements: ScriptElement[] = [];
    
    lines.forEach((line, index) => {
      const trimmed = line.trim();
      if (trimmed) {
        if (trimmed.includes('INT.') || trimmed.includes('EXT.') || 
            (trimmed.toUpperCase() === trimmed && trimmed.includes(' - '))) {
          elements.push({
            id: (Date.now() + index + 1).toString(),
            type: 'scene-heading',
            content: trimmed
          });
        } else {
          elements.push({
            id: (Date.now() + index + 1).toString(),
            type: 'action',
            content: trimmed
          });
        }
      }
    });
    
    return elements;
  }
}

export const createAIService = (apiKey: string): AIService => {
  return new AIService({ apiKey });
};
