/**
 * Centralized service for all localStorage operations
 * Provides type-safe storage with error handling and user-specific data isolation
 */
export class StorageService {
  private static instance: StorageService;
  
  private constructor() {}
  
  static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  // Helper method to create user-specific keys
  private getUserKey(userId: string | null, baseKey: string): string {
    if (!userId) {
      return `guest-${baseKey}`; // Fallback for unauthenticated users
    }
    return `user-${userId}-${baseKey}`;
  }

  // API Keys (sensitive data) - now user-specific
  setAPIKey(provider: string, key: string, userId: string | null = null): void {
    try {
      const storageKey = this.getUserKey(userId, `${provider}-api-key`);
      localStorage.setItem(storageKey, key);
    } catch (error) {
      console.error(`Failed to store API key for ${provider}:`, error);
    }
  }

  getAPIKey(provider: string, userId: string | null = null): string {
    try {
      const storageKey = this.getUserKey(userId, `${provider}-api-key`);
      return localStorage.getItem(storageKey) || '';
    } catch (error) {
      console.error(`Failed to retrieve API key for ${provider}:`, error);
      return '';
    }
  }

  removeAPIKey(provider: string, userId: string | null = null): void {
    try {
      const storageKey = this.getUserKey(userId, `${provider}-api-key`);
      localStorage.removeItem(storageKey);
    } catch (error) {
      console.error(`Failed to remove API key for ${provider}:`, error);
    }
  }

  // User-specific settings
  setUserSetting(key: string, value: string, userId: string | null = null): void {
    try {
      const storageKey = this.getUserKey(userId, `setting-${key}`);
      localStorage.setItem(storageKey, value);
    } catch (error) {
      console.error(`Failed to store user setting ${key}:`, error);
    }
  }

  getUserSetting(key: string, userId: string | null = null): string {
    try {
      const storageKey = this.getUserKey(userId, `setting-${key}`);
      return localStorage.getItem(storageKey) || '';
    } catch (error) {
      console.error(`Failed to retrieve user setting ${key}:`, error);
      return '';
    }
  }

  // Project data - keep existing methods for now (already project-specific)
  setProjectData(projectId: string, data: any): void {
    try {
      localStorage.setItem(`project-${projectId}`, JSON.stringify({
        ...data,
        lastModified: new Date().toISOString()
      }));
    } catch (error) {
      console.error(`Failed to store project data for ${projectId}:`, error);
    }
  }

  getProjectData(projectId: string): any | null {
    try {
      const data = localStorage.getItem(`project-${projectId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error(`Failed to retrieve project data for ${projectId}:`, error);
      return null;
    }
  }

  // Brainstorm data
  setBrainstormData(projectId: string, data: any): void {
    try {
      localStorage.setItem(`project-${projectId}-brainstorm`, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to store brainstorm data for ${projectId}:`, error);
    }
  }

  getBrainstormData(projectId: string): any | null {
    try {
      const data = localStorage.getItem(`project-${projectId}-brainstorm`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error(`Failed to retrieve brainstorm data for ${projectId}:`, error);
      return null;
    }
  }

  // Structure data
  setStructureData(projectId: string, data: any): void {
    try {
      localStorage.setItem(`project-${projectId}-structure`, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to store structure data for ${projectId}:`, error);
    }
  }

  getStructureData(projectId: string): any | null {
    try {
      const data = localStorage.getItem(`project-${projectId}-structure`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error(`Failed to retrieve structure data for ${projectId}:`, error);
      return null;
    }
  }

  // Storyboard data
  setStoryboardData(scriptId: string, data: any): void {
    try {
      localStorage.setItem(`storyboard-${scriptId}`, JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to store storyboard data for ${scriptId}:`, error);
    }
  }

  getStoryboardData(scriptId: string): any | null {
    try {
      const data = localStorage.getItem(`storyboard-${scriptId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error(`Failed to retrieve storyboard data for ${scriptId}:`, error);
      return null;
    }
  }

  removeStoryboardData(scriptId: string): void {
    try {
      localStorage.removeItem(`storyboard-${scriptId}`);
    } catch (error) {
      console.error(`Failed to remove storyboard data for ${scriptId}:`, error);
    }
  }

  // NEW: User data cleanup methods
  clearUserData(userId: string): void {
    if (!userId) return;
    
    try {
      const keysToRemove: string[] = [];
      
      // Find all keys that belong to this user
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith(`user-${userId}-`)) {
          keysToRemove.push(key);
        }
      }
      
      // Remove all user-specific keys
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      console.log(`Cleared ${keysToRemove.length} user-specific items for user ${userId}`);
    } catch (error) {
      console.error(`Failed to clear user data for ${userId}:`, error);
    }
  }

  // NEW: Migration method to move global keys to user-specific keys
  migrateGlobalKeysToUser(userId: string): void {
    if (!userId) return;
    
    try {
      // Check if migration has already been done
      const migrationKey = `migration-${userId}-completed`;
      if (localStorage.getItem(migrationKey)) {
        return; // Already migrated
      }

      // List of global keys to migrate
      const globalKeys = [
        'openai-api-key',
        'openai-image-api-key',
        'use-same-key-for-images',
        'selected-image-model'
      ];

      let migratedCount = 0;
      globalKeys.forEach(globalKey => {
        const value = localStorage.getItem(globalKey);
        if (value) {
          // Move to user-specific key
          const userKey = this.getUserKey(userId, globalKey);
          localStorage.setItem(userKey, value);
          localStorage.removeItem(globalKey); // Remove global key
          migratedCount++;
        }
      });

      // Mark migration as completed
      localStorage.setItem(migrationKey, 'true');
      
      if (migratedCount > 0) {
        console.log(`Migrated ${migratedCount} global keys to user-specific keys for user ${userId}`);
      }
    } catch (error) {
      console.error(`Failed to migrate global keys for user ${userId}:`, error);
    }
  }

  // NEW: Clear all guest data (for unauthenticated users)
  clearGuestData(): void {
    try {
      const keysToRemove: string[] = [];
      
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('guest-')) {
          keysToRemove.push(key);
        }
      }
      
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      if (keysToRemove.length > 0) {
        console.log(`Cleared ${keysToRemove.length} guest items`);
      }
    } catch (error) {
      console.error('Failed to clear guest data:', error);
    }
  }

  // Cleanup utilities
  clearProjectData(projectId: string): void {
    try {
      const keysToRemove = [
        `project-${projectId}`,
        `project-${projectId}-brainstorm`,
        `project-${projectId}-structure`,
        `storyboard-${projectId}`
      ];
      
      keysToRemove.forEach(key => localStorage.removeItem(key));
    } catch (error) {
      console.error(`Failed to clear project data for ${projectId}:`, error);
    }
  }

  // Get storage usage info
  getStorageInfo(): { used: number; available: number; usage: string } {
    try {
      let used = 0;
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          used += localStorage[key].length + key.length;
        }
      }
      
      const available = 5 * 1024 * 1024; // 5MB typical limit
      const usage = ((used / available) * 100).toFixed(1);
      
      return { used, available, usage };
    } catch (error) {
      console.error('Failed to get storage info:', error);
      return { used: 0, available: 0, usage: '0' };
    }
  }
}

export const storageService = StorageService.getInstance();
