import { Character, ProjectBrainstorm, ProjectStructure } from '../types/project';

export class CharacterGenerationService {
  private getApiKey(): string {
    return localStorage.getItem('openai-api-key') || '';
  }

  private async callOpenAI(prompt: string): Promise<string> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    console.log('Making OpenAI API call for character generation...');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are a character development assistant. Create diverse, well-rounded characters that are specifically designed for the provided three-act structure. Characters should be integral to the story beats and plot points. Always include age, gender, physical description, and personality. Format each character as: "Name - Role - Age - Gender - Physical Description - Personality". Keep each character description concise but detailed.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`API call failed: ${response.status} ${response.statusText} - ${errorData.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private validateStructureCompleteness(structure?: ProjectStructure | null): void {
    if (!structure) {
      throw new Error('Please complete the Structure Planning step first. Characters need to be designed for your specific three-act structure.');
    }

    const missingActs = [];
    
    if (!structure.act1?.setup || !structure.act1?.incitingIncident || !structure.act1?.plotPoint1) {
      missingActs.push('Act I (Setup, Inciting Incident, Plot Point 1)');
    }
    
    if (!structure.act2?.confrontation || !structure.act2?.midpoint || !structure.act2?.plotPoint2) {
      missingActs.push('Act II (Confrontation, Midpoint, Plot Point 2)');
    }
    
    if (!structure.act3?.climax || !structure.act3?.resolution) {
      missingActs.push('Act III (Climax, Resolution)');
    }

    if (missingActs.length > 0) {
      throw new Error(`Please complete these story structure elements first: ${missingActs.join(', ')}. Characters should be designed to serve your specific plot points and story beats.`);
    }
  }

  private buildContextPrompt(brainstorm?: ProjectBrainstorm | null, structure?: ProjectStructure | null): string {
    let contextInfo = '';
    
    if (brainstorm) {
      contextInfo = `STORY FOUNDATION:
- Genre: ${brainstorm.genre || 'Not specified'}
- Setting: ${brainstorm.setting || 'Not specified'} 
- Time Period: ${brainstorm.timeframe || 'Contemporary'}
- Tone: ${brainstorm.tone || 'Not specified'}
- Theme: ${brainstorm.theme || 'Not specified'}
- Core Idea: ${brainstorm.idea || 'Not specified'}
- Logline: ${brainstorm.logline || 'Not specified'}

`;
    }

    if (structure) {
      contextInfo += `THREE-ACT STRUCTURE:

ACT I - SETUP (Pages 1-25):
- Setup: ${structure.act1?.setup || 'Not specified'}
- Inciting Incident: ${structure.act1?.incitingIncident || 'Not specified'}
- Plot Point 1: ${structure.act1?.plotPoint1 || 'Not specified'}

ACT II - CONFRONTATION (Pages 25-90):
- Confrontation: ${structure.act2?.confrontation || 'Not specified'}
- Midpoint: ${structure.act2?.midpoint || 'Not specified'}
- Plot Point 2: ${structure.act2?.plotPoint2 || 'Not specified'}

ACT III - RESOLUTION (Pages 90-120):
- Climax: ${structure.act3?.climax || 'Not specified'}
- Resolution: ${structure.act3?.resolution || 'Not specified'}

`;
    }

    return contextInfo + `Based on this complete story foundation and three-act structure, create exactly 3-4 characters that are ESSENTIAL to these specific plot points and story beats. Each character should serve a specific purpose in the story's progression through Acts I, II, and III.

REQUIREMENTS:
- Characters must be directly connected to the established plot points (inciting incident, midpoint, climax, etc.)
- Include at least one protagonist who drives the main story arc
- Include at least one antagonist who creates the central conflict
- Supporting characters should facilitate key story beats or represent thematic elements
- Characters should fit naturally into the established genre, setting, and tone

For each character, provide:
- Name (appropriate for the setting/time period)
- Role (protagonist, antagonist, supporting, minor)
- Age (realistic for their role and story context)
- Gender (ensure diversity)
- Physical Description (height, build, hair, eyes, distinctive features, clothing style appropriate to setting)
- Personality & Story Function (motivations, traits, how they connect to specific plot points and what role they play in the three-act structure)

Format each character EXACTLY as:
"[Name] - [Role] - [Age] - [Gender] - [Physical Description] - [Personality & Story Function]"

Focus on creating characters that are integral to YOUR specific story rather than generic character types.`;
  }

  private parseCharacterSuggestions(suggestions: string): Character[] {
    const lines = suggestions.split('\n').filter(line => line.trim() && line.includes('-'));
    const newCharacters: Character[] = [];
    
    console.log('Parsing character suggestions:', lines);
    
    lines.forEach((line, index) => {
      try {
        const parts = line.split(' - ');
        if (parts.length >= 6) {
          const name = parts[0].trim().replace(/^\d+\.?\s*/, '');
          const roleText = parts[1].trim().toLowerCase();
          const ageText = parts[2].trim();
          const gender = parts[3].trim();
          const physicalDescription = parts[4].trim();
          const personality = parts[5].trim();
          
          let role: Character['role'] = 'supporting';
          if (roleText.includes('protagonist') || roleText.includes('main character') || roleText.includes('hero')) {
            role = 'protagonist';
          } else if (roleText.includes('antagonist') || roleText.includes('villain') || roleText.includes('enemy')) {
            role = 'antagonist';
          } else if (roleText.includes('supporting')) {
            role = 'supporting';
          } else if (roleText.includes('minor')) {
            role = 'minor';
          }
          
          const age = parseInt(ageText) || undefined;
          
          if (name) {
            newCharacters.push({
              id: '', // Will be assigned by useCharacterOperations
              name,
              role,
              age,
              gender,
              physicalDescription,
              description: personality,
              relationships: []
            });
          }
        }
      } catch (error) {
        console.warn(`Failed to parse character line ${index}:`, line, error);
      }
    });
    
    console.log('Successfully parsed characters:', newCharacters.length);
    return newCharacters;
  }

  async generateCharacterSuggestions(
    brainstorm?: ProjectBrainstorm | null, 
    structure?: ProjectStructure | null
  ): Promise<Character[]> {
    const apiKey = this.getApiKey();
    if (!apiKey.trim()) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    // Validate that all three acts are complete
    this.validateStructureCompleteness(structure);

    console.log('Generating characters with complete three-act structure:', { brainstorm, structure });
    
    const prompt = this.buildContextPrompt(brainstorm, structure);
    const suggestions = await this.callOpenAI(prompt);
    const newCharacters = this.parseCharacterSuggestions(suggestions);
    
    if (newCharacters.length === 0) {
      throw new Error('Failed to generate valid characters from AI response');
    }
    
    console.log('Character generation completed successfully:', newCharacters.length, 'characters designed for three-act structure');
    return newCharacters;
  }
}

export const characterGenerationService = new CharacterGenerationService();
