
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { ScriptElement } from '../types/script';

export interface StoryContext {
  scriptTitle?: string;
  genre?: string;
  mainCharacter?: Character;
  currentAct: number;
  actDescription: string;
  recentScenes: string[];
  recentDialogue: string[];
  characterVoiceSamples: Record<string, string[]>;
  visualCharacterTraits: Record<string, string>;
  plotThreads: string[];
  themes: string[];
  currentSceneContext: string;
}

export class ContextService {
  static buildStoryContext(
    brainstorm?: ProjectBrainstorm | null,
    structure?: ProjectStructure | null,
    characters: Character[] = [],
    elements: ScriptElement[] = [],
    scriptTitle?: string
  ): StoryContext {
    // Determine current act based on script progress
    const totalScenes = elements.filter(el => 
      el.type === 'scene-heading' && el.content.trim() && !el.content.includes('FADE')
    ).length;
    
    let currentAct = 1;
    let actDescription = '';
    
    if (totalScenes > 0) {
      const position = totalScenes / Math.max(totalScenes + 5, 10);
      if (position > 0.25) currentAct = 2;
      if (position > 0.75) currentAct = 3;
    }

    // Get act-specific description
    if (currentAct === 1 && structure?.act1) {
      actDescription = structure.act1.setup || 'Setting up the story world and characters';
    } else if (currentAct === 2 && structure?.act2) {
      actDescription = structure.act2.confrontation || 'Developing conflict and challenges';
    } else if (currentAct === 3 && structure?.act3) {
      actDescription = structure.act3.climax || 'Building toward resolution';
    }

    // Extract recent scenes (last 3)
    const recentScenes = elements
      .filter(el => el.type === 'scene-heading' && el.content.trim())
      .slice(-3)
      .map(el => el.content);

    // Extract recent dialogue for character voice analysis
    const recentDialogue = elements
      .filter(el => el.type === 'dialogue' && el.content.trim())
      .slice(-10)
      .map(el => el.content);

    // Build character voice samples from existing dialogue
    const characterVoiceSamples: Record<string, string[]> = {};
    let currentCharacter = '';
    
    elements.forEach(el => {
      if (el.type === 'character') {
        currentCharacter = el.content.trim();
      } else if (el.type === 'dialogue' && currentCharacter) {
        if (!characterVoiceSamples[currentCharacter]) {
          characterVoiceSamples[currentCharacter] = [];
        }
        if (characterVoiceSamples[currentCharacter].length < 3) {
          characterVoiceSamples[currentCharacter].push(el.content);
        }
      }
    });

    // Build visual character traits
    const visualCharacterTraits: Record<string, string> = {};
    characters.forEach(char => {
      visualCharacterTraits[char.name] = char.physicalDescription || 'No description available';
    });

    // Extract plot threads from brainstorm and structure
    const plotThreads: string[] = [];
    if (brainstorm?.idea) plotThreads.push(brainstorm.idea);
    if (brainstorm?.premise) plotThreads.push(brainstorm.premise);
    if (structure?.act1?.incitingIncident) plotThreads.push(structure.act1.incitingIncident);
    if (structure?.act2?.midpoint) plotThreads.push(structure.act2.midpoint);

    // Extract themes
    const themes: string[] = [];
    if (brainstorm?.theme) themes.push(brainstorm.theme);
    if (brainstorm?.tone) themes.push(brainstorm.tone);

    // Build current scene context
    const recentActions = elements
      .filter(el => el.type === 'action' && el.content.trim())
      .slice(-2)
      .map(el => el.content)
      .join(' ');

    // Find main character (protagonist or first character)
    const mainCharacter = characters.find(c => c.role === 'protagonist') || characters[0];

    return {
      scriptTitle: scriptTitle || 'Untitled Script',
      genre: brainstorm?.genre || 'Drama',
      mainCharacter,
      currentAct,
      actDescription,
      recentScenes,
      recentDialogue,
      characterVoiceSamples,
      visualCharacterTraits,
      plotThreads,
      themes,
      currentSceneContext: recentActions || 'Story beginning'
    };
  }

  static buildContextualPrompt(basePrompt: string, context: StoryContext): string {
    let enhancedPrompt = `STORY UNIVERSE:
Title: "${context.scriptTitle}"
Genre: ${context.genre}
Main Character: ${context.mainCharacter?.name || 'Protagonist'} - ${context.mainCharacter?.description || 'Character in development'}
Current Act: ${context.currentAct} - ${context.actDescription}
Current Situation: ${context.currentSceneContext}

`;

    // Add character voice examples if available
    if (context.mainCharacter && context.characterVoiceSamples[context.mainCharacter.name]) {
      enhancedPrompt += `CHARACTER VOICE EXAMPLES:
Previous dialogue by ${context.mainCharacter.name}:
${context.characterVoiceSamples[context.mainCharacter.name].map(d => `"${d}"`).join('\n')}

`;
    }

    // Add recent story context
    if (context.recentScenes.length > 0) {
      enhancedPrompt += `RECENT SCENES:
${context.recentScenes.join('\n')}

`;
    }

    // Add plot threads
    if (context.plotThreads.length > 0) {
      enhancedPrompt += `ESTABLISHED PLOT THREADS:
${context.plotThreads.join('; ')}

`;
    }

    enhancedPrompt += basePrompt;
    enhancedPrompt += `\n\nRemember: You're continuing ${context.mainCharacter?.name || 'the protagonist'}'s established story, not starting fresh. Maintain character consistency and build on previous events.`;

    return enhancedPrompt;
  }

  static buildImagePrompt(
    baseVisualDescription: string,
    frameTitle: string,
    shotType: string,
    mood: string,
    lighting: string,
    context: StoryContext
  ): string {
    const characterName = context.mainCharacter?.name || 'the protagonist';
    const characterDescription = context.mainCharacter?.description || 'main character';
    const visualTraits = context.visualCharacterTraits[characterName] || 'character appearance not yet established';

    return `Professional cinematic storyboard frame for ${characterName}'s ${context.genre} story "${context.scriptTitle}": ${baseVisualDescription}

Character Details: ${characterName} (${characterDescription}) - Visual: ${visualTraits}
Story Context: Act ${context.currentAct} - ${context.actDescription}
Scene Context: ${frameTitle}
Visual Style: ${context.genre}-appropriate lighting and composition
Shot Type: ${shotType}. Mood: ${mood}. Lighting: ${lighting}

Rendered as professional film storyboard sketch, maintaining character consistency with previous frames and ${context.genre} genre conventions.`;
  }
}
