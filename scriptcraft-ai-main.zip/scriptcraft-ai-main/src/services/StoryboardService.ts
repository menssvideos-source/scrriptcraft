
import { StoryboardFrame } from '../lib/storyboard/types';
import { ImageModel } from '../contexts/APIKeyContext';

export interface StoryboardServiceConfig {
  apiKey: string;
  imageModel: ImageModel;
}

export class StoryboardService {
  private config: StoryboardServiceConfig;

  constructor(config: StoryboardServiceConfig) {
    this.config = config;
  }

  async generateImage(frame: StoryboardFrame): Promise<string> {
    if (!this.config.apiKey?.trim()) {
      throw new Error('Please configure your image generation API key');
    }

    try {
      console.log(`StoryboardService: Generating image for frame ${frame.id}: ${frame.title}`);
      
      // Enhanced prompt for better image generation
      const enhancedPrompt = this.enhanceImagePrompt(frame);
      console.log(`StoryboardService: Enhanced prompt: ${enhancedPrompt}`);
      
      let imageUrl: string;

      switch (this.config.imageModel.id) {
        case 'flux-schnell':
        case 'flux-dev':
          imageUrl = await this.generateWithFlux(enhancedPrompt);
          break;
        case 'dall-e-2':
        case 'dall-e-3':
          imageUrl = await this.generateWithDallE(enhancedPrompt);
          break;
        default:
          throw new Error(`Unsupported image model: ${this.config.imageModel.id}`);
      }

      console.log(`StoryboardService: Successfully generated image for frame ${frame.id}`);
      return imageUrl;
    } catch (error) {
      console.error(`StoryboardService: Image generation failed for frame ${frame.id}:`, error);
      throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private enhanceImagePrompt(frame: StoryboardFrame): string {
    let prompt = frame.visualDescription;
    
    // Add scene context from title if available
    if (frame.title && frame.title !== frame.visualDescription) {
      prompt = `${frame.title}. ${prompt}`;
    }
    
    // Add cinematic style indicators
    if (frame.shotType) {
      prompt += `, ${frame.shotType} shot`;
    }
    
    if (frame.cameraAngle) {
      prompt += `, ${frame.cameraAngle} angle`;
    }
    
    if (frame.lighting) {
      prompt += `, ${frame.lighting} lighting`;
    }
    
    if (frame.mood) {
      prompt += `, ${frame.mood} mood`;
    }
    
    // Add key moments context
    if (frame.keyMoments && frame.keyMoments.length > 0) {
      const keyMomentsText = frame.keyMoments.slice(0, 2).join(', '); // Limit to avoid overly long prompts
      prompt += `, featuring: ${keyMomentsText}`;
    }
    
    // Add cinematic quality enhancers
    prompt += ', cinematic composition, high quality, professional cinematography, film still';
    
    return prompt;
  }

  private async generateWithFlux(prompt: string): Promise<string> {
    const response = await fetch('/api/generate-image-flux', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({ prompt })
    });

    if (!response.ok) {
      throw new Error(`FLUX API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.imageUrl;
  }

  private async generateWithStableDiffusion(prompt: string): Promise<string> {
    const response = await fetch('/api/generate-image-sd', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({ prompt })
    });

    if (!response.ok) {
      throw new Error(`Stable Diffusion API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.imageUrl;
  }

  private async generateWithDallE(prompt: string): Promise<string> {
    const modelName = this.config.imageModel.id === 'dall-e-3' ? 'dall-e-3' : 'dall-e-2';
    
    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({
        model: modelName,
        prompt: prompt,
        n: 1,
        size: '1024x1024',
        quality: this.config.imageModel.id === 'dall-e-3' ? 'hd' : 'standard'
      })
    });

    if (!response.ok) {
      throw new Error(`DALL-E API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.data[0].url;
  }

  async batchGenerateImages(frames: StoryboardFrame[]): Promise<{ frameId: string; imageUrl: string; error?: string }[]> {
    console.log(`StoryboardService: Starting batch generation for ${frames.length} frames`);
    
    const results = await Promise.allSettled(
      frames.map(async (frame) => {
        try {
          const imageUrl = await this.generateImage(frame);
          return { frameId: frame.id, imageUrl };
        } catch (error) {
          console.error(`StoryboardService: Batch generation failed for frame ${frame.id}:`, error);
          return { 
            frameId: frame.id, 
            imageUrl: '', 
            error: error instanceof Error ? error.message : 'Unknown error' 
          };
        }
      })
    );

    const finalResults = results.map((result, index) => {
      if (result.status === 'fulfilled') {
        return result.value;
      } else {
        return {
          frameId: frames[index].id,
          imageUrl: '',
          error: result.reason?.message || 'Generation failed'
        };
      }
    });

    console.log(`StoryboardService: Batch generation completed. ${finalResults.filter(r => r.imageUrl).length}/${frames.length} successful`);
    return finalResults;
  }
}

export const createStoryboardService = (apiKey: string, imageModel: ImageModel): StoryboardService => {
  return new StoryboardService({ apiKey, imageModel });
};
