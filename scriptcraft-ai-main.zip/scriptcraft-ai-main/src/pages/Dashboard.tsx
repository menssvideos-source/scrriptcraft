
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  Plus, 
  FileText, 
  Clock, 
  Users, 
  TrendingUp,
  BookOpen,
  Edit3,
  Star
} from 'lucide-react';
import Header from '../components/Header';
import { useScripts } from '../hooks/useScripts';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  const { scripts, loading } = useScripts();

  // Dashboard stats
  const totalScripts = scripts.length;
  const recentScripts = scripts.slice(0, 3);
  const totalWords = scripts.reduce((sum, script) => sum + script.wordCount, 0);
  const starredScripts = scripts.filter(script => script.isStarred).length;

  const stats = [
    {
      title: t('totalScripts'),
      value: totalScripts,
      icon: FileText,
      color: 'text-script-blue-600',
      bgColor: 'bg-script-blue-50'
    },
    {
      title: t('totalWords'),
      value: totalWords.toLocaleString(),
      icon: Edit3,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Storyboards',
      value: '-', // Placeholder - was causing automatic API calls
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      title: t('starredScripts'),
      value: starredScripts,
      icon: Star,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50'
    }
  ];

  const quickActions = [
    {
      title: t('createNewScript'),
      description: t('startNewProject'),
      icon: Plus,
      color: 'bg-gradient-to-r from-script-blue-500 to-script-blue-600',
      action: () => navigate('/new-script')
    },
    {
      title: t('viewAll'),
      description: t('browseLibrary'),
      icon: BookOpen,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      action: () => navigate('/scripts')
    },
    {
      title: t('continueWriting'),
      description: t('resumeLatest'),
      icon: Edit3,
      color: 'bg-gradient-to-r from-purple-500 to-purple-600',
      action: () => recentScripts.length > 0 ? navigate(`/script/${recentScripts[0].id}`) : navigate('/new-script')
    }
  ];

  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-script-slate-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-script-slate-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Welcome Section */}
        <div className={`mb-6 sm:mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl sm:text-4xl font-bold text-script-slate-900 mb-2">
            {t('welcome')} 👋
          </h1>
          <p className="text-lg sm:text-xl text-script-slate-600">
            {t('readyToContinue')}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 sm:p-6">
                <div className={`flex flex-col sm:flex-row sm:items-center justify-between ${isRTL ? 'space-x-reverse' : ''}`}>
                  <div className="mb-2 sm:mb-0">
                    <p className="text-xs sm:text-sm font-medium text-script-slate-600 mb-1">
                      {stat.title}
                    </p>
                    <p className="text-xl sm:text-2xl font-bold text-script-slate-900">
                      {stat.value}
                    </p>
                  </div>
                  <div className={`p-2 sm:p-3 rounded-full ${stat.bgColor} self-start sm:self-auto`}>
                    <stat.icon className={`h-4 w-4 sm:h-6 sm:w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2">
            <h2 className="text-xl sm:text-2xl font-bold text-script-slate-900 mb-4 sm:mb-6">{t('quickActionsTitle')}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6 sm:mb-8">
              {quickActions.map((action, index) => (
                <Card 
                  key={index}
                  className="group cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-[1.02]"
                  onClick={action.action}
                >
                  <CardContent className="p-4 sm:p-6 text-center">
                    <div className={`w-12 h-12 mx-auto mb-4 ${action.color} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <action.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-script-slate-900 mb-2 text-sm sm:text-base">
                      {action.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-script-slate-600">
                      {action.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Scripts */}
            <div>
              <div className={`flex items-center justify-between mb-4 sm:mb-6 ${isRTL ? 'space-x-reverse' : ''}`}>
                <h2 className="text-xl sm:text-2xl font-bold text-script-slate-900">{t('recentScripts')}</h2>
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/scripts')}
                  className="text-script-blue-600 border-script-blue-200 hover:bg-script-blue-50"
                  size="sm"
                >
                  {t('viewAll')}
                </Button>
              </div>
              
              {recentScripts.length === 0 ? (
                <Card className="p-8 text-center">
                  <FileText className="h-12 w-12 text-script-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-script-slate-600 mb-2">No scripts yet</h3>
                  <p className="text-script-slate-500 mb-4">Start your first screenplay project</p>
                  <Button onClick={() => navigate('/new-script')}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create New Script
                  </Button>
                </Card>
              ) : (
                <div className="space-y-4">
                  {recentScripts.map((script) => (
                    <Card 
                      key={script.id}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => navigate(`/script/${script.id}`)}
                    >
                      <CardContent className="p-4">
                        <div className={`flex items-center justify-between ${isRTL ? 'space-x-reverse' : ''}`}>
                          <div className="flex-1 min-w-0">
                            <div className={`flex items-center space-x-3 mb-2 ${isRTL ? 'space-x-reverse' : ''}`}>
                              <h3 className="font-semibold text-script-slate-900 truncate">
                                {script.title}
                              </h3>
                              {script.isStarred && (
                                <Star className="h-4 w-4 text-yellow-500 fill-current flex-shrink-0" />
                              )}
                            </div>
                            <p className="text-sm text-script-slate-600 mb-3 line-clamp-2">
                              {script.description}
                            </p>
                            
                            <div className={`flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-script-slate-500 ${isRTL ? 'space-x-reverse' : ''}`}>
                              <span className="whitespace-nowrap">{t('lastModified')}: {script.lastModified.toLocaleDateString()}</span>
                              <span className="whitespace-nowrap">{script.wordCount.toLocaleString()} {t('words')}</span>
                              <span className="whitespace-nowrap">{script.pageCount} {t('pages')}</span>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2 ml-4 flex-shrink-0">
                            <Badge variant="secondary">
                              {script.template.replace('-', ' ').toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Writing Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-script-slate-900">
                  {t('writingProgress')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className={`flex justify-between text-sm mb-2 ${isRTL ? 'space-x-reverse' : ''}`}>
                      <span className="text-script-slate-600">{t('dailyGoal')}</span>
                      <span className="font-medium">{Math.min(totalWords, 1000)} / 1000 {t('words')}</span>
                    </div>
                    <div className="w-full bg-script-slate-200 rounded-full h-2">
                      <div className="bg-script-blue-500 h-2 rounded-full" style={{ width: `${Math.min((totalWords / 1000) * 100, 100)}%` }}></div>
                    </div>
                  </div>
                  <div>
                    <div className={`flex justify-between text-sm mb-2 ${isRTL ? 'space-x-reverse' : ''}`}>
                      <span className="text-script-slate-600">{t('weeklyGoal')}</span>
                      <span className="font-medium">{Math.min(totalWords, 7000).toLocaleString()} / 7k {t('words')}</span>
                    </div>
                    <div className="w-full bg-script-slate-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: `${Math.min((totalWords / 7000) * 100, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="bg-gradient-to-br from-script-blue-50 to-script-blue-100 border-script-blue-200">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-script-blue-900">
                  💡 {t('writingTip')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-script-blue-800">
                  "{t('writingTipText')}"
                </p>
                <p className="text-xs text-script-blue-600 mt-2">- {t('screenwritingProTip')}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
