
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Pen, BookOpen, Film, Users, Lightbulb } from 'lucide-react';
import Header from '../components/Header';

const Index = () => {
  const { user, loading } = useAuth();
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 flex items-center justify-center ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <div className="animate-pulse text-script-slate-500">
          {isRTL ? 'جاري التحميل...' : 'Loading...'}
        </div>
      </div>
    );
  }

  if (user) {
    return null; // Redirect handled by useEffect
  }

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className={`text-center max-w-4xl mx-auto ${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className={`text-4xl md:text-6xl font-bold text-script-slate-900 mb-6 ${isRTL ? 'text-right' : 'text-left'}`} dir={isRTL ? 'rtl' : 'ltr'}>
            {t('welcomeToScriptCraft')}
          </h1>
          <p className={`text-xl text-script-slate-600 mb-8 ${isRTL ? 'text-right' : 'text-left'}`} dir={isRTL ? 'rtl' : 'ltr'}>
            {t('professionalScreenwriting')}
          </p>
          
          <div className={`flex flex-col sm:flex-row gap-4 justify-center ${isRTL ? 'sm:flex-row-reverse' : ''}`}>
            <Button 
              size="lg"
              className="bg-gradient-to-r from-script-blue-500 to-script-blue-600 hover:from-script-blue-600 hover:to-script-blue-700"
              onClick={() => navigate('/signup')}
            >
              <Pen className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              {t('getStarted')}
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => navigate('/login')}
            >
              <BookOpen className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              {t('signIn')}
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className={`text-3xl font-bold text-center text-script-slate-900 mb-12 ${isRTL ? 'font-arabic' : ''}`}>
          {t('features')}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className={`flex items-center ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                <Film className={`h-6 w-6 text-script-blue-600 ${isRTL ? 'ml-3' : 'mr-3'}`} />
                <span dir={isRTL ? 'rtl' : 'ltr'}>{t('hollywoodFormatting')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-script-slate-600 ${isRTL ? 'text-right font-arabic' : ''}`} dir={isRTL ? 'rtl' : 'ltr'}>
                {t('industryStandardFormatting')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className={`flex items-center ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                <Lightbulb className={`h-6 w-6 text-script-blue-600 ${isRTL ? 'ml-3' : 'mr-3'}`} />
                <span dir={isRTL ? 'rtl' : 'ltr'}>{t('aiPoweredTools')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-script-slate-600 ${isRTL ? 'text-right font-arabic' : ''}`} dir={isRTL ? 'rtl' : 'ltr'}>
                {t('aiAssistance')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className={`flex items-center ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                <Users className={`h-6 w-6 text-script-blue-600 ${isRTL ? 'ml-3' : 'mr-3'}`} />
                <span dir={isRTL ? 'rtl' : 'ltr'}>{t('collaboration')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-script-slate-600 ${isRTL ? 'text-right font-arabic' : ''}`} dir={isRTL ? 'rtl' : 'ltr'}>
                {t('realtimeCollaboration')}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Index;
