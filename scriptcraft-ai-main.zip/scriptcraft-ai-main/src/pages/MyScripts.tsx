
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Plus, FileText } from 'lucide-react';
import ScriptCard from '../components/ScriptCard';
import ScriptSearch from '../components/ScriptSearch';
import Header from '../components/Header';
import { useScriptsOptimized } from '../hooks/useScriptsOptimized';

const MyScripts: React.FC = () => {
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  
  // ✅ Use optimized hook that only fetches metadata
  const { scripts, loading, error, deleteScript, duplicateScript } = useScriptsOptimized();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('lastModified');
  const [filterBy, setFilterBy] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // ✅ Performance monitoring
  React.useEffect(() => {
    const startTime = performance.now();
    console.log('MyScripts: Component mounted, starting script fetch');
    
    return () => {
      const endTime = performance.now();
      console.log(`MyScripts: Component unmounted after ${endTime - startTime}ms`);
    };
  }, []);

  React.useEffect(() => {
    if (!loading && scripts.length > 0) {
      console.log(`MyScripts: Scripts loaded successfully (${scripts.length} scripts)`);
    }
  }, [loading, scripts.length]);

  // ✅ Memoized filtering and sorting to prevent unnecessary recalculations
  const filteredAndSortedScripts = useMemo(() => {
    console.log('MyScripts: Filtering and sorting scripts');
    
    let filtered = scripts.filter(script => {
      const matchesSearch = script.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (script.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
      
      const matchesFilter = filterBy === 'all' || 
                           (filterBy === 'starred' && script.isStarred) ||
                           script.template === filterBy;

      return matchesSearch && matchesFilter;
    });

    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'created':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'wordCount':
          return b.wordCount - a.wordCount;
        case 'lastModified':
        default:
          return new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime();
      }
    });

    console.log(`MyScripts: Filtered to ${filtered.length} scripts`);
    return filtered;
  }, [scripts, searchQuery, sortBy, filterBy]);

  const handleOpenScript = (scriptId: string) => {
    console.log('MyScripts: Opening script:', scriptId);
    navigate(`/script/${scriptId}`);
  };

  const handleDuplicateScript = async (scriptId: string) => {
    try {
      console.log('MyScripts: Duplicating script:', scriptId);
      const newScriptId = await duplicateScript(scriptId);
      console.log('MyScripts: Script duplicated successfully:', newScriptId);
    } catch (error) {
      console.error('MyScripts: Failed to duplicate script:', error);
    }
  };

  const handleDeleteScript = async (scriptId: string) => {
    try {
      console.log('MyScripts: Deleting script:', scriptId);
      await deleteScript(scriptId);
      console.log('MyScripts: Script deleted successfully');
    } catch (error) {
      console.error('MyScripts: Failed to delete script:', error);
    }
  };

  const handleToggleStar = (scriptId: string) => {
    // TODO: Implement star functionality in database
    console.log('MyScripts: Toggle star for script:', scriptId);
  };

  // ✅ Optimized loading state with performance-friendly skeleton
  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-script-slate-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-48 bg-script-slate-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ✅ Error state
  if (error) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="text-center py-12">
            <div className="text-red-500 mb-4">Error loading scripts: {error}</div>
            <Button onClick={() => window.location.reload()}>Retry</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Page Header */}
        <div className={`flex flex-col sm:flex-row sm:items-center justify-between mb-6 sm:mb-8 gap-4 ${isRTL ? 'space-x-reverse' : ''}`}>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-script-slate-900 mb-2">{t('myScripts')}</h1>
            <p className="text-script-slate-600">
              {filteredAndSortedScripts.length} {t('of')} {scripts.length} {t('scriptsCount')}
            </p>
          </div>
          <Button 
            onClick={() => navigate('/new-script')}
            className="bg-gradient-to-r from-script-blue-500 to-script-blue-600 hover:from-script-blue-600 hover:to-script-blue-700 w-full sm:w-auto"
          >
            <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('newScript')}
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="mb-6 sm:mb-8">
          <ScriptSearch
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            sortBy={sortBy}
            onSortChange={setSortBy}
            filterBy={filterBy}
            onFilterChange={setFilterBy}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
          />
        </div>

        {/* Scripts Grid/List */}
        {filteredAndSortedScripts.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-script-slate-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-script-slate-600 mb-2">
              {searchQuery || filterBy !== 'all' ? t('noScriptsFound') : t('noScriptsYet')}
            </h3>
            <p className="text-script-slate-500 mb-6 px-4">
              {searchQuery || filterBy !== 'all' 
                ? t('adjustSearch')
                : t('createFirst')
              }
            </p>
            {!searchQuery && filterBy === 'all' && (
              <Button onClick={() => navigate('/new-script')} className="w-full sm:w-auto">
                <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                {t('createNewScript')}
              </Button>
            )}
          </div>
        ) : (
          <div className={viewMode === 'grid' 
            ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6'
            : 'space-y-4'
          }>
            {filteredAndSortedScripts.map((script) => (
              <ScriptCard
                key={script.id}
                script={script}
                onOpen={handleOpenScript}
                onDuplicate={handleDuplicateScript}
                onDelete={handleDeleteScript}
                onToggleStar={handleToggleStar}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyScripts;
