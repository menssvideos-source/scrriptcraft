
import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { Shield, Lock, Key, Database, Eye, Server } from 'lucide-react';

const Privacy: React.FC = () => {
  const { isRTL } = useLanguage();

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-6">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-script-slate-900 mb-4">Privacy Policy</h1>
            <p className="text-script-slate-600 text-lg">Your privacy is our top priority</p>
            <p className="text-sm text-script-slate-500 mt-2">Last updated: December 24, 2025</p>
          </div>

          {/* Privacy-First Architecture Highlight */}
          <div className="bg-gradient-to-r from-script-blue-50 to-script-blue-100 rounded-lg p-6 mb-8">
            <div className="flex items-center space-x-3 mb-4">
              <Key className="h-6 w-6 text-script-blue-600" />
              <h2 className="text-xl font-semibold text-script-blue-900">BYOK: Your Keys, Your Control</h2>
            </div>
            <p className="text-script-blue-800">
              ScriptCraft AI operates on a "Bring Your Own Key" (BYOK) architecture. This means you provide and control your own API keys for AI services, ensuring your creative content never passes through our servers unnecessarily.
            </p>
          </div>

          <div className="prose prose-lg max-w-none">
            {/* Information We Collect */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Database className="h-6 w-6 mr-3 text-script-blue-600" />
                Information We Collect
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Account Information</h3>
                  <ul className="list-disc list-inside text-script-slate-600 space-y-1">
                    <li>Email address and name for account creation</li>
                    <li>User preferences and settings</li>
                    <li>Login and usage analytics</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Script Content</h3>
                  <ul className="list-disc list-inside text-script-slate-600 space-y-1">
                    <li>Screenplay content you create and save</li>
                    <li>Project metadata (titles, creation dates)</li>
                    <li>Character and story development data</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Technical Information</h3>
                  <ul className="list-disc list-inside text-script-slate-600 space-y-1">
                    <li>Browser type and version</li>
                    <li>Device information and screen resolution</li>
                    <li>IP address and general location</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* API Key Privacy */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Lock className="h-6 w-6 mr-3 text-script-blue-600" />
                API Key Privacy & Security
              </h2>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <h3 className="font-semibold text-green-800 mb-2">🔒 Your API Keys Are Secure</h3>
                <ul className="text-green-700 space-y-1">
                  <li>• Stored encrypted in your browser's local storage only</li>
                  <li>• Never transmitted to or stored on our servers</li>
                  <li>• Direct communication between your browser and AI providers</li>
                  <li>• You maintain full control and can revoke access anytime</li>
                </ul>
              </div>

              <p className="text-script-slate-600 mb-4">
                When you use AI features, your screenplay content is sent directly from your browser to your chosen AI provider (OpenAI, Anthropic, etc.) using your own API keys. We act as a facilitator only - your creative content never touches our servers during AI processing.
              </p>
            </section>

            {/* How We Use Information */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Eye className="h-6 w-6 mr-3 text-script-blue-600" />
                How We Use Your Information
              </h2>
              
              <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                <li>Provide and maintain the ScriptCraft AI service</li>
                <li>Save and sync your screenplay projects</li>
                <li>Improve our features based on usage patterns</li>
                <li>Send important service updates and security notifications</li>
                <li>Provide customer support when requested</li>
              </ul>
            </section>

            {/* Data Sharing */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Server className="h-6 w-6 mr-3 text-script-blue-600" />
                Data Sharing & Third Parties
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">AI Service Providers</h3>
                  <p className="text-script-slate-600">
                    When you use AI features with your own API keys, your content is sent directly to providers like OpenAI, Anthropic, or Replicate. These interactions are governed by their respective privacy policies.
                  </p>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Service Infrastructure</h3>
                  <p className="text-script-slate-600">
                    We use Supabase for database services and user authentication. Your account data is stored securely and is governed by both our privacy policy and Supabase's privacy practices.
                  </p>
                </div>

                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h3 className="font-semibold text-red-800 mb-2">We Never Sell Your Data</h3>
                  <p className="text-red-700">
                    We do not sell, rent, or trade your personal information or screenplay content to third parties for marketing or any other purposes.
                  </p>
                </div>
              </div>
            </section>

            {/* Your Rights */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Your Rights & Controls</h2>
              
              <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                <li><strong>Access:</strong> Request a copy of your personal data</li>
                <li><strong>Correction:</strong> Update or correct your information</li>
                <li><strong>Deletion:</strong> Request deletion of your account and data</li>
                <li><strong>Portability:</strong> Export your screenplay projects</li>
                <li><strong>API Key Control:</strong> Add, remove, or change your API keys anytime</li>
              </ul>
            </section>

            {/* Contact */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Contact Us</h2>
              <p className="text-script-slate-600 mb-4">
                If you have questions about this Privacy Policy or your data, please contact us:
              </p>
              <div className="bg-script-slate-100 rounded-lg p-4">
                <p className="text-script-slate-700">
                  <strong>Email:</strong> privacy@scriptcraft.ai<br/>
                  <strong>Support:</strong> <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact Form</Link>
                </p>
              </div>
            </section>
          </div>

          {/* Footer Navigation */}
          <div className="border-t border-script-slate-200 pt-8 mt-12">
            <div className="flex flex-wrap justify-center space-x-6 text-sm">
              <Link to="/terms" className="text-script-blue-600 hover:text-script-blue-700">Terms of Service</Link>
              <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact</Link>
              <Link to="/setup-guide" className="text-script-blue-600 hover:text-script-blue-700">API Setup Guide</Link>
              <Link to="/user-guide" className="text-script-blue-600 hover:text-script-blue-700">User Guide</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
