
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  Key, 
  ExternalLink, 
  CheckCircle, 
  AlertTriangle, 
  DollarSign, 
  Shield, 
  Zap,
  Image,
  MessageSquare,
  Clock,
  Globe
} from 'lucide-react';

const SetupGuide: React.FC = () => {
  const { isRTL } = useLanguage();
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const toggleStep = (stepId: string) => {
    setCompletedSteps(prev => 
      prev.includes(stepId) 
        ? prev.filter(id => id !== stepId)
        : [...prev, stepId]
    );
  };

  const StepCard = ({ 
    id, 
    title, 
    children, 
    icon: Icon,
    difficulty = 'Easy'
  }: { 
    id: string;
    title: string;
    children: React.ReactNode;
    icon: React.ComponentType<any>;
    difficulty?: string;
  }) => {
    const isCompleted = completedSteps.includes(id);
    
    return (
      <Card className={`transition-all ${isCompleted ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Icon className={`h-6 w-6 ${isCompleted ? 'text-green-600' : 'text-script-blue-600'}`} />
              <CardTitle className="text-xl">{title}</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant={difficulty === 'Easy' ? 'secondary' : 'outline'}>
                {difficulty}
              </Badge>
              <Button
                size="sm"
                variant={isCompleted ? 'default' : 'outline'}
                onClick={() => toggleStep(id)}
                className={isCompleted ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                {isCompleted ? <CheckCircle className="h-4 w-4" /> : 'Mark Complete'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {children}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-6">
            <Key className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-script-slate-900 mb-4">API Keys Setup Guide</h1>
          <p className="text-script-slate-600 text-lg max-w-3xl mx-auto">
            Follow this step-by-step guide to configure your AI service API keys and unlock the full power of ScriptCraft AI's intelligent writing features.
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          <Card className="text-center p-4">
            <Shield className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <h3 className="font-semibold text-script-slate-900">100% Private</h3>
            <p className="text-sm text-script-slate-600">Your keys stay in your browser</p>
          </Card>
          <Card className="text-center p-4">
            <Zap className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <h3 className="font-semibold text-script-slate-900">Direct Access</h3>
            <p className="text-sm text-script-slate-600">Connect directly to AI providers</p>
          </Card>
          <Card className="text-center p-4">
            <DollarSign className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <h3 className="font-semibold text-script-slate-900">Cost Control</h3>
            <p className="text-sm text-script-slate-600">You control all usage costs</p>
          </Card>
          <Card className="text-center p-4">
            <Clock className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <h3 className="font-semibold text-script-slate-900">5 Min Setup</h3>
            <p className="text-sm text-script-slate-600">Quick and easy configuration</p>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="openai">OpenAI Setup</TabsTrigger>
            <TabsTrigger value="replicate">Image Generation</TabsTrigger>
            <TabsTrigger value="troubleshooting">Troubleshooting</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card className="bg-gradient-to-r from-script-blue-50 to-script-blue-100 border-script-blue-200">
              <CardHeader>
                <CardTitle className="text-script-blue-900">What You'll Need</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <MessageSquare className="h-6 w-6 text-script-blue-600 mt-1" />
                    <div>
                      <h4 className="font-semibold text-script-blue-900">Text Generation</h4>
                      <p className="text-script-blue-800 text-sm">OpenAI API key for script writing, character development, and story analysis</p>
                      <div className="mt-2">
                        <Badge variant="secondary">Required for AI features</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Image className="h-6 w-6 text-purple-600 mt-1" />
                    <div>
                      <h4 className="font-semibold text-script-slate-900">Image Generation</h4>
                      <p className="text-script-slate-700 text-sm">Replicate API key for storyboard and character visualization</p>
                      <div className="mt-2">
                        <Badge variant="outline">Optional</Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-4 border border-script-blue-200">
                  <h4 className="font-semibold text-script-blue-900 mb-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Important Security Note
                  </h4>
                  <p className="text-script-blue-800 text-sm">
                    Your API keys are stored encrypted in your browser's local storage only. They never leave your device except to make direct requests to AI providers. We cannot see or access your keys.
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="h-5 w-5 mr-2 text-script-blue-600" />
                    Supported Providers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-script-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">OpenAI</p>
                      <p className="text-sm text-script-slate-600">GPT-4, GPT-3.5 Turbo</p>
                    </div>
                    <Badge>Text AI</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-script-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">Replicate</p>
                      <p className="text-sm text-script-slate-600">FLUX, Stable Diffusion</p>
                    </div>
                    <Badge variant="outline">Image AI</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                    Cost Estimates
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-medium text-green-900">OpenAI Text</p>
                    <p className="text-sm text-green-700">~$0.01-0.03 per script page</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium text-blue-900">Image Generation</p>
                    <p className="text-sm text-blue-700">~$0.10-0.50 per image</p>
                  </div>
                  <p className="text-xs text-script-slate-600">
                    Costs vary by model and usage. You pay providers directly.
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* OpenAI Setup Tab */}
          <TabsContent value="openai" className="space-y-6">
            <StepCard id="openai-account" title="Create OpenAI Account" icon={MessageSquare}>
              <div className="space-y-4">
                <p className="text-script-slate-600">
                  First, you'll need an OpenAI account to access their API services.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-script-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-script-blue-600 mt-0.5">1</div>
                    <div>
                      <p className="font-medium">Visit OpenAI Platform</p>
                      <p className="text-sm text-script-slate-600">Go to platform.openai.com and sign up for an account</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-script-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-script-blue-600 mt-0.5">2</div>
                    <div>
                      <p className="font-medium">Add Payment Method</p>
                      <p className="text-sm text-script-slate-600">Add a credit card to your account for API usage billing</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-script-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-script-blue-600 mt-0.5">3</div>
                    <div>
                      <p className="font-medium">Set Usage Limits</p>
                      <p className="text-sm text-script-slate-600">Set monthly spending limits to control costs</p>
                    </div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <a href="https://platform.openai.com" target="_blank" rel="noopener noreferrer">
                    Open OpenAI Platform <ExternalLink className="h-4 w-4 ml-2" />
                  </a>
                </Button>
              </div>
            </StepCard>

            <StepCard id="openai-api-key" title="Generate API Key" icon={Key}>
              <div className="space-y-4">
                <p className="text-script-slate-600">
                  Create an API key to connect ScriptCraft AI to OpenAI's services.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600 mt-0.5">1</div>
                    <div>
                      <p className="font-medium">Navigate to API Keys</p>
                      <p className="text-sm text-script-slate-600">In your OpenAI dashboard, go to API Keys section</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600 mt-0.5">2</div>
                    <div>
                      <p className="font-medium">Create New Key</p>
                      <p className="text-sm text-script-slate-600">Click "Create new secret key" and give it a descriptive name</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600 mt-0.5">3</div>
                    <div>
                      <p className="font-medium">Copy and Save</p>
                      <p className="text-sm text-script-slate-600">Copy the key immediately - you won't be able to see it again!</p>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-yellow-800">Security Tip</p>
                      <p className="text-sm text-yellow-700">
                        Your API key starts with "sk-" and is about 50 characters long. Keep it secure and never share it publicly.
                      </p>
                    </div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer">
                    Go to API Keys <ExternalLink className="h-4 w-4 ml-2" />
                  </a>
                </Button>
              </div>
            </StepCard>

            <StepCard id="openai-configure" title="Add Key to ScriptCraft AI" icon={CheckCircle}>
              <div className="space-y-4">
                <p className="text-script-slate-600">
                  Now add your OpenAI API key to ScriptCraft AI to enable AI features.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center text-sm font-semibold text-purple-600 mt-0.5">1</div>
                    <div>
                      <p className="font-medium">Go to Dashboard</p>
                      <p className="text-sm text-script-slate-600">Navigate to your ScriptCraft AI dashboard</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center text-sm font-semibold text-purple-600 mt-0.5">2</div>
                    <div>
                      <p className="font-medium">Open AI Panel</p>
                      <p className="text-sm text-script-slate-600">Click on any AI feature or go to Settings → API Keys</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center text-sm font-semibold text-purple-600 mt-0.5">3</div>
                    <div>
                      <p className="font-medium">Paste Your Key</p>
                      <p className="text-sm text-script-slate-600">Paste your OpenAI API key and click Save</p>
                    </div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <Link to="/dashboard">
                    Go to Dashboard <ExternalLink className="h-4 w-4 ml-2" />
                  </Link>
                </Button>
              </div>
            </StepCard>
          </TabsContent>

          {/* Replicate Setup Tab */}
          <TabsContent value="replicate" className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-900">Image Generation Setup</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-purple-800 mb-4">
                  Replicate provides access to state-of-the-art image generation models for creating storyboards and character visualizations.
                </p>
                <Badge variant="outline">Optional - Only needed for visual features</Badge>
              </CardContent>
            </Card>

            <StepCard id="replicate-account" title="Create Replicate Account" icon={Image}>
              <div className="space-y-4">
                <p className="text-script-slate-600">
                  Sign up for Replicate to access powerful image generation models.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center text-sm font-semibold text-purple-600 mt-0.5">1</div>
                    <div>
                      <p className="font-medium">Visit Replicate</p>
                      <p className="text-sm text-script-slate-600">Go to replicate.com and create an account</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center text-sm font-semibold text-purple-600 mt-0.5">2</div>
                    <div>
                      <p className="font-medium">Add Billing Info</p>
                      <p className="text-sm text-script-slate-600">Add payment method for pay-per-use billing</p>
                    </div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <a href="https://replicate.com" target="_blank" rel="noopener noreferrer">
                    Open Replicate <ExternalLink className="h-4 w-4 ml-2" />
                  </a>
                </Button>
              </div>
            </StepCard>

            <StepCard id="replicate-token" title="Get API Token" icon={Key}>
              <div className="space-y-4">
                <p className="text-script-slate-600">
                  Generate an API token to connect to Replicate's image generation services.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-blue-600 mt-0.5">1</div>
                    <div>
                      <p className="font-medium">Go to API Tokens</p>
                      <p className="text-sm text-script-slate-600">Navigate to your account settings → API tokens</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-blue-600 mt-0.5">2</div>
                    <div>
                      <p className="font-medium">Create Token</p>
                      <p className="text-sm text-script-slate-600">Click "Create token" and copy the generated token</p>
                    </div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <a href="https://replicate.com/account/api-tokens" target="_blank" rel="noopener noreferrer">
                    Go to API Tokens <ExternalLink className="h-4 w-4 ml-2" />
                  </a>
                </Button>
              </div>
            </StepCard>
          </TabsContent>

          {/* Troubleshooting Tab */}
          <TabsContent value="troubleshooting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
                  Common Issues & Solutions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="border-l-4 border-red-500 pl-4">
                    <h4 className="font-semibold text-script-slate-900">❌ "Invalid API Key" Error</h4>
                    <p className="text-script-slate-600 text-sm mb-2">Check these common issues:</p>
                    <ul className="text-script-slate-600 text-sm space-y-1 list-disc list-inside">
                      <li>Ensure the key starts with "sk-" for OpenAI</li>
                      <li>Check for extra spaces when copying/pasting</li>
                      <li>Verify the key hasn't been revoked or expired</li>
                      <li>Confirm billing is set up on your AI provider account</li>
                    </ul>
                  </div>

                  <div className="border-l-4 border-yellow-500 pl-4">
                    <h4 className="font-semibold text-script-slate-900">⚠️ "Quota Exceeded" Error</h4>
                    <p className="text-script-slate-600 text-sm mb-2">You've hit usage limits:</p>
                    <ul className="text-script-slate-600 text-sm space-y-1 list-disc list-inside">
                      <li>Check your usage on the AI provider's dashboard</li>
                      <li>Increase your monthly spending limit if needed</li>
                      <li>Wait for the quota to reset (usually monthly)</li>
                    </ul>
                  </div>

                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-semibold text-script-slate-900">🔄 "Network Error" Issues</h4>
                    <p className="text-script-slate-600 text-sm mb-2">Connection problems:</p>
                    <ul className="text-script-slate-600 text-sm space-y-1 list-disc list-inside">
                      <li>Check your internet connection</li>
                      <li>Try refreshing the page</li>
                      <li>Disable VPN if using one</li>
                      <li>Check if your firewall is blocking API calls</li>
                    </ul>
                  </div>

                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-semibold text-script-slate-900">💡 Best Practices</h4>
                    <ul className="text-script-slate-600 text-sm space-y-1 list-disc list-inside">
                      <li>Start with small usage limits and increase as needed</li>
                      <li>Monitor your usage regularly on provider dashboards</li>
                      <li>Keep your API keys secure and rotate them periodically</li>
                      <li>Test with simple prompts before complex operations</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-script-slate-50 rounded-lg p-4">
                  <h4 className="font-semibold text-script-slate-900 mb-2">Still Having Issues?</h4>
                  <p className="text-script-slate-600 text-sm mb-4">
                    If you're still experiencing problems, our support team is here to help.
                  </p>
                  <Button asChild>
                    <Link to="/contact">
                      Contact Support <ExternalLink className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Progress Summary */}
        <Card className="mt-12 bg-gradient-to-r from-green-50 to-green-100 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-green-900">Setup Progress</h3>
                <p className="text-green-700">
                  {completedSteps.length} of 6 steps completed
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-600">
                  {Math.round((completedSteps.length / 6) * 100)}%
                </div>
                <p className="text-sm text-green-700">Complete</p>
              </div>
            </div>
            
            {completedSteps.length === 6 && (
              <div className="mt-4 p-4 bg-green-600 rounded-lg text-white">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-semibold">Congratulations! Setup Complete</span>
                </div>
                <p className="text-sm mt-1">
                  You're ready to start using all of ScriptCraft AI's features.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer Navigation */}
        <div className="border-t border-script-slate-200 pt-8 mt-12">
          <div className="flex flex-wrap justify-center space-x-6 text-sm">
            <Link to="/user-guide" className="text-script-blue-600 hover:text-script-blue-700">User Guide</Link>
            <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact Support</Link>
            <Link to="/privacy" className="text-script-blue-600 hover:text-script-blue-700">Privacy Policy</Link>
            <Link to="/terms" className="text-script-blue-600 hover:text-script-blue-700">Terms of Service</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SetupGuide;
