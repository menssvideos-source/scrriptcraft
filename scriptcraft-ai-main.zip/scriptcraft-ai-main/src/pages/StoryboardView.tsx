import React from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { StoryboardGenerationProvider } from '../contexts/StoryboardGenerationContext';
import Header from '../components/Header';
import { StoryboardFrame, StoryboardGenerator } from '../lib/storyboard';
import { ImageStorageService } from '../lib/imageStorage';
import { AVAILABLE_IMAGE_MODELS } from '../contexts/APIKeyContext';
import StoryboardHeader from '../components/StoryboardView/StoryboardHeader';
import StoryboardProgressIndicator from '../components/StoryboardView/StoryboardProgressIndicator';
import StoryboardInfoBanner from '../components/StoryboardView/StoryboardInfoBanner';
import StoryboardGrid from '../components/StoryboardView/StoryboardGrid';
import EmptyStoryboard from '../components/StoryboardView/EmptyStoryboard';
import { DownloadService } from '../lib/downloadService';
import { toast } from '../components/ui/sonner';

const StoryboardViewContent: React.FC = () => {
  const { id } = useParams();
  const { isRTL } = useLanguage();
  const [searchParams] = useSearchParams();
  const isGenerating = searchParams.get('generating') === 'true';
  
  const [storyboardFrames, setStoryboardFrames] = React.useState<StoryboardFrame[]>([]);
  const [refreshKey, setRefreshKey] = React.useState(0);
  const [regeneratingImages, setRegeneratingImages] = React.useState(false);
  const [imageErrors, setImageErrors] = React.useState<Set<string>>(new Set());
  const [loading, setLoading] = React.useState(true);

  // Enhanced loading logic that prioritizes Supabase storage
  React.useEffect(() => {
    const loadStoryboardData = async () => {
      if (!id) return;
      
      setLoading(true);
      console.log(`Loading storyboard data for script: ${id}`);
      
      try {
        // Always check Supabase first for stored images
        const imageStorage = new ImageStorageService();
        const storedImages = await imageStorage.getStoredImages(id);
        
        if (storedImages.length > 0) {
          console.log(`Found ${storedImages.length} stored images in Supabase`);
          
          // Convert stored images back to frames with proper metadata
          const frames: StoryboardFrame[] = storedImages.map(img => ({
            id: img.frame_id,
            sceneId: img.frame_id,
            sceneNumber: img.scene_number,
            title: img.title,
            visualDescription: 'AI-generated storyboard frame',
            shotType: 'Multi-Panel Layout',
            cameraAngle: 'Various Angles',
            mood: 'Cinematic',
            lighting: 'Dynamic',
            composition: '3-panel storyboard layout',
            panelCount: 3,
            keyMoments: [],
            imageUrl: ''
          }));
          
          // Load the actual image URLs from storage
          const apiKey = localStorage.getItem('openai-api-key') || 'temp';
          const defaultImageModel = AVAILABLE_IMAGE_MODELS[0]; // Use the complete DALL-E 3 model
          const generator = new StoryboardGenerator(apiKey, defaultImageModel);
          const framesWithStoredImages = await generator.loadStoredImages(id, frames);
          setStoryboardFrames(framesWithStoredImages);
          
          // Clear any old localStorage data that might have expired URLs
          localStorage.removeItem(`storyboard-${id}`);
          console.log('Successfully loaded stored images from Supabase and cleared localStorage cache');
        } else {
          // No stored images, check localStorage but validate URLs
          const savedStoryboard = localStorage.getItem(`storyboard-${id}`);
          if (savedStoryboard) {
            try {
              const parsedStoryboard = JSON.parse(savedStoryboard);
              
              // Check for expired DALL-E URLs and clear them
              const cleanedFrames = parsedStoryboard.map((frame: StoryboardFrame) => {
                // Remove any expired DALL-E URLs
                if (frame.imageUrl && (
                  frame.imageUrl.includes('oaidalleapiprodscus') ||
                  frame.imageUrl.includes('blob.core.windows.net')
                )) {
                  console.log(`Removing expired URL for frame ${frame.id}`);
                  return { ...frame, imageUrl: undefined };
                }
                return frame;
              });
              
              setStoryboardFrames(cleanedFrames);
              // Update localStorage with cleaned data
              localStorage.setItem(`storyboard-${id}`, JSON.stringify(cleanedFrames));
              console.log(`Loaded and cleaned ${cleanedFrames.length} frames from localStorage`);
            } catch (error) {
              console.error('Failed to parse localStorage storyboard:', error);
              localStorage.removeItem(`storyboard-${id}`);
              setStoryboardFrames([]);
            }
          } else {
            console.log('No storyboard data found');
            setStoryboardFrames([]);
          }
        }
      } catch (error) {
        console.error('Failed to load storyboard data:', error);
        setStoryboardFrames([]);
      } finally {
        setLoading(false);
      }
    };

    loadStoryboardData();
  }, [id, refreshKey]);

  const handleRefresh = () => {
    console.log('Refreshing storyboard data...');
    setRefreshKey(prev => prev + 1);
    setImageErrors(new Set());
  };

  const handleImageError = (frameId: string) => {
    console.log(`Image failed to load for frame: ${frameId}`);
    setImageErrors(prev => new Set([...prev, frameId]));
  };

  const handleImageLoad = (frameId: string) => {
    console.log(`Image loaded successfully for frame: ${frameId}`);
    setImageErrors(prev => {
      const newSet = new Set(prev);
      newSet.delete(frameId);
      return newSet;
    });
  };

  const regenerateFailedImages = async () => {
    const apiKey = localStorage.getItem('openai-api-key');
    if (!apiKey) {
      toast.error('Please set your API key in the script editor first');
      return;
    }

    if (!id) {
      toast.error('No script ID found');
      return;
    }

    setRegeneratingImages(true);
    
    try {
      const defaultImageModel = AVAILABLE_IMAGE_MODELS[0]; // Use the complete DALL-E 3 model
      const generator = new StoryboardGenerator(apiKey, defaultImageModel);
      const framesToRegenerate = storyboardFrames.filter(frame => 
        imageErrors.has(frame.id) || !frame.imageUrl || frame.imageError
      );

      if (framesToRegenerate.length === 0) {
        toast.info('No images need to be regenerated');
        return;
      }

      console.log(`Regenerating images for ${framesToRegenerate.length} frames with immediate storage`);
      toast.info(`Regenerating ${framesToRegenerate.length} failed images...`);

      const updatedFrames = await generator.generateImagesForFrames(
        framesToRegenerate,
        id,
        (progressFrames) => {
          // Update frames with new images as they're generated and stored
          setStoryboardFrames(currentFrames => {
            const newFrames = [...currentFrames];
            progressFrames.forEach(updatedFrame => {
              const index = newFrames.findIndex(f => f.id === updatedFrame.id);
              if (index !== -1) {
                newFrames[index] = updatedFrame;
              }
            });
            return newFrames;
          });
        }
      );

      // Update localStorage with regenerated data
      localStorage.setItem(`storyboard-${id}`, JSON.stringify(updatedFrames));

      // Clear image errors
      setImageErrors(new Set());
      
      console.log('Image regeneration completed with immediate storage');
      toast.success(`Successfully regenerated ${framesToRegenerate.length} images!`);
      
    } catch (error) {
      console.error('Failed to regenerate images:', error);
      toast.error(`Failed to regenerate images: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setRegeneratingImages(false);
    }
  };

  const handleDownloadImages = async () => {
    const framesWithImages = storyboardFrames.filter(frame => frame.imageUrl);
    
    if (framesWithImages.length === 0) {
      toast.error('No images available to download');
      return;
    }

    try {
      toast.info(`Downloading ${framesWithImages.length} storyboard images...`);
      await DownloadService.downloadAllImages(framesWithImages, `Script-${id}`);
      toast.success(`Successfully downloaded ${framesWithImages.length} storyboard images!`);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error(`Download failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'} w-full`}>
        <Header />
        <div className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8">
          <div className="flex items-center justify-center min-h-96">
            <div className="flex flex-col items-center space-y-4">
              <div className="animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-script-blue-600"></div>
              <div className="text-script-slate-500 text-sm sm:text-base">Loading storyboard...</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const framesWithImages = storyboardFrames.filter(frame => frame.imageUrl && !imageErrors.has(frame.id));
  const framesGenerating = storyboardFrames.filter(frame => frame.isGeneratingImage);
  const framesWithErrors = storyboardFrames.filter(frame => imageErrors.has(frame.id) || frame.imageError);
  const hasFailedImages = framesWithErrors.length > 0 || storyboardFrames.some(f => !f.imageUrl);

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'} w-full`}>
      <Header />
      
      <div className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8 max-w-7xl">
        <div className="space-y-4 sm:space-y-6">
          <StoryboardHeader
            scriptId={id || ''}
            onRefresh={handleRefresh}
            onRegenerateImages={regenerateFailedImages}
            onDownloadImages={handleDownloadImages}
            regeneratingImages={regeneratingImages}
            totalFrames={storyboardFrames.length}
            framesWithImages={framesWithImages.length}
            framesWithErrors={framesWithErrors.length}
            framesGenerating={framesGenerating.length}
            hasFailedImages={hasFailedImages}
          />

          {/* Enhanced Progress Indicator */}
          <StoryboardProgressIndicator />

          <StoryboardInfoBanner framesWithErrors={framesWithErrors.length} />

          {storyboardFrames.length === 0 ? (
            <EmptyStoryboard scriptId={id || ''} />
          ) : (
            <StoryboardGrid
              frames={storyboardFrames}
              imageErrors={imageErrors}
              onImageError={handleImageError}
              onImageLoad={handleImageLoad}
            />
          )}
        </div>
      </div>
    </div>
  );
};

const StoryboardView: React.FC = () => {
  return (
    <StoryboardGenerationProvider>
      <StoryboardViewContent />
    </StoryboardGenerationProvider>
  );
};

export default StoryboardView;
