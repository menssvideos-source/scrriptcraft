
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { LoginPage } from '../components/auth/LoginPage';

const Login: React.FC = () => {
  const { isRTL } = useLanguage();
  const { signIn, signInWithGoogle, user } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleEmailLogin = async (email: string, password: string) => {
    setIsLoading(true);
    const { error } = await signIn(email, password);
    
    if (error) {
      console.error('Login error:', error);
      if (error.message.includes('Invalid login credentials')) {
        toast.error('Invalid email or password. Please try again.');
      } else if (error.message.includes('Email not confirmed')) {
        toast.error('Please check your email and click the confirmation link before signing in.');
      } else {
        toast.error('Login failed. Please try again.');
      }
    } else {
      toast.success('Welcome back!');
      navigate('/dashboard');
    }
    
    setIsLoading(false);
  };

  const handleGoogleLogin = async () => {
    setIsGoogleLoading(true);
    try {
      const { error } = await signInWithGoogle();
      
      if (error) {
        console.error('Google login error:', error);
        toast.error('Google login failed. Please try again.');
      }
      // If successful, user will be redirected automatically by auth state change
    } catch (error) {
      console.error('Google login error:', error);
      toast.error('An unexpected error occurred during Google login.');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  return (
    <LoginPage
      isRTL={isRTL}
      onEmailLogin={handleEmailLogin}
      onGoogleLogin={handleGoogleLogin}
      isLoading={isLoading}
      isGoogleLoading={isGoogleLoading}
    />
  );
};

export default Login;
