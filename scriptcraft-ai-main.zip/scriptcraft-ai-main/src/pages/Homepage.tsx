
import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  FileText, 
  Users, 
  Globe, 
  Shield, 
  Zap, 
  BookOpen,
  Edit,
  Camera,
  Star,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Brain,
  TreePine,
  User,
  Play,
  Lock,
  DollarSign,
  Eye,
  Workflow
} from 'lucide-react';

const Homepage: React.FC = () => {
  const { user, loading } = useAuth();
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  // Show loading state while checking auth
  if (loading) {
    return (
      <div className="min-h-screen bg-script-slate-50 flex items-center justify-center">
        <div className="animate-pulse text-script-slate-500">Loading...</div>
      </div>
    );
  }

  // Don't render if user is authenticated (redirect is in progress)
  if (user) {
    return null;
  }

  const workflowPhases = [
    {
      icon: Brain,
      phase: '1',
      title: 'AI-Powered Brainstorming',
      description: 'Generate compelling story ideas, develop loglines, and explore themes with advanced AI assistance.',
      features: ['AI story idea generation', 'Smart logline development', 'Theme exploration', 'Premise refinement']
    },
    {
      icon: TreePine,
      phase: '2', 
      title: 'Intelligent Structure Planning',
      description: 'Build your three-act structure with AI-guided plot points and story arcs.',
      features: ['AI three-act breakdown', 'Smart plot point mapping', 'Story arc development', 'AI pacing analysis']
    },
    {
      icon: User,
      phase: '3',
      title: 'AI Character Development',
      description: 'Create rich, multi-dimensional characters with AI-generated backstories and motivations.',
      features: ['AI character profiling', 'Smart backstory creation', 'Motivation mapping', 'Character relationship analysis']
    },
    {
      icon: Edit,
      phase: '4',
      title: 'AI-Enhanced Writing',
      description: 'Write your screenplay with AI suggestions, industry-standard formatting, and real-time collaboration.',
      features: ['AI writing assistance', 'Professional formatting', 'Live collaboration', 'Smart export options']
    }
  ];

  const coreFeatures = [
    {
      icon: Workflow,
      title: 'AI-Guided 4-Phase Workflow',
      description: 'Intelligent workflow system that guides you from initial idea to final script with AI assistance at every step.'
    },
    {
      icon: Sparkles,
      title: 'Advanced AI Creative Tools',
      description: 'Get intelligent suggestions for story ideas, character development, and scene enhancement using cutting-edge AI models.'
    },
    {
      icon: Camera,
      title: 'AI Visual Storyboard Generation',
      description: 'Transform your screenplay scenes into cinematic storyboard images with multiple AI image generation models.'
    },
    {
      icon: FileText,
      title: 'Industry-Standard Formatting',
      description: 'Automatic Hollywood-style formatting for scene headings, dialogue, and action lines powered by AI.'
    },
    {
      icon: Users,
      title: 'Real-time Collaboration',
      description: 'Work seamlessly with co-writers and team members with live editing and AI-powered shared workspaces.',
      comingSoon: true
    },
    {
      icon: Lock,
      title: 'Complete Privacy Control',
      description: 'Your scripts and API keys never touch our servers. Full BYOK architecture for maximum AI privacy.'
    }
  ];

  const privacyBenefits = [
    'Bring Your Own AI API Keys (BYOK)',
    'Zero-knowledge AI architecture',
    'Direct AI API connections only',
    'Complete AI cost transparency',
    'GDPR compliant AI data handling',
    'Encrypted local AI key storage'
  ];

  return (
    <div className={`min-h-screen bg-gradient-to-br from-script-slate-50 to-white ${isRTL ? 'font-arabic' : 'font-script'}`}>
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm border-b border-script-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse' : ''}`}>
              <div className="w-8 h-8 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">SA</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-script-slate-900">ScriptCraft AI</h1>
              </div>
            </div>

            <div className={`flex items-center space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
              <Button variant="ghost" onClick={() => navigate('/login')}>
                Sign In
              </Button>
              <Button onClick={() => navigate('/signup')} className="bg-script-blue-500 hover:bg-script-blue-600">
                Start Writing
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <Badge className="mb-4 bg-script-blue-100 text-script-blue-700 hover:bg-script-blue-200">
              <Workflow className="h-3 w-3 mr-1" />
              AI-Powered 4-Phase Workflow
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold text-script-slate-900 mb-6">
              From Idea to Screenplay
              <span className="block text-script-blue-600">With AI & Complete Privacy</span>
            </h1>
            
            <p className="text-xl text-script-slate-600 mb-8 max-w-3xl mx-auto">
              An AI-powered 4-phase approach to screenwriting with intelligent creative assistance, real-time collaboration, 
              and absolute privacy control. Your creativity, your data, your AI keys.
            </p>

            <div className={`flex flex-col sm:flex-row gap-4 justify-center mb-12 ${isRTL ? 'sm:flex-row-reverse' : ''}`}>
              <Button 
                size="lg" 
                onClick={() => navigate('/signup')}
                className="bg-script-blue-500 hover:bg-script-blue-600 text-lg px-8 py-3"
              >
                Start Your First Script
                <ArrowRight className={`h-5 w-5 ${isRTL ? 'mr-2' : 'ml-2'}`} />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/login')}
                className="text-lg px-8 py-3"
              >
                <Play className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                See Live Demo
              </Button>
            </div>

            {/* Workflow Preview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {workflowPhases.map((phase, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-script-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <phase.icon className="h-6 w-6 text-script-blue-600" />
                  </div>
                  <div className="text-sm font-medium text-script-slate-700">{phase.title}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Workflow Details Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-script-slate-900 mb-4">
              AI-Guided 4-Phase Workflow
            </h2>
            <p className="text-xl text-script-slate-600 max-w-3xl mx-auto">
              Our AI-powered structured approach ensures you develop every aspect of your screenplay with intelligent assistance.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {workflowPhases.map((phase, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-script-blue-100 rounded-lg flex items-center justify-center">
                      <phase.icon className="h-6 w-6 text-script-blue-600" />
                    </div>
                    <div>
                      <Badge variant="outline" className="mb-2">Phase {phase.phase}</Badge>
                      <CardTitle className="text-xl">{phase.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-script-slate-600 mb-4">
                    {phase.description}
                  </CardDescription>
                  <div className="grid grid-cols-2 gap-2">
                    {phase.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center text-sm text-script-slate-600">
                        <CheckCircle className="h-3 w-3 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Core Features Section */}
      <section className="py-20 bg-script-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-script-slate-900 mb-4">
              AI-Powered Tools for Modern Screenwriters
            </h2>
            <p className="text-xl text-script-slate-600 max-w-3xl mx-auto">
              Everything you need to create industry-standard screenplays with AI assistance and complete privacy.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {coreFeatures.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-script-blue-100 rounded-lg flex items-center justify-center">
                      <feature.icon className="h-6 w-6 text-script-blue-600" />
                    </div>
                    {feature.comingSoon && (
                      <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200">
                        Coming Soon
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-script-slate-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced BYOK Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-green-100 text-green-700">
              <Shield className="h-3 w-3 mr-1" />
              Zero-Knowledge AI Architecture
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-script-slate-900 mb-4">
              Your Data, Your AI, Your Control
            </h2>
            <p className="text-xl text-script-slate-600 max-w-3xl mx-auto">
              Unlike other platforms, we never see your scripts or AI keys. Everything stays in your control.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-script-slate-900 mb-6">
                Why AI Privacy Matters in Creative Work
              </h3>
              <div className="space-y-4">
                {privacyBenefits.map((benefit, index) => (
                  <div key={index} className={`flex items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <CheckCircle className={`h-5 w-5 text-green-500 ${isRTL ? 'ml-3' : 'mr-3'} flex-shrink-0`} />
                    <span className="text-script-slate-700">{benefit}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-green-50 rounded-lg">
                <div className="flex items-center mb-2">
                  <DollarSign className="h-4 w-4 text-green-600 mr-2" />
                  <span className="font-medium text-green-800">AI Cost Transparency</span>
                </div>
                <p className="text-sm text-green-700">
                  See exactly what each AI operation costs. No hidden fees, no markup on AI API usage.
                </p>
              </div>
            </div>

            <Card className="p-6">
              <h4 className="font-bold text-script-slate-900 mb-4">How Our AI Privacy Model Works</h4>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-blue-600">1</span>
                  </div>
                  <div>
                    <p className="font-medium">You provide your AI API keys</p>
                    <p className="text-sm text-script-slate-600">Stored encrypted on your device only</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-blue-600">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Direct AI API connections</p>
                    <p className="text-sm text-script-slate-600">Your browser talks directly to AI providers</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-blue-600">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Scripts stay private</p>
                    <p className="text-sm text-script-slate-600">Stored in your Supabase account, not ours</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 p-3 bg-script-slate-50 rounded-md">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">AI Privacy Level</span>
                  <Badge className="bg-green-600">Maximum</Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-script-blue-600 to-script-blue-700">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Write Your AI-Powered Screenplay?
          </h2>
          <p className="text-xl text-script-blue-100 mb-8">
            Join screenwriters who value both AI-enhanced creativity and complete privacy control.
          </p>
          
          <div className={`flex flex-col sm:flex-row gap-4 justify-center ${isRTL ? 'sm:flex-row-reverse' : ''}`}>
            <Button 
              size="lg" 
              onClick={() => navigate('/signup')}
              className="bg-white text-script-blue-600 hover:bg-script-slate-50 text-lg px-8 py-3"
            >
              Start Your First Script
              <ArrowRight className={`h-5 w-5 ${isRTL ? 'mr-2' : 'ml-2'}`} />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => navigate('/login')}
              className="border-white text-white hover:bg-white hover:text-script-blue-600 text-lg px-8 py-3"
            >
              Sign In
            </Button>
          </div>

          <div className="mt-8 flex items-center justify-center space-x-6 text-script-blue-200 text-sm">
            <div className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-1" />
              Free to start
            </div>
            <div className="flex items-center">
              <Eye className="h-4 w-4 mr-1" />
              AI-private by design
            </div>
            <div className="flex items-center">
              <Zap className="h-4 w-4 mr-1" />
              AI-powered workflow
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-script-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className={`flex items-center justify-center space-x-3 mb-4 ${isRTL ? 'space-x-reverse' : ''}`}>
              <div className="w-8 h-8 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">SA</span>
              </div>
              <span className="text-xl font-bold">ScriptCraft AI</span>
            </div>
            <p className="text-script-slate-400 mb-6">
              AI-powered screenplay writing with complete privacy control
            </p>
            <div className={`flex justify-center space-x-6 ${isRTL ? 'space-x-reverse' : ''}`}>
              <Link to="/privacy" className="text-script-slate-400 hover:text-white">Privacy Policy</Link>
              <Link to="/terms" className="text-script-slate-400 hover:text-white">Terms of Service</Link>
              <Link to="/contact" className="text-script-slate-400 hover:text-white">Contact</Link>
              <Link to="/setup-guide" className="text-script-slate-400 hover:text-white">Setup Guide</Link>
              <Link to="/user-guide" className="text-script-slate-400 hover:text-white">User Guide</Link>
            </div>
            <p className="text-script-slate-500 mt-6 text-sm">
              © 2024 ScriptCraft AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;
