
import React, { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { ArrowLeft, Save, Plus } from 'lucide-react';
import Header from '../components/Header';
import ScriptEditorCore from '../components/ScriptEditor/ScriptEditorCore';

const ScriptEditorPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  const [scriptTitle, setScriptTitle] = useState('');

  console.log('ScriptEditor: Loading full editor for script ID:', id);

  // Early validation of script ID
  if (!id) {
    console.log('ScriptEditor: No script ID, redirecting to scripts');
    navigate('/scripts', { replace: true });
    return null;
  }

  const handleTitleChange = useCallback((newTitle: string) => {
    setScriptTitle(newTitle);
  }, []);

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'} w-full flex flex-col`}>
      <Header />
      
      <div className="flex-1 flex flex-col">
        {/* Navigation Header */}
        <div className="bg-white border-b border-script-slate-200 px-4 py-3 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/scripts')}
                className="text-script-slate-600 hover:text-script-slate-900"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Scripts
              </Button>
              <div className="h-4 w-px bg-script-slate-300"></div>
              <h1 className="text-lg font-semibold text-script-slate-900">
                {scriptTitle || 'Script Editor'}
              </h1>
            </div>
          </div>
        </div>

        {/* Script Editor Core */}
        <ScriptEditorCore onTitleChange={handleTitleChange} />
      </div>
    </div>
  );
};

export default ScriptEditorPage;
