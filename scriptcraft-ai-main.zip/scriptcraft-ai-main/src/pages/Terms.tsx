
import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { FileText, Users, AlertTriangle, Scale, Crown, Shield } from 'lucide-react';

const Terms: React.FC = () => {
  const { isRTL } = useLanguage();

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-6">
              <FileText className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-script-slate-900 mb-4">Terms of Service</h1>
            <p className="text-script-slate-600 text-lg">Agreement for using ScriptCraft AI</p>
            <p className="text-sm text-script-slate-500 mt-2">Last updated: December 24, 2025</p>
          </div>

          <div className="prose prose-lg max-w-none">
            {/* Acceptance */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Scale className="h-6 w-6 mr-3 text-script-blue-600" />
                Agreement to Terms
              </h2>
              <p className="text-script-slate-600 mb-4">
                By accessing and using ScriptCraft AI, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using this service.
              </p>
            </section>

            {/* Service Description */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Crown className="h-6 w-6 mr-3 text-script-blue-600" />
                Service Description
              </h2>
              <p className="text-script-slate-600 mb-4">
                ScriptCraft AI is a professional screenplay writing application that provides:
              </p>
              <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                <li>Industry-standard screenplay formatting tools</li>
                <li>AI-powered writing assistance using your own API keys</li>
                <li>Character development and story planning features</li>
                <li>Storyboard generation capabilities</li>
                <li>Cloud storage for your screenplay projects</li>
                <li>Collaborative writing features</li>
              </ul>
            </section>

            {/* User Accounts */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Users className="h-6 w-6 mr-3 text-script-blue-600" />
                User Accounts & Responsibilities
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Account Security</h3>
                  <ul className="list-disc list-inside text-script-slate-600 space-y-1">
                    <li>You are responsible for maintaining the confidentiality of your account</li>
                    <li>You must provide accurate and complete information</li>
                    <li>You must notify us immediately of any unauthorized access</li>
                    <li>You are responsible for all activities under your account</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">API Key Management</h3>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Important Responsibilities</h4>
                    <ul className="text-yellow-700 space-y-1">
                      <li>• You are solely responsible for your AI service API keys</li>
                      <li>• You must comply with all AI provider terms of service</li>
                      <li>• You are responsible for all API usage costs</li>
                      <li>• Keep your API keys secure and never share them</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Intellectual Property */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Intellectual Property Rights</h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Your Content</h3>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-green-800">
                      <strong>You own your screenplays.</strong> All screenplay content, characters, stories, and creative works you create using ScriptCraft AI remain your intellectual property.
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">AI-Generated Content</h3>
                  <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                    <li>AI-generated suggestions and content are provided as tools to assist your creativity</li>
                    <li>You are responsible for reviewing and editing all AI-generated content</li>
                    <li>AI suggestions do not guarantee originality or freedom from copyright issues</li>
                    <li>Final creative responsibility rests with you as the author</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">Service Content</h3>
                  <p className="text-script-slate-600">
                    The ScriptCraft AI software, interface, and all associated intellectual property remain owned by us and are protected by copyright and other laws.
                  </p>
                </div>
              </div>
            </section>

            {/* Prohibited Uses */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <AlertTriangle className="h-6 w-6 mr-3 text-red-600" />
                Prohibited Uses
              </h2>
              
              <p className="text-script-slate-600 mb-4">You may not use ScriptCraft AI to:</p>
              <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                <li>Create content that violates copyright, trademark, or other intellectual property rights</li>
                <li>Generate illegal, harmful, threatening, abusive, or discriminatory content</li>
                <li>Attempt to reverse engineer, hack, or compromise the service</li>
                <li>Share your account credentials with others</li>
                <li>Use the service for any commercial purpose without authorization</li>
                <li>Upload malicious code or attempt to disrupt the service</li>
                <li>Violate any applicable laws or regulations</li>
              </ul>
            </section>

            {/* Privacy & Data */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4 flex items-center">
                <Shield className="h-6 w-6 mr-3 text-script-blue-600" />
                Privacy & Data Handling
              </h2>
              
              <p className="text-script-slate-600 mb-4">
                Your privacy is governed by our <Link to="/privacy" className="text-script-blue-600 hover:text-script-blue-700 underline">Privacy Policy</Link>. Key points:
              </p>
              <ul className="list-disc list-inside text-script-slate-600 space-y-2">
                <li>Your API keys are stored locally and encrypted</li>
                <li>AI processing happens directly between your browser and AI providers</li>
                <li>Your screenplay content belongs to you</li>
                <li>We implement industry-standard security measures</li>
              </ul>
            </section>

            {/* Limitation of Liability */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Limitation of Liability</h2>
              
              <div className="bg-script-slate-100 rounded-lg p-6">
                <p className="text-script-slate-700 mb-4">
                  <strong>Service "As-Is":</strong> ScriptCraft AI is provided "as-is" without warranties of any kind. We do not guarantee that the service will be uninterrupted, error-free, or meet your specific requirements.
                </p>
                <p className="text-script-slate-700 mb-4">
                  <strong>AI Content:</strong> AI-generated content is provided for creative assistance only. We are not responsible for the accuracy, originality, or legal compliance of AI-generated suggestions.
                </p>
                <p className="text-script-slate-700">
                  <strong>Damages:</strong> Our liability is limited to the amount you paid for the service in the 12 months preceding any claim, if any.
                </p>
              </div>
            </section>

            {/* Termination */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Account Termination</h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">By You</h3>
                  <p className="text-script-slate-600">
                    You may terminate your account at any time through your account settings. Upon termination, you can export your screenplay projects.
                  </p>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-script-slate-800 mb-2">By Us</h3>
                  <p className="text-script-slate-600">
                    We may suspend or terminate accounts that violate these terms, engage in prohibited activities, or for any reason with reasonable notice.
                  </p>
                </div>
              </div>
            </section>

            {/* Changes to Terms */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Changes to Terms</h2>
              <p className="text-script-slate-600">
                We reserve the right to modify these terms at any time. We will notify users of significant changes via email or through the service. Continued use after changes constitutes acceptance of the new terms.
              </p>
            </section>

            {/* Contact Information */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-script-slate-900 mb-4">Contact Information</h2>
              <p className="text-script-slate-600 mb-4">
                Questions about these Terms of Service? Contact us:
              </p>
              <div className="bg-script-slate-100 rounded-lg p-4">
                <p className="text-script-slate-700">
                  <strong>Email:</strong> legal@scriptcraft.ai<br/>
                  <strong>Support:</strong> <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact Form</Link>
                </p>
              </div>
            </section>
          </div>

          {/* Footer Navigation */}
          <div className="border-t border-script-slate-200 pt-8 mt-12">
            <div className="flex flex-wrap justify-center space-x-6 text-sm">
              <Link to="/privacy" className="text-script-blue-600 hover:text-script-blue-700">Privacy Policy</Link>
              <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact</Link>
              <Link to="/setup-guide" className="text-script-blue-600 hover:text-script-blue-700">API Setup Guide</Link>
              <Link to="/user-guide" className="text-script-blue-600 hover:text-script-blue-700">User Guide</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Terms;
