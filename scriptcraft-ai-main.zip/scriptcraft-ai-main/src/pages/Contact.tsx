
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Mail, MessageSquare, Phone, MapPin, Send, Clock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const Contact: React.FC = () => {
  const { isRTL } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Message sent successfully! We\'ll get back to you within 24 hours.');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (error) {
      toast.error('Failed to send message. Please try again.');
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-6">
            <MessageSquare className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-script-slate-900 mb-4">Contact Us</h1>
          <p className="text-script-slate-600 text-lg max-w-2xl mx-auto">
            Have questions about ScriptCraft AI? Need help setting up your API keys? We're here to help you succeed with your screenplay writing.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-script-slate-900">Send us a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Your full name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      type="text"
                      placeholder="What can we help you with?"
                      value={formData.subject}
                      onChange={(e) => handleInputChange('subject', e.target.value)}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      placeholder="Please describe your question or issue in detail..."
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      className="w-full min-h-32"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-script-blue-500 to-script-blue-600 hover:from-script-blue-600 hover:to-script-blue-700"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Sending...</span>
                      </div>
                    ) : (
                      <>
                        <Send className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Contact Info Card */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-script-slate-900">Get in Touch</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Mail className="h-5 w-5 text-script-blue-600 mt-1" />
                  <div>
                    <p className="font-medium text-script-slate-900">Email Support</p>
                    <p className="text-script-slate-600 text-sm">support@scriptcraft.ai</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-script-blue-600 mt-1" />
                  <div>
                    <p className="font-medium text-script-slate-900">Response Time</p>
                    <p className="text-script-slate-600 text-sm">Within 24 hours</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* FAQ Quick Links */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-script-slate-900">Quick Help</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link 
                  to="/setup-guide" 
                  className="block p-3 bg-script-blue-50 rounded-lg hover:bg-script-blue-100 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <AlertCircle className="h-5 w-5 text-script-blue-600" />
                    <div>
                      <p className="font-medium text-script-blue-900">API Setup Guide</p>
                      <p className="text-script-blue-700 text-sm">Learn how to configure your API keys</p>
                    </div>
                  </div>
                </Link>

                <Link 
                  to="/user-guide" 
                  className="block p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <MessageSquare className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-medium text-green-900">User Guide</p>
                      <p className="text-green-700 text-sm">Complete walkthrough of all features</p>
                    </div>
                  </div>
                </Link>

                <Link 
                  to="/privacy" 
                  className="block p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-purple-600" />
                    <div>
                      <p className="font-medium text-purple-900">Privacy Policy</p>
                      <p className="text-purple-700 text-sm">How we protect your data</p>
                    </div>
                  </div>
                </Link>
              </CardContent>
            </Card>

            {/* Common Issues */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-script-slate-900">Common Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-script-slate-900 mb-2">API Key Issues?</h4>
                  <p className="text-script-slate-600 text-sm">
                    Most API key problems are solved by checking the setup guide and ensuring your keys have the right permissions.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-script-slate-900 mb-2">Script Not Saving?</h4>
                  <p className="text-script-slate-600 text-sm">
                    Check your internet connection and try refreshing the page. Your work is auto-saved frequently.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-script-slate-900 mb-2">Billing Questions?</h4>
                  <p className="text-script-slate-600 text-sm">
                    AI usage costs go directly to your AI provider (OpenAI, etc.). We don't charge for AI usage.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="border-t border-script-slate-200 pt-8 mt-12">
          <div className="flex flex-wrap justify-center space-x-6 text-sm">
            <Link to="/privacy" className="text-script-blue-600 hover:text-script-blue-700">Privacy Policy</Link>
            <Link to="/terms" className="text-script-blue-600 hover:text-script-blue-700">Terms of Service</Link>
            <Link to="/setup-guide" className="text-script-blue-600 hover:text-script-blue-700">API Setup Guide</Link>
            <Link to="/user-guide" className="text-script-blue-600 hover:text-script-blue-700">User Guide</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
