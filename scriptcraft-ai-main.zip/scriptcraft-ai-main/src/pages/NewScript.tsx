
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { scriptTemplates } from '../data/mockScripts';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Film, Tv, Clock, Wand2 } from 'lucide-react';
import Header from '../components/Header';
import { useScripts } from '../hooks/useScripts';
import { supabase } from '../integrations/supabase/client';

const NewScript: React.FC = () => {
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  const { createScript } = useScripts();

  const getTemplateIcon = (iconName: string) => {
    switch (iconName) {
      case 'Film':
        return Film;
      case 'Tv':
        return Tv;
      case 'Clock':
        return Clock;
      default:
        return Film;
    }
  };

  const handleCreateScript = async (templateId: string) => {
    // Check if template is coming soon
    if (templateId === 'tv-episode') {
      alert('TV Episode templates are coming soon! Please try Feature Film or Short Film for now.');
      return;
    }

    try {
      // Check if user is authenticated
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        alert('Please log in to create a script');
        navigate('/login');
        return;
      }

      // Create a script in the database first to get a proper UUID
      const scriptId = await createScript('Untitled Script', 'AI-assisted script', templateId);
      
      // Initialize project data in localStorage with the proper UUID
      const projectData = {
        id: scriptId,
        title: 'Untitled Script',
        type: templateId,
        currentPhase: 'brainstorm',
        createdAt: new Date(),
        lastModified: new Date()
      };
      
      localStorage.setItem(`project-${scriptId}`, JSON.stringify(projectData));
      
      // Navigate to brainstorm phase with the correct route pattern
      navigate(`/script/${scriptId}/brainstorm`);
    } catch (error) {
      console.error('Failed to create script:', error);
      alert('Failed to create script. Please try again.');
    }
  };

  const handleQuickStart = async () => {
    try {
      // Create a script in the database first
      const scriptId = await createScript('Untitled Script', 'Quick start script', 'feature-film');
      // Navigate to the script editor with the proper UUID
      navigate(`/script/${scriptId}`);
    } catch (error) {
      console.error('Failed to create script:', error);
      alert('Failed to create script. Please try again.');
    }
  };

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Back Button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate('/scripts')}
          className={`mb-4 sm:mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('backToMyScripts')}
        </Button>

        {/* Page Header */}
        <div className={`text-center mb-8 sm:mb-12 ${isRTL ? 'text-right' : 'text-left'} px-4`}>
          <h1 className="text-3xl sm:text-4xl font-bold text-script-slate-900 mb-4">
            {t('createNewScriptTitle')}
          </h1>
          <p className="text-lg sm:text-xl text-script-slate-600 max-w-2xl mx-auto">
            Choose your path: Get AI assistance through our guided workflow or jump straight to writing.
          </p>
        </div>

        {/* Creation Options */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* AI-Assisted Workflow */}
          <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-[1.02] border-2 hover:border-script-blue-300">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-script-blue-500 to-script-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Wand2 className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-script-slate-900">
                AI-Assisted Workflow
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-script-slate-600 mb-6">
                Get guided help with brainstorming, structure planning, character development, and writing.
              </p>
              <div className="space-y-4">
                <div className="text-sm text-script-slate-500 space-y-1">
                  <p>✓ Story idea development</p>
                  <p>✓ Three-act structure planning</p>
                  <p>✓ Character profiles & relationships</p>
                  <p>✓ AI writing assistance</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Start */}
          <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-[1.02] border-2 hover:border-script-slate-300">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-script-slate-500 to-script-slate-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Film className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-script-slate-900">
                Quick Start
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-script-slate-600 mb-6">
                Jump straight into writing with our professional screenplay editor.
              </p>
              <Button 
                className="w-full bg-script-slate-500 hover:bg-script-slate-600"
                onClick={handleQuickStart}
              >
                Start Writing Now
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Template Cards for AI Workflow */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-center text-script-slate-900">
            Choose Your Project Type
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {scriptTemplates.map((template) => {
              const IconComponent = getTemplateIcon(template.icon);
              const isComingSoon = template.id === 'tv-episode';
              
              return (
                <Card 
                  key={template.id}
                  className={`group hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-[1.02] border-2 hover:border-script-blue-300 ${isComingSoon ? 'opacity-75' : ''}`}
                  onClick={() => handleCreateScript(template.id)}
                >
                  <CardHeader className="text-center pb-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-12 h-12 mx-auto bg-gradient-to-br from-script-blue-500 to-script-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      {isComingSoon && (
                        <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200">
                          Coming Soon
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg font-bold text-script-slate-900">
                      {template.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-script-slate-600 mb-4 text-sm">
                      {template.description}
                    </p>
                    <Button 
                      className={`w-full text-sm ${isComingSoon ? 'bg-script-slate-400 cursor-not-allowed' : 'bg-script-blue-500 hover:bg-script-blue-600'}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCreateScript(template.id);
                      }}
                      disabled={isComingSoon}
                    >
                      {isComingSoon ? 'Coming Soon' : 'Start with AI Guidance'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Additional Info */}
        <div className="bg-white rounded-lg p-6 sm:p-8 shadow-sm border border-script-slate-200 mt-12">
          <h3 className="text-lg font-semibold text-script-slate-900 mb-4">
            What's Included in the AI-Assisted Workflow?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-sm text-script-slate-600">
            <div>
              <h4 className="font-semibold text-script-slate-800 mb-2">Phase 1: Brainstorm</h4>
              <ul className="space-y-1">
                <li>• Story idea development</li>
                <li>• Genre & tone selection</li>
                <li>• Logline creation</li>
                <li>• Setting & audience</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-script-slate-800 mb-2">Phase 2: Structure</h4>
              <ul className="space-y-1">
                <li>• Three-act breakdown</li>
                <li>• Plot point planning</li>
                <li>• Conflict development</li>
                <li>• Pacing guidance</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-script-slate-800 mb-2">Phase 3: Characters</h4>
              <ul className="space-y-1">
                <li>• Character profiles</li>
                <li>• Backstory development</li>
                <li>• Relationship mapping</li>
                <li>• Voice & dialogue</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-script-slate-800 mb-2">Phase 4: Writing</h4>
              <ul className="space-y-1">
                <li>• Context-aware AI help</li>
                <li>• Character consistency</li>
                <li>• Format checking</li>
                <li>• Real-time suggestions</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewScript;
