
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, ArrowRight, Lightbulb, Wand2, Film, Save, Loader2, AlertCircle } from 'lucide-react';
import Header from '../components/Header';
import AIAssistant from '../components/AIAssistant';
import { ProjectBrainstorm } from '../types/project';
import { useWorkflowData } from '../hooks/useWorkflowData';

const ProjectBrainstormPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  
  // Use workflow data hook for proper Supabase integration
  const { brainstorm, setBrainstorm, loading } = useWorkflowData(id);
  
  // Manual step control only - no automatic step detection
  const [currentStep, setCurrentStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [suggestions, setSuggestions] = useState<{[key: string]: string[]}>({});
  const [showStepSuggestion, setShowStepSuggestion] = useState(false);
  const [suggestedStep, setSuggestedStep] = useState(1);

  // Initialize local brainstorm state from loaded data
  const [localBrainstorm, setLocalBrainstorm] = useState<ProjectBrainstorm>({
    idea: '',
    genre: '',
    theme: '',
    setting: '',
    timeframe: '',
    tone: '',
    logline: '',
    premise: '',
    targetAudience: '',
    inspirations: [],
    keywords: []
  });

  // Sync local state with loaded brainstorm data
  useEffect(() => {
    if (brainstorm) {
      console.log('ProjectBrainstorm: Loading brainstorm data from Supabase:', brainstorm);
      setLocalBrainstorm(brainstorm);
      
      // Suggest step continuation based on data completion (optional, user-controlled)
      let recommendedStep = 1;
      if (brainstorm.setting && brainstorm.targetAudience) {
        recommendedStep = 3;
      } else if (brainstorm.logline && brainstorm.premise) {
        recommendedStep = 2;
      }
      
      // Only show suggestion if user is on step 1 but has more complete data
      if (currentStep === 1 && recommendedStep > 1) {
        setSuggestedStep(recommendedStep);
        setShowStepSuggestion(true);
      }
    }
  }, [brainstorm, currentStep]);

  // Auto-save when local brainstorm changes (decoupled from navigation)
  useEffect(() => {
    if (id && (localBrainstorm.idea || localBrainstorm.genre || localBrainstorm.theme || localBrainstorm.setting || localBrainstorm.logline || localBrainstorm.premise)) {
      console.log('ProjectBrainstorm: Auto-saving brainstorm data to Supabase:', localBrainstorm);
      setBrainstorm(localBrainstorm);
      setLastSaved(new Date());
    }
  }, [localBrainstorm, id, setBrainstorm]);

  const genres = [
    { value: 'action', label: t('genreAction') },
    { value: 'adventure', label: t('genreAdventure') },
    { value: 'comedy', label: t('genreComedy') },
    { value: 'drama', label: t('genreDrama') },
    { value: 'fantasy', label: t('genreFantasy') },
    { value: 'horror', label: t('genreHorror') },
    { value: 'mystery', label: t('genreMystery') },
    { value: 'romance', label: t('genreRomance') },
    { value: 'sci-fi', label: t('genreSciFi') },
    { value: 'thriller', label: t('genreThriller') },
    { value: 'western', label: t('genreWestern') },
    { value: 'crime', label: t('genreCrime') }
  ];

  const tones = [
    { value: 'dark', label: t('toneDark') },
    { value: 'light', label: t('toneLight') },
    { value: 'dramatic', label: t('toneDramatic') },
    { value: 'comedic', label: t('toneComedic') },
    { value: 'satirical', label: t('toneSatirical') },
    { value: 'uplifting', label: t('toneUplifting') },
    { value: 'suspenseful', label: t('toneSuspenseful') },
    { value: 'romantic', label: t('toneRomantic') },
    { value: 'gritty', label: t('toneGritty') },
    { value: 'whimsical', label: t('toneWhimsical') }
  ];

  const callOpenAI = async (prompt: string) => {
    const apiKey = localStorage.getItem('openai-api-key');
    if (!apiKey) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: prompt.includes('JSON') ? 
              'You are a creative screenplay consultant. Generate original story concepts with appropriate genre, tone, and theme suggestions. Return valid JSON only.' :
              'You are a creative screenplay consultant. Provide brief, concise suggestions that are 1-2 words or short phrases only.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.9,
        max_tokens: prompt.includes('JSON') ? 300 : 50,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  };

  const handleGenerateIdea = async () => {
    const apiKey = localStorage.getItem('openai-api-key');
    if (!apiKey || !apiKey.trim()) {
      alert('Please enter your OpenAI API key in the AI Assistant panel first');
      return;
    }

    setIsGenerating(true);
    
    try {
      const prompt = `Generate a complete screenplay concept including story idea, genre, tone, and theme. Return as JSON with these exact keys:
{
  "idea": "1-2 sentence story description with specific characters and conflict",
  "genre": "one of: action, adventure, comedy, drama, fantasy, horror, mystery, romance, sci-fi, thriller, western, crime",
  "tone": "one of: dark, light, dramatic, comedic, satirical, uplifting, suspenseful, romantic, gritty, whimsical",
  "theme": "main thematic element in 2-4 words"
}

Make sure all elements work together cohesively.`;

      const response = await callOpenAI(prompt);
      
      try {
        const concept = JSON.parse(response);
        
        setLocalBrainstorm(prev => ({
          ...prev,
          idea: concept.idea || '',
          genre: concept.genre || '',
          tone: concept.tone || '',
          theme: concept.theme || '',
          logline: '',
          premise: ''
        }));
        
        // Stay on current step - no automatic navigation
        console.log('ProjectBrainstorm: Generated idea, staying on current step:', currentStep);
        
      } catch (parseError) {
        console.warn('Failed to parse JSON response, falling back to simple idea generation');
        const simplePrompt = 'Generate a unique and compelling screenplay idea in 1-2 sentences.';
        const simpleIdea = await callOpenAI(simplePrompt);
        
        setLocalBrainstorm(prev => ({
          ...prev,
          idea: simpleIdea,
          logline: '',
          premise: ''
        }));
      }
      
    } catch (error) {
      console.error('AI idea generation failed:', error);
      alert(`Failed to generate idea. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAIAssist = async (field: string) => {
    if (!localBrainstorm.idea) {
      alert('Please fill in the story idea first');
      return;
    }

    setIsGenerating(true);
    
    try {
      let prompt = '';
      const contextInfo = `Story Idea: ${localBrainstorm.idea}${localBrainstorm.genre ? `\nGenre: ${localBrainstorm.genre}` : ''}${localBrainstorm.tone ? `\nTone: ${localBrainstorm.tone}` : ''}${localBrainstorm.theme ? `\nTheme: ${localBrainstorm.theme}` : ''}`;
      
      if (field === 'logline') {
        prompt = `Based on this story concept, create a compelling one-sentence logline that captures the main conflict and stakes. Use the format "When [inciting incident], [protagonist] must [goal] or [stakes]":

${contextInfo}

Make the logline specific, engaging, and directly related to the story idea provided.`;
      } else if (field === 'premise') {
        prompt = `Based on this story concept, write a detailed 2-3 paragraph premise that expands on the story idea and includes character setup, conflict, and stakes:

${contextInfo}

Make sure the premise directly builds upon and expands the core story idea provided.`;
      } else if (field === 'setting') {
        prompt = `Based on this story concept, suggest 3 brief location options (1-2 words each, like "London", "Space Station", "Medieval Castle"). Separate with commas:

${contextInfo}

Provide only location names or types, no descriptions.`;
      } else if (field === 'timeframe') {
        prompt = `Based on this story concept, suggest 3 brief time periods (like "Present Day", "1920s", "Future", "Medieval"). Separate with commas:

${contextInfo}

Provide only time periods, no descriptions.`;
      } else if (field === 'targetAudience') {
        prompt = `Based on this story concept, suggest 3 brief audience types (like "Young Adults", "Families", "Teens", "Adults"). Separate with commas:

${contextInfo}

Provide only demographic groups, no descriptions.`;
      }

      const suggestion = await callOpenAI(prompt);
      
      if (['setting', 'timeframe', 'targetAudience'].includes(field)) {
        // Parse suggestions and store them - stay on current step
        const suggestionList = suggestion.split(',').map(s => s.trim()).filter(s => s.length > 0);
        setSuggestions(prev => ({ ...prev, [field]: suggestionList }));
        console.log(`ProjectBrainstorm: Generated ${field} suggestions, staying on current step:`, currentStep);
      } else {
        // For logline and premise, set directly - stay on current step
        if (field === 'logline') {
          setLocalBrainstorm(prev => ({ ...prev, logline: suggestion.trim() }));
          console.log('ProjectBrainstorm: Generated logline, staying on current step:', currentStep);
        } else if (field === 'premise') {
          setLocalBrainstorm(prev => ({ ...prev, premise: suggestion.trim() }));
          console.log('ProjectBrainstorm: Generated premise, staying on current step:', currentStep);
        }
      }
      
    } catch (error) {
      console.error('AI assist failed:', error);
      alert(`Failed to generate ${field}. Please check your API key and try again.`);
    } finally {
      setIsGenerating(false);
    }
  };

  const applySuggestion = (field: string, value: string) => {
    setLocalBrainstorm(prev => ({ ...prev, [field]: value }));
    // Don't clear suggestions immediately - let user see multiple options
    console.log(`ProjectBrainstorm: Applied ${field} suggestion, staying on current step:`, currentStep);
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
      setShowStepSuggestion(false); // Clear any step suggestions when manually navigating
    } else {
      // Final save before navigation
      console.log('ProjectBrainstorm: Final save before navigation to structure');
      setBrainstorm(localBrainstorm);
      navigate(`/script/${id}/structure-planning`);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      setShowStepSuggestion(false); // Clear any step suggestions when manually navigating
    } else {
      // Save before navigating back
      console.log('ProjectBrainstorm: Saving before navigation back to scripts');
      setBrainstorm(localBrainstorm);
      navigate('/scripts');
    }
  };

  const handleContinueToStep = (step: number) => {
    setCurrentStep(step);
    setShowStepSuggestion(false);
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return localBrainstorm.idea && localBrainstorm.genre;
      case 2:
        return localBrainstorm.logline && localBrainstorm.premise;
      case 3:
        return localBrainstorm.setting && localBrainstorm.targetAudience;
      default:
        return false;
    }
  };

  // Show loading state while fetching data from Supabase
  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-center min-h-96">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p className="text-script-slate-600">Loading brainstorm data...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            {/* Optional step continuation suggestion */}
            {showStepSuggestion && (
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm text-blue-800 mb-3">
                        It looks like you have more content completed. Would you like to continue where you left off?
                      </p>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          onClick={() => handleContinueToStep(suggestedStep)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Continue to Step {suggestedStep}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => setShowStepSuggestion(false)}
                        >
                          Stay Here
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className={`flex items-center ${isRTL ? 'space-x-reverse' : ''}`}>
                  <Lightbulb className={`h-5 w-5 text-script-blue-500 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('coreIdeaGenre')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t('storyIdea')}</label>
                  <div className="flex gap-2">
                    <Textarea
                      value={localBrainstorm.idea}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, idea: e.target.value }))}
                      placeholder={t('storyIdeaPlaceholder')}
                      className="min-h-24"
                    />
                    <Button 
                      onClick={handleGenerateIdea} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                      title="Generate new story idea with AI"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">{t('genre')}</label>
                  <Select value={localBrainstorm.genre} onValueChange={(value) => setLocalBrainstorm(prev => ({ ...prev, genre: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('selectGenre')} />
                    </SelectTrigger>
                    <SelectContent>
                      {genres.map(genre => (
                        <SelectItem key={genre.value} value={genre.value}>{genre.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">{t('tone')}</label>
                  <Select value={localBrainstorm.tone} onValueChange={(value) => setLocalBrainstorm(prev => ({ ...prev, tone: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('selectTone')} />
                    </SelectTrigger>
                    <SelectContent>
                      {tones.map(tone => (
                        <SelectItem key={tone.value} value={tone.value}>{tone.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">{t('theme')}</label>
                  <Input
                    value={localBrainstorm.theme}
                    onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, theme: e.target.value }))}
                    placeholder={t('themePlaceholder')}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('loglinePremise')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t('logline')}</label>
                  <div className="flex gap-2">
                    <Textarea
                      value={localBrainstorm.logline}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, logline: e.target.value }))}
                      placeholder={t('loglinePlaceholder')}
                      className="min-h-20"
                    />
                    <Button 
                      onClick={() => handleAIAssist('logline')} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-script-slate-500 mt-1">
                    {t('loglineFormat')}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">{t('premise')}</label>
                  <div className="flex gap-2">
                    <Textarea
                      value={localBrainstorm.premise}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, premise: e.target.value }))}
                      placeholder={t('premisePlaceholder')}
                      className="min-h-32"
                    />
                    <Button 
                      onClick={() => handleAIAssist('premise')} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('settingAudience')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Location</label>
                  <div className="flex gap-2">
                    <Input
                      value={localBrainstorm.setting}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, setting: e.target.value }))}
                      placeholder="e.g., London, Space Station, Medieval Castle"
                    />
                    <Button 
                      onClick={() => handleAIAssist('setting')} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                      title="Get location suggestions"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {suggestions.setting && suggestions.setting.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {suggestions.setting.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => applySuggestion('setting', suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Time Period</label>
                  <div className="flex gap-2">
                    <Input
                      value={localBrainstorm.timeframe}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, timeframe: e.target.value }))}
                      placeholder="e.g., Present Day, 1920s, Future"
                    />
                    <Button 
                      onClick={() => handleAIAssist('timeframe')} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                      title="Get time period suggestions"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {suggestions.timeframe && suggestions.timeframe.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {suggestions.timeframe.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => applySuggestion('timeframe', suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">{t('targetAudience')}</label>
                  <div className="flex gap-2">
                    <Input
                      value={localBrainstorm.targetAudience}
                      onChange={(e) => setLocalBrainstorm(prev => ({ ...prev, targetAudience: e.target.value }))}
                      placeholder="e.g., Young Adults, Families, Teens"
                    />
                    <Button 
                      onClick={() => handleAIAssist('targetAudience')} 
                      disabled={isGenerating}
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                      title="Get audience suggestions"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {suggestions.targetAudience && suggestions.targetAudience.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {suggestions.targetAudience.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => applySuggestion('targetAudience', suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Navigation */}
        <Button 
          variant="ghost" 
          onClick={handleBack}
          className={`mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {currentStep === 1 ? t('backToScripts') : t('previous')}
        </Button>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">{t('projectBrainstorm')}</h1>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{t('phaseOneOfFour')}</Badge>
              {lastSaved && (
                <div className="flex items-center text-xs text-script-slate-500">
                  <Save className="h-3 w-3 mr-1" />
                  Auto-saved {lastSaved.toLocaleTimeString()}
                </div>
              )}
            </div>
          </div>
          
          {/* Progress indicators */}
          <div className="flex items-center space-x-2">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step <= currentStep ? 'bg-script-blue-500 text-white' : 'bg-script-slate-200 text-script-slate-500'
                }`}>
                  {step}
                </div>
                {step < 3 && <div className={`w-12 h-1 ${step < currentStep ? 'bg-script-blue-500' : 'bg-script-slate-200'}`} />}
              </div>
            ))}
          </div>
          
          <div className="flex justify-between mt-2 text-sm text-script-slate-600">
            <span>{t('coreIdea')}</span>
            <span>{t('logline')}</span>
            <span>{t('setting')}</span>
          </div>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            {renderStep()}
          </div>
          
          <div className="lg:col-span-1">
            <AIAssistant context="brainstorm" projectData={localBrainstorm} />
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className={`flex items-center justify-between mt-8 ${isRTL ? 'space-x-reverse' : ''}`}>
          <Button 
            variant="outline" 
            onClick={handleBack}
            disabled={false}
          >
            {currentStep === 1 ? t('backToScripts') : t('previous')}
          </Button>
          
          <Button 
            onClick={handleNext}
            disabled={!canProceed()}
            className="bg-script-blue-500 hover:bg-script-blue-600"
          >
            {currentStep === 3 ? t('continueToStructure') : t('next')}
            <ArrowRight className={`h-4 w-4 ${isRTL ? 'mr-2' : 'ml-2'}`} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProjectBrainstormPage;
