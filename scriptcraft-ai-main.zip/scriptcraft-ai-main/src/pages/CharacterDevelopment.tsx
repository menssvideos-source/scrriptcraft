
import React from 'react';
import CharacterDevelopmentPage from '../components/CharacterDevelopment/CharacterDevelopmentPage';

const CharacterDevelopment: React.FC = () => {
  return <CharacterDevelopmentPage />;
};

export default CharacterDevelopment;
