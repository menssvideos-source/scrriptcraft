
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  BookOpen, 
  Play, 
  Users, 
  Brain, 
  Image, 
  Download,
  ChevronRight,
  Lightbulb,
  Target,
  FileText,
  Zap,
  Palette,
  Share2,
  CheckCircle,
  Star
} from 'lucide-react';

const UserGuide: React.FC = () => {
  const { isRTL } = useLanguage();
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const toggleSection = (sectionId: string) => {
    setExpandedSection(expandedSection === sectionId ? null : sectionId);
  };

  const FeatureCard = ({ 
    icon: Icon, 
    title, 
    description, 
    features,
    color = 'blue'
  }: {
    icon: React.ComponentType<any>;
    title: string;
    description: string;
    features: string[];
    color?: string;
  }) => {
    const colorClasses = {
      blue: 'from-blue-50 to-blue-100 border-blue-200 text-blue-900',
      green: 'from-green-50 to-green-100 border-green-200 text-green-900',
      purple: 'from-purple-50 to-purple-100 border-purple-200 text-purple-900',
      orange: 'from-orange-50 to-orange-100 border-orange-200 text-orange-900'
    };

    return (
      <Card className={`bg-gradient-to-br ${colorClasses[color as keyof typeof colorClasses]}`}>
        <CardHeader>
          <div className="flex items-center space-x-3">
            <Icon className="h-6 w-6" />
            <CardTitle className="text-lg">{title}</CardTitle>
          </div>
          <p className="text-sm opacity-90">{description}</p>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {features.map((feature, index) => (
              <li key={index} className="flex items-center space-x-2 text-sm">
                <CheckCircle className="h-4 w-4" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    );
  };

  const WorkflowStep = ({ 
    number, 
    title, 
    description, 
    tips 
  }: {
    number: number;
    title: string;
    description: string;
    tips: string[];
  }) => (
    <Card className="transition-all hover:shadow-lg">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-lg">{number}</span>
          </div>
          <div>
            <CardTitle className="text-xl">{title}</CardTitle>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-script-slate-600">{description}</p>
        
        <div className="bg-script-blue-50 rounded-lg p-4">
          <h4 className="font-semibold text-script-blue-900 mb-2 flex items-center">
            <Lightbulb className="h-4 w-4 mr-2" />
            Pro Tips
          </h4>
          <ul className="space-y-1">
            {tips.map((tip, index) => (
              <li key={index} className="text-sm text-script-blue-800 flex items-start">
                <span className="text-script-blue-600 mr-2">•</span>
                {tip}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-script-blue-500 to-script-blue-700 rounded-2xl flex items-center justify-center mb-6">
            <BookOpen className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-script-slate-900 mb-4">User Guide</h1>
          <p className="text-script-slate-600 text-lg max-w-3xl mx-auto">
            Master ScriptCraft AI's powerful features and create professional screenplays with intelligent AI assistance. From beginner basics to advanced techniques.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          <Card className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100">
            <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <h3 className="font-semibold text-green-900">4-Phase System</h3>
            <p className="text-sm text-green-700">Structured workflow</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100">
            <Brain className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <h3 className="font-semibold text-blue-900">AI-Powered</h3>
            <p className="text-sm text-blue-700">Intelligent assistance</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100">
            <FileText className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <h3 className="font-semibold text-purple-900">Industry Standard</h3>
            <p className="text-sm text-purple-700">Professional formatting</p>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100">
            <Zap className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <h3 className="font-semibold text-orange-900">Real-time</h3>
            <p className="text-sm text-orange-700">Instant collaboration</p>
          </Card>
        </div>

        <Tabs defaultValue="getting-started" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
            <TabsTrigger value="workflow">4-Phase Workflow</TabsTrigger>
            <TabsTrigger value="features">Key Features</TabsTrigger>
            <TabsTrigger value="ai-assistance">AI Features</TabsTrigger>
            <TabsTrigger value="tips">Pro Tips</TabsTrigger>
          </TabsList>

          {/* Getting Started Tab */}
          <TabsContent value="getting-started" className="space-y-6">
            <Card className="bg-gradient-to-r from-script-blue-50 to-script-blue-100 border-script-blue-200">
              <CardHeader>
                <CardTitle className="text-2xl text-script-blue-900">Welcome to ScriptCraft AI!</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-script-blue-800">
                  ScriptCraft AI is designed to guide you through the entire screenplay writing process using a proven 4-phase methodology combined with powerful AI assistance.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-script-blue-900">🎯 What Makes Us Different</h4>
                    <ul className="text-sm text-script-blue-800 space-y-1">
                      <li>• Structured 4-phase writing workflow</li>
                      <li>• BYOK (Bring Your Own Key) privacy-first approach</li>
                      <li>• Industry-standard screenplay formatting</li>
                      <li>• AI-powered creative assistance</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-script-blue-900">🚀 Getting Started Checklist</h4>
                    <ul className="text-sm text-script-blue-800 space-y-1">
                      <li>• Create your account</li>
                      <li>• Set up API keys (optional)</li>
                      <li>• Create your first project</li>
                      <li>• Start with brainstorming</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="text-center p-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Play className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-script-slate-900 mb-2">1. Start a Project</h3>
                <p className="text-script-slate-600 text-sm mb-4">
                  Create a new screenplay project and begin with the brainstorming phase.
                </p>
                <Button asChild size="sm">
                  <Link to="/new-script">Create Project</Link>
                </Button>
              </Card>

              <Card className="text-center p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Brain className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-script-slate-900 mb-2">2. Setup AI (Optional)</h3>
                <p className="text-script-slate-600 text-sm mb-4">
                  Add your API keys to unlock AI-powered writing assistance.
                </p>
                <Button asChild size="sm" variant="outline">
                  <Link to="/setup-guide">Setup Guide</Link>
                </Button>
              </Card>

              <Card className="text-center p-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-script-slate-900 mb-2">3. Start Writing</h3>
                <p className="text-script-slate-600 text-sm mb-4">
                  Follow our 4-phase workflow to create professional screenplays.
                </p>
                <Button asChild size="sm" variant="outline">
                  <Link to="/dashboard">Go to Dashboard</Link>
                </Button>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>First Project Walkthrough</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-start space-x-4 p-4 bg-script-slate-50 rounded-lg">
                    <div className="w-8 h-8 bg-script-blue-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">1</div>
                    <div>
                      <h4 className="font-semibold">Create Your First Script</h4>
                      <p className="text-script-slate-600 text-sm">Click "New Script" and enter a title for your screenplay. Choose a genre that matches your vision.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4 p-4 bg-script-slate-50 rounded-lg">
                    <div className="w-8 h-8 bg-script-blue-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">2</div>
                    <div>
                      <h4 className="font-semibold">Start with Brainstorming</h4>
                      <p className="text-script-slate-600 text-sm">Begin in Phase 1 to develop your core concept, themes, and basic story structure.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4 p-4 bg-script-slate-50 rounded-lg">
                    <div className="w-8 h-8 bg-script-blue-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">3</div>
                    <div>
                      <h4 className="font-semibold">Use AI Assistance</h4>
                      <p className="text-script-slate-600 text-sm">If you've set up API keys, try the AI suggestions for story ideas and character development.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 4-Phase Workflow Tab */}
          <TabsContent value="workflow" className="space-y-8">
            <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
              <CardHeader>
                <CardTitle className="text-2xl text-green-900">The ScriptCraft AI 4-Phase System</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-green-800 mb-4">
                  Our proven methodology guides you through every step of screenplay creation, from initial concept to final draft.
                </p>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-green-600">Structured</Badge>
                  <Badge variant="outline">Professional</Badge>
                  <Badge variant="outline">AI-Enhanced</Badge>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-8">
              <WorkflowStep
                number={1}
                title="Project Brainstorm"
                description="Develop your core concept, explore themes, and establish the foundation of your story. This phase is about discovering what your screenplay is really about."
                tips={[
                  "Start with a compelling 'What if?' question",
                  "Define your protagonist's main goal and obstacles",
                  "Explore themes that resonate with you personally",
                  "Use AI to generate fresh story angles and concepts"
                ]}
              />

              <WorkflowStep
                number={2}
                title="Structure Planning"
                description="Map out your three-act structure, plot points, and story beats. Create a solid blueprint before you start writing scenes."
                tips={[
                  "Follow the proven three-act structure",
                  "Identify key plot points and turning moments",
                  "Balance character arcs with plot progression",
                  "Plan your opening and closing scenes carefully"
                ]}
              />

              <WorkflowStep
                number={3}
                title="Character Development"
                description="Bring your characters to life with detailed backgrounds, motivations, and unique voices. Great characters drive great stories."
                tips={[
                  "Give each character a clear want and need",
                  "Develop distinct voices and speech patterns",
                  "Create compelling character relationships",
                  "Use AI to explore character backstories and motivations"
                ]}
              />

              <WorkflowStep
                number={4}
                title="Script Writing"
                description="Write your screenplay with professional formatting, bringing together all your planning into compelling scenes and dialogue."
                tips={[
                  "Focus on visual storytelling and action",
                  "Keep dialogue sharp and character-specific",
                  "Use proper screenplay formatting throughout",
                  "Leverage AI for dialogue polish and scene enhancement"
                ]}
              />
            </div>

            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <Star className="h-6 w-6 text-purple-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-purple-900 mb-2">Why This System Works</h3>
                    <p className="text-purple-800 text-sm">
                      This structured approach is based on proven screenwriting methodologies used by professional writers. 
                      By completing each phase thoroughly, you'll have a stronger foundation for your screenplay and avoid 
                      common pitfalls that derail many writing projects.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Key Features Tab */}
          <TabsContent value="features" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <FeatureCard
                icon={FileText}
                title="Professional Formatting"
                description="Industry-standard screenplay formatting that meets Hollywood requirements."
                features={[
                  "Automatic scene heading formatting",
                  "Character name and dialogue styling",
                  "Action line and parenthetical formatting",
                  "Page numbering and margins"
                ]}
                color="blue"
              />

              <FeatureCard
                icon={Share2}
                title="Real-time Collaboration"
                description="Work with co-writers and get feedback from collaborators in real-time."
                features={[
                  "Live editing with multiple users",
                  "Comment and suggestion system",
                  "Version history and change tracking",
                  "Share links for easy access"
                ]}
                color="green"
              />

              <FeatureCard
                icon={Image}
                title="Visual Storyboarding"
                description="Generate storyboard images to visualize your scenes and characters."
                features={[
                  "AI-generated scene imagery",
                  "Character visualization",
                  "Mood and tone representation",
                  "Export storyboards for production"
                ]}
                color="purple"
              />

              <FeatureCard
                icon={Download}
                title="Export & Sharing"
                description="Export your screenplay in multiple formats for different purposes."
                features={[
                  "PDF export for submissions",
                  "Final Draft compatible files",
                  "Fountain format support",
                  "Print-ready formatting"
                ]}
                color="orange"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Advanced Features</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-4">
                    <Palette className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-semibold">Custom Themes</h4>
                    <p className="text-sm text-script-slate-600">Personalize your writing environment</p>
                  </div>
                  <div className="text-center p-4">
                    <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <h4 className="font-semibold">Goal Tracking</h4>
                    <p className="text-sm text-script-slate-600">Set and monitor writing goals</p>
                  </div>
                  <div className="text-center p-4">
                    <Zap className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                    <h4 className="font-semibold">Quick Actions</h4>
                    <p className="text-sm text-script-slate-600">Keyboard shortcuts for efficiency</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Features Tab */}
          <TabsContent value="ai-assistance" className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardHeader>
                <CardTitle className="text-2xl text-purple-900">AI-Powered Creative Assistance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-purple-800 mb-4">
                  ScriptCraft AI integrates seamlessly with leading AI providers to enhance your creative process while maintaining complete privacy through our BYOK architecture.
                </p>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-purple-600">Privacy-First</Badge>
                  <Badge variant="outline">Your Keys</Badge>
                  <Badge variant="outline">Direct Connection</Badge>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-blue-600" />
                    Story Development
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">Concept Generation</h4>
                    <p className="text-sm text-blue-700">Generate story ideas, plot twists, and "what if" scenarios</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">Theme Exploration</h4>
                    <p className="text-sm text-blue-700">Explore deeper meanings and thematic elements</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">Genre Analysis</h4>
                    <p className="text-sm text-blue-700">Understand genre conventions and expectations</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-green-600" />
                    Character Creation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900">Character Backgrounds</h4>
                    <p className="text-sm text-green-700">Develop rich backstories and motivations</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900">Dialogue Polish</h4>
                    <p className="text-sm text-green-700">Refine character voices and speech patterns</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900">Relationship Dynamics</h4>
                    <p className="text-sm text-green-700">Explore character relationships and conflicts</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-purple-600" />
                    Script Enhancement
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-900">Scene Analysis</h4>
                    <p className="text-sm text-purple-700">Get feedback on pacing and structure</p>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-900">Format Suggestions</h4>
                    <p className="text-sm text-purple-700">Improve screenplay formatting and style</p>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-900">Revision Ideas</h4>
                    <p className="text-sm text-purple-700">Generate alternative approaches to scenes</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Image className="h-5 w-5 mr-2 text-orange-600" />
                    Visual Storytelling
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <h4 className="font-semibold text-orange-900">Storyboard Generation</h4>
                    <p className="text-sm text-orange-700">Create visual representations of key scenes</p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <h4 className="font-semibold text-orange-900">Character Visualization</h4>
                    <p className="text-sm text-orange-700">Generate character appearance references</p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <h4 className="font-semibold text-orange-900">Mood Boards</h4>
                    <p className="text-sm text-orange-700">Create visual tone and atmosphere guides</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <Lightbulb className="h-6 w-6 text-yellow-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-yellow-900 mb-2">AI Best Practices</h3>
                    <ul className="space-y-1 text-sm text-yellow-800">
                      <li>• Use AI suggestions as starting points, not final solutions</li>
                      <li>• Always review and edit AI-generated content</li>
                      <li>• Combine AI assistance with your creative vision</li>
                      <li>• Start with simple prompts and iterate</li>
                      <li>• Remember: AI enhances creativity, it doesn't replace it</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pro Tips Tab */}
          <TabsContent value="tips" className="space-y-6">
            <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
              <CardHeader>
                <CardTitle className="text-2xl text-green-900">Professional Writing Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-green-800">
                  Learn from the pros and avoid common pitfalls. These tips will help you create compelling, professional screenplays.
                </p>
              </CardContent>
            </Card>

            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2 text-blue-600" />
                    Story Structure Mastery
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-semibold">Start with the End</h4>
                    <p className="text-sm text-script-slate-600">Know your ending before you write your beginning. This gives your story direction and purpose.</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-semibold">The 15-Beat Structure</h4>
                    <p className="text-sm text-script-slate-600">Use Blake Snyder's beat sheet to ensure your story hits all the essential moments audiences expect.</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-semibold">Page Count Rules</h4>
                    <p className="text-sm text-script-slate-600">Aim for 90-120 pages for features, 22-30 for TV half-hours, 42-60 for TV hours.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-green-600" />
                    Character Development Secrets
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-semibold">Want vs. Need</h4>
                    <p className="text-sm text-script-slate-600">Your protagonist's want drives the plot, but their need drives the character arc.</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-semibold">Unique Voice</h4>
                    <p className="text-sm text-script-slate-600">Each character should have a distinct way of speaking that reflects their background and personality.</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-semibold">Active Protagonists</h4>
                    <p className="text-sm text-script-slate-600">Your main character should drive the story forward through their choices and actions.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-purple-600" />
                    Writing Craft Excellence
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-semibold">Show, Don't Tell</h4>
                    <p className="text-sm text-script-slate-600">Use action and visual elements to convey information rather than exposition-heavy dialogue.</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-semibold">Economy of Words</h4>
                    <p className="text-sm text-script-slate-600">Every word counts in a screenplay. Cut unnecessary descriptions and get to the point quickly.</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-semibold">Read Aloud</h4>
                    <p className="text-sm text-script-slate-600">Read your dialogue out loud to ensure it sounds natural and character-appropriate.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-orange-600" />
                    Productivity Hacks
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-semibold">Write First, Edit Later</h4>
                    <p className="text-sm text-script-slate-600">Get the full story down before worrying about perfection. You can always revise.</p>
                  </div>
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-semibold">Set Daily Goals</h4>
                    <p className="text-sm text-script-slate-600">Aim for 2-5 pages per day. Consistency beats intensity for long-term success.</p>
                  </div>
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-semibold">Use ScriptCraft AI's Structure</h4>
                    <p className="text-sm text-script-slate-600">Follow our 4-phase system to stay organized and avoid getting stuck.</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-script-blue-50 border-script-blue-200">
              <CardContent className="p-6">
                <div className="text-center">
                  <h3 className="font-bold text-script-blue-900 text-lg mb-2">Ready to Start Writing?</h3>
                  <p className="text-script-blue-800 mb-4">
                    Apply these tips in your next screenplay project with ScriptCraft AI's structured workflow.
                  </p>
                  <Button asChild className="bg-script-blue-600 hover:bg-script-blue-700">
                    <Link to="/new-script">
                      Create New Script <ChevronRight className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer Navigation */}
        <div className="border-t border-script-slate-200 pt-8 mt-12">
          <div className="flex flex-wrap justify-center space-x-6 text-sm">
            <Link to="/setup-guide" className="text-script-blue-600 hover:text-script-blue-700">API Setup Guide</Link>
            <Link to="/contact" className="text-script-blue-600 hover:text-script-blue-700">Contact Support</Link>
            <Link to="/privacy" className="text-script-blue-600 hover:text-script-blue-700">Privacy Policy</Link>
            <Link to="/terms" className="text-script-blue-600 hover:text-script-blue-700">Terms of Service</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserGuide;
