import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ArrowLeft, Target, Zap, BookOpen, Loader2, Save, CheckCircle, AlertCircle } from 'lucide-react';
import Header from '../components/Header';
import AIAssistant from '../components/AIAssistant';
import ThreeActVisualization from '../components/ThreeActVisualization';
import ActCard from '../components/ActCard';
import StructureNavigation from '../components/StructureNavigation';
import { useWorkflowData } from '../hooks/useWorkflowData';
import { ProjectStructure } from '../types/project';

const StructurePlanningPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  
  // Use workflow data hook to get all project data including brainstorm
  const { brainstorm, structure, setStructure, characters, loading, saving, lastSaved, saveNow } = useWorkflowData(id);

  const [isGenerating, setIsGenerating] = React.useState(false);
  const [debugInfo, setDebugInfo] = React.useState<string>('');

  // Enhanced debugging effect
  React.useEffect(() => {
    const info = [
      `Project ID: ${id || 'undefined'}`,
      `Loading: ${loading}`,
      `Brainstorm exists: ${!!brainstorm}`,
      `Structure exists: ${!!structure}`,
      `Characters count: ${characters?.length || 0}`,
      `Brainstorm fields: ${brainstorm ? Object.keys(brainstorm).join(', ') : 'none'}`,
      `Auth ready: checking...`
    ].join('\n');
    
    setDebugInfo(info);
    
    console.log('StructurePlanning Debug Info:', {
      projectId: id,
      loading,
      hasBrainstorm: !!brainstorm,
      hasStructure: !!structure,
      charactersCount: characters?.length || 0,
      brainstormData: brainstorm,
      brainstormFields: brainstorm ? Object.keys(brainstorm) : []
    });
  }, [id, loading, brainstorm, structure, characters]);

  const handleNext = async () => {
    // Save before navigating
    await saveNow();
    navigate(`/script/${id}/character-development`);
  };

  const handleBack = async () => {
    // Save before navigating
    await saveNow();
    navigate(`/script/${id}/brainstorm`);
  };

  // Get API key for AI generation
  const getApiKey = () => {
    return localStorage.getItem('openai-api-key') || '';
  };

  // Enhanced contextual prompt that includes Act I structure for Act II generation
  const buildContextualPrompt = (structureType: string): string => {
    let prompt = '';
    
    console.log('Building contextual prompt with:', {
      hasBrainstorm: !!brainstorm,
      brainstormKeys: brainstorm ? Object.keys(brainstorm) : [],
      charactersCount: characters?.length || 0,
      characterNames: characters?.map(c => c.name) || [],
      hasStructure: !!structure,
      act1Complete: !!(structure?.act1?.setup && structure?.act1?.incitingIncident && structure?.act1?.plotPoint1)
    });
    
    if (brainstorm) {
      if (brainstorm.idea) prompt += `Story Concept: ${brainstorm.idea}\n`;
      if (brainstorm.premise) prompt += `Premise: ${brainstorm.premise}\n`;
      if (brainstorm.logline) prompt += `Logline: ${brainstorm.logline}\n`;
      if (brainstorm.genre) prompt += `Genre: ${brainstorm.genre}\n`;
      if (brainstorm.theme) prompt += `Theme: ${brainstorm.theme}\n`;
      if (brainstorm.setting) prompt += `Setting: ${brainstorm.setting}\n`;
      if (brainstorm.tone) prompt += `Tone: ${brainstorm.tone}\n`;
      if (brainstorm.timeframe) prompt += `Time Period: ${brainstorm.timeframe}\n`;
      if (brainstorm.targetAudience) prompt += `Target Audience: ${brainstorm.targetAudience}\n`;
    }

    if (characters && characters.length > 0) {
      prompt += `\nDeveloped Characters:\n`;
      characters.forEach(char => {
        prompt += `${char.name} (${char.role}): ${char.description}\n`;
        if (char.motivation) prompt += `  Motivation: ${char.motivation}\n`;
        if (char.arc) prompt += `  Character Arc: ${char.arc}\n`;
        if (char.backstory) prompt += `  Backstory: ${char.backstory}\n`;
      });
    }

    let mainCharacterName = 'the protagonist';
    if (characters && characters.length > 0) {
      const protagonist = characters.find(c => c.role === 'protagonist') || characters[0];
      mainCharacterName = protagonist.name;
    }

    // Include Act I structure data for Act II and Act III generation
    if ((structureType === 'act2' || structureType === 'act3') && structure?.act1) {
      prompt += `\nCOMPLETED ACT I STRUCTURE:\n`;
      if (structure.act1.setup) {
        prompt += `Setup: ${structure.act1.setup}\n`;
      }
      if (structure.act1.incitingIncident) {
        prompt += `Inciting Incident: ${structure.act1.incitingIncident}\n`;
      }
      if (structure.act1.plotPoint1) {
        prompt += `Plot Point 1: ${structure.act1.plotPoint1}\n`;
      }
    }

    // Include Act II structure data for Act III generation
    if (structureType === 'act3' && structure?.act2) {
      prompt += `\nCOMPLETED ACT II STRUCTURE:\n`;
      if (structure.act2.confrontation) {
        prompt += `Confrontation: ${structure.act2.confrontation}\n`;
      }
      if (structure.act2.midpoint) {
        prompt += `Midpoint: ${structure.act2.midpoint}\n`;
      }
      if (structure.act2.plotPoint2) {
        prompt += `Plot Point 2: ${structure.act2.plotPoint2}\n`;
      }
    }

    if (structureType === 'act1') {
      prompt += `\nBased on the established story foundation above, generate complete Act 1 structure for ${mainCharacterName}'s story. Use the specific genre (${brainstorm?.genre || 'established genre'}), setting (${brainstorm?.setting || 'established setting'}), and tone (${brainstorm?.tone || 'established tone'}). Reference the developed characters by name and build directly on the core story concept and premise.

Format your response with these exact labeled sections:

Setup:
[Introduce ${mainCharacterName} in their ordinary world within the ${brainstorm?.setting || 'established setting'}. Show their current life, relationships, and what they care about before everything changes. Build on the established character development and story concept.]

Inciting Incident:
[The specific event that disrupts ${mainCharacterName}'s normal world and sets the main story in motion. This should directly relate to the core concept: ${brainstorm?.idea || 'the established story idea'}.]

Plot Point 1:
[${mainCharacterName}'s decision to pursue their goal and enter the new world of Act II. Reference their established motivation and character arc.]

Maintain consistency with the ${brainstorm?.genre || 'established genre'} genre, ${brainstorm?.tone || 'established tone'} tone, and ${brainstorm?.theme || 'established theme'} theme throughout.`;

    } else if (structureType === 'act2') {
      // Enhanced Act II prompt that builds on Act I
      prompt += `\nBased on the completed Act I structure above, generate Act 2 that directly continues ${mainCharacterName}'s story. Build specifically on the established setup, inciting incident, and Plot Point 1. Format your response with these exact labeled sections:

Confrontation:
[Building directly from Plot Point 1 (${structure?.act1?.plotPoint1 || 'the established commitment'}), show ${mainCharacterName} facing escalating obstacles in their pursuit of the goal established in Act I. Each challenge should stem from the consequences of the inciting incident (${structure?.act1?.incitingIncident || 'the established disruption'}) and test what was established in the setup phase.]

Midpoint:
[Create a major revelation or twist that fundamentally changes ${mainCharacterName}'s understanding of the situation established in the inciting incident. This should raise the stakes significantly and force them to reconsider everything they thought they knew from the setup phase.]

Plot Point 2:
[The darkest moment where ${mainCharacterName} faces the greatest consequence of their Plot Point 1 decision. All the obstacles from the confrontation phase culminate in this lowest point, making their Act I goal seem impossible to achieve.]

Ensure each element builds logically from the Act I foundation and pushes toward a compelling Act III resolution.`;

    } else if (structureType === 'act3') {
      // Enhanced Act III prompt that builds on Acts I & II
      prompt += `\nBased on the completed Act I and Act II structures above, generate Act 3 that resolves ${mainCharacterName}'s journey. Build specifically on the setup, inciting incident, confrontation, and lowest point. Format your response with these exact labeled sections:

Climax:
[${mainCharacterName} faces the final confrontation that directly addresses the core conflict established in the inciting incident. Using everything they've learned through the confrontation phase and having overcome Plot Point 2's lowest moment, they make their ultimate choice that resolves the central story question.]

Resolution:
[Show how ${mainCharacterName}'s world has changed from the original setup. Address the consequences of the climax and demonstrate their character growth. The new normal should contrast meaningfully with their ordinary world from Act I.]

Bring together all established story threads and provide satisfying closure to the character arcs developed throughout all three acts.`;
    }

    console.log('Enhanced contextual prompt with Act I structure:', prompt.substring(0, 300) + '...');
    return prompt;
  };

  // AI generation function
  const callOpenAI = async (prompt: string) => {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are a professional screenplay structure consultant. Create detailed story elements that build on existing brainstorm concepts and maintain character consistency. Always reference established characters by name and expand on the established story concept.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 400,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  };

  // Enhanced AI assist with Act I validation for Act II
  const handleAIAssist = async (field: string) => {
    // Enhanced validation for Act II generation
    if (field === 'act2') {
      if (!structure?.act1?.setup || !structure?.act1?.incitingIncident || !structure?.act1?.plotPoint1) {
        alert('Please complete all Act I fields (Setup, Inciting Incident, and Plot Point 1) before generating Act II. Act II needs to build directly on the established Act I foundation.');
        return;
      }
    }

    // Enhanced validation for Act III generation
    if (field === 'act3') {
      if (!structure?.act1?.setup || !structure?.act2?.confrontation) {
        alert('Please complete Act I and Act II before generating Act III. Act III needs to resolve the conflicts established in the previous acts.');
        return;
      }
    }

    // Check if we have brainstorm data
    if (!brainstorm) {
      alert('Please complete the Brainstorm step first to generate personalized structure. Click "Back to Brainstorm" to add your story foundation.');
      return;
    }

    setIsGenerating(true);
    
    try {
      console.log('Starting generation with project data:', { 
        field, 
        hasBrainstorm: !!brainstorm,
        brainstormIdea: brainstorm?.idea?.substring(0, 50),
        charactersCount: characters?.length || 0,
        characterNames: characters?.map(c => c.name),
        hasAct1: !!(structure?.act1?.setup && structure?.act1?.incitingIncident && structure?.act1?.plotPoint1)
      });
      
      const prompt = buildContextualPrompt(field);
      console.log('Generated enhanced prompt length:', prompt.length);
      
      const response = await callOpenAI(prompt);
      console.log('Generated response:', response.substring(0, 200) + '...');

      // Get current structure to preserve other acts
      const currentStructure: ProjectStructure = structure || {
        act1: { setup: '', incitingIncident: '', plotPoint1: '' },
        act2: { confrontation: '', midpoint: '', plotPoint2: '' },
        act3: { climax: '', resolution: '' }
      };
      
      if (field === 'act1') {
        // Parse Act 1 response into all three fields
        const setupMatch = response.match(/Setup:\s*(.*?)(?=Inciting Incident:|$)/is);
        const incitingMatch = response.match(/Inciting Incident:\s*(.*?)(?=Plot Point 1:|$)/is);
        const plotPoint1Match = response.match(/Plot Point 1:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act1: {
            setup: setupMatch ? setupMatch[1].trim() : response.split('\n')[0] || '',
            incitingIncident: incitingMatch ? incitingMatch[1].trim() : response.split('\n')[1] || '',
            plotPoint1: plotPoint1Match ? plotPoint1Match[1].trim() : response.split('\n')[2] || ''
          }
        };
        
        console.log('Generated Act 1 structure:', newStructure.act1);
        setStructure(newStructure);
        
      } else if (field === 'act2') {
        // Parse Act 2 response into all three fields
        const confrontationMatch = response.match(/Confrontation:\s*(.*?)(?=Midpoint:|$)/is);
        const midpointMatch = response.match(/Midpoint:\s*(.*?)(?=Plot Point 2:|$)/is);
        const plotPoint2Match = response.match(/Plot Point 2:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act2: {
            confrontation: confrontationMatch ? confrontationMatch[1].trim() : response.split('\n')[0] || '',
            midpoint: midpointMatch ? midpointMatch[1].trim() : response.split('\n')[1] || '',
            plotPoint2: plotPoint2Match ? plotPoint2Match[1].trim() : response.split('\n')[2] || ''
          }
        };
        
        setStructure(newStructure);
        
      } else if (field === 'act3') {
        // Parse Act 3 response into both fields
        const climaxMatch = response.match(/Climax:\s*(.*?)(?=Resolution:|$)/is);
        const resolutionMatch = response.match(/Resolution:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act3: {
            climax: climaxMatch ? climaxMatch[1].trim() : response.split('\n')[0] || '',
            resolution: resolutionMatch ? resolutionMatch[1].trim() : response.split('\n')[1] || ''
          }
        };
        
        setStructure(newStructure);
      }

      console.log('Structure generation completed successfully');
      
    } catch (error) {
      console.error('Structure generation failed:', error);
      alert(`Structure generation failed. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Show loading state while fetching data from Supabase
  if (loading) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-center min-h-96">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p className="text-script-slate-600">Loading structure data...</p>
              <p className="text-xs text-script-slate-500 mt-2">Authenticating and loading project data...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Enhanced missing brainstorm message with debugging info
  if (!brainstorm) {
    return (
      <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
        <Header />
        
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Button 
            variant="ghost" 
            onClick={handleBack}
            className={`mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('backToBrainstorm')}
          </Button>

          <div className="text-center py-12">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 max-w-md mx-auto mb-6">
              <AlertCircle className="h-8 w-8 text-yellow-600 mx-auto mb-4" />
              <h2 className="text-lg font-semibold text-yellow-800 mb-2">Complete Brainstorm First</h2>
              <p className="text-yellow-700 mb-4">
                To generate personalized structure that references your specific story elements, you need to complete the Brainstorm step first.
              </p>
              <Button onClick={handleBack} className="bg-yellow-600 hover:bg-yellow-700">
                Go to Brainstorm
              </Button>
            </div>

            {/* Debug information */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 max-w-md mx-auto">
              <h3 className="text-sm font-medium text-gray-800 mb-2">Debug Information</h3>
              <pre className="text-xs text-gray-600 text-left whitespace-pre-wrap">{debugInfo}</pre>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Act 1 fields configuration
  const act1Fields = [
    {
      key: 'setup',
      label: t('setup'),
      placeholder: "Introduce your protagonist in their ordinary world. Show their current life, relationships, and what they care about before everything changes.",
      value: structure?.act1?.setup || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act1: { ...currentStructure.act1, setup: value }
        });
      }
    },
    {
      key: 'incitingIncident',
      label: t('incitingIncident'),
      placeholder: "The event that disrupts the protagonist's normal world and sets the story in motion. This should happen early and create the central conflict.",
      value: structure?.act1?.incitingIncident || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act1: { ...currentStructure.act1, incitingIncident: value }
        });
      }
    },
    {
      key: 'plotPoint1',
      label: t('plotPoint1'),
      placeholder: "The protagonist makes a decision to pursue their goal and enter the new world of Act II. There's no turning back now.",
      value: structure?.act1?.plotPoint1 || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act1: { ...currentStructure.act1, plotPoint1: value }
        });
      }
    }
  ];

  // Act 2 fields configuration
  const act2Fields = [
    {
      key: 'confrontation',
      label: t('confrontation'),
      placeholder: "The protagonist faces increasing obstacles while pursuing their goal. Each challenge should build toward the midpoint revelation.",
      value: structure?.act2?.confrontation || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act2: { ...currentStructure.act2, confrontation: value }
        });
      }
    },
    {
      key: 'midpoint',
      label: t('midpoint'),
      placeholder: "A major twist or revelation that changes everything. The protagonist gains new information that raises the stakes significantly.",
      value: structure?.act2?.midpoint || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act2: { ...currentStructure.act2, midpoint: value }
        });
      }
    },
    {
      key: 'plotPoint2',
      label: t('plotPoint2'),
      placeholder: "The darkest moment where all seems lost. The protagonist faces their greatest fear or lowest point before the final act.",
      value: structure?.act2?.plotPoint2 || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act2: { ...currentStructure.act2, plotPoint2: value }
        });
      }
    }
  ];

  // Act 3 fields configuration
  const act3Fields = [
    {
      key: 'climax',
      label: t('climax'),
      placeholder: "The final confrontation where the protagonist faces their biggest challenge using everything they've learned throughout the story.",
      value: structure?.act3?.climax || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act3: { ...currentStructure.act3, climax: value }
        });
      }
    },
    {
      key: 'resolution',
      label: t('resolution'),
      placeholder: "Show the new normal. How has the protagonist changed? What is their world like now that the conflict is resolved?",
      value: structure?.act3?.resolution || '',
      onChange: (value: string) => {
        const currentStructure: ProjectStructure = structure || {
          act1: { setup: '', incitingIncident: '', plotPoint1: '' },
          act2: { confrontation: '', midpoint: '', plotPoint2: '' },
          act3: { climax: '', resolution: '' }
        };
        setStructure({
          ...currentStructure,
          act3: { ...currentStructure.act3, resolution: value }
        });
      }
    }
  ];

  const canProceed = !!structure && !!(structure?.act1?.setup && structure?.act2?.confrontation && structure?.act3?.climax);

  return (
    <div className={`min-h-screen bg-script-slate-50 ${isRTL ? 'font-arabic' : 'font-script'}`}>
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Navigation */}
        <Button 
          variant="ghost" 
          onClick={handleBack}
          className={`mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('backToBrainstorm')}
        </Button>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">{t('threeActStructureTitle')}</h1>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{t('phaseTwoOfFour')}</Badge>
              {/* Save status indicator */}
              {saving && (
                <div className="flex items-center text-xs text-script-slate-500">
                  <Loader2 className="h-3 w-3 animate-spin mr-1" />
                  Saving...
                </div>
              )}
              {lastSaved && !saving && (
                <div className="flex items-center text-xs text-green-600">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Saved {lastSaved.toLocaleTimeString()}
                </div>
              )}
            </div>
          </div>
          
          {/* Show story foundation info */}
          {brainstorm && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <h3 className="font-medium text-green-800 mb-2">Story Foundation Loaded</h3>
              <div className="text-sm text-green-700 grid grid-cols-2 gap-2">
                {brainstorm.idea && <div><strong>Idea:</strong> {brainstorm.idea.substring(0, 60)}...</div>}
                {brainstorm.genre && <div><strong>Genre:</strong> {brainstorm.genre}</div>}
                {brainstorm.setting && <div><strong>Setting:</strong> {brainstorm.setting}</div>}
                {characters.length > 0 && <div><strong>Characters:</strong> {characters.length} developed</div>}
              </div>
            </div>
          )}
          
          <ThreeActVisualization />
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Tabs defaultValue="act1" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="act1">{t('act1Setup')}</TabsTrigger>
                <TabsTrigger value="act2">{t('act2Confrontation')}</TabsTrigger>
                <TabsTrigger value="act3">{t('act3Resolution')}</TabsTrigger>
              </TabsList>

              <ActCard
                actNumber={1}
                tabValue="act1"
                title={t('act1Setup')}
                subtitle={t('setupPages')}
                icon={<Target className="h-5 w-5 text-green-500" />}
                fields={act1Fields}
                onAIAssist={handleAIAssist}
                isGenerating={isGenerating}
              />

              <ActCard
                actNumber={2}
                tabValue="act2"
                title={t('act2Confrontation')}
                subtitle={t('confrontationPages')}
                icon={<Zap className="h-5 w-5 text-blue-500" />}
                fields={act2Fields}
                onAIAssist={handleAIAssist}
                isGenerating={isGenerating}
              />

              <ActCard
                actNumber={3}
                tabValue="act3"
                title={t('act3Resolution')}
                subtitle={t('resolutionPages')}
                icon={<BookOpen className="h-5 w-5 text-purple-500" />}
                fields={act3Fields}
                onAIAssist={handleAIAssist}
                isGenerating={isGenerating}
              />
            </Tabs>
          </div>
          
          <div className="lg:col-span-1">
            <AIAssistant context="structure" projectData={{ brainstorm, structure, characters }} />
          </div>
        </div>

        <StructureNavigation
          projectId={id || ''}
          onBack={handleBack}
          onNext={handleNext}
          canProceed={canProceed}
        />
      </div>
    </div>
  );
};

export default StructurePlanningPage;
