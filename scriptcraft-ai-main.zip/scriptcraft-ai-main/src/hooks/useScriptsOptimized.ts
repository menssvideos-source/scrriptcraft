
import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '../integrations/supabase/client';
import { Script } from '../types/script';

export const useScriptsOptimized = () => {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ✅ Optimized fetch function - only get metadata for list view
  const fetchScripts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setScripts([]);
        return;
      }

      console.log('useScriptsOptimized: Fetching optimized scripts list for user:', user.id);

      // ✅ Optimized query - only fetch fields needed for list view
      const { data, error } = await supabase
        .from('scripts')
        .select(`
          id,
          title,
          description,
          genre,
          created_at,
          updated_at,
          word_count,
          page_count,
          scene_count
        `)
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('useScriptsOptimized: Database error:', error);
        throw error;
      }

      console.log('useScriptsOptimized: Fetched', data?.length || 0, 'scripts (metadata only)');

      // Transform to match Script type without heavy content processing
      const transformedScripts: Script[] = (data || []).map(script => {
        let template: 'feature-film' | 'tv-episode' | 'short-film' = 'feature-film';
        if (script.genre === 'tv-episode' || script.genre === 'short-film') {
          template = script.genre as 'tv-episode' | 'short-film';
        }

        return {
          id: script.id,
          title: script.title || 'Untitled Script',
          description: script.description || '',
          template,
          createdAt: new Date(script.created_at),
          lastModified: new Date(script.updated_at),
          wordCount: script.word_count || 0,
          pageCount: script.page_count || 1,
          sceneCount: script.scene_count || 0,
          isStarred: false
        };
      });

      setScripts(transformedScripts);
      console.log('useScriptsOptimized: Successfully transformed and set scripts');
    } catch (err) {
      console.error('useScriptsOptimized: Error fetching scripts:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch scripts');
    } finally {
      setLoading(false);
    }
  }, []);

  // ✅ Memoized operations
  const createScript = useCallback(async (title: string, description: string, template: string) => {
    try {
      console.log('useScriptsOptimized: Creating new script:', { title, template });
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('scripts')
        .insert({
          title,
          description,
          genre: template,
          user_id: user.id,
          content: { elements: [] }, // Minimal content structure
          word_count: 0,
          page_count: 1,
          scene_count: 0
        })
        .select('id')
        .single();

      if (error) throw error;

      console.log('useScriptsOptimized: Script created successfully:', data.id);
      await fetchScripts(); // Refresh the list
      return data.id;
    } catch (err) {
      console.error('useScriptsOptimized: Error creating script:', err);
      throw err;
    }
  }, [fetchScripts]);

  const deleteScript = useCallback(async (scriptId: string) => {
    try {
      console.log('useScriptsOptimized: Deleting script:', scriptId);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('scripts')
        .delete()
        .eq('id', scriptId)
        .eq('user_id', user.id);

      if (error) throw error;

      // ✅ Optimistic update
      setScripts(prev => prev.filter(s => s.id !== scriptId));
      console.log('useScriptsOptimized: Script deleted successfully');
    } catch (err) {
      console.error('useScriptsOptimized: Error deleting script:', err);
      throw err;
    }
  }, []);

  const duplicateScript = useCallback(async (scriptId: string) => {
    try {
      console.log('useScriptsOptimized: Duplicating script:', scriptId);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Get original script with minimal data needed for duplication
      const { data: originalScript, error: fetchError } = await supabase
        .from('scripts')
        .select('title, description, genre, content, word_count, page_count, scene_count')
        .eq('id', scriptId)
        .eq('user_id', user.id)
        .single();

      if (fetchError) throw fetchError;

      const { data, error } = await supabase
        .from('scripts')
        .insert({
          title: `${originalScript.title} (Copy)`,
          description: originalScript.description,
          genre: originalScript.genre,
          content: originalScript.content,
          word_count: originalScript.word_count,
          page_count: originalScript.page_count,
          scene_count: originalScript.scene_count,
          user_id: user.id
        })
        .select('id')
        .single();

      if (error) throw error;

      console.log('useScriptsOptimized: Script duplicated successfully:', data.id);
      await fetchScripts(); // Refresh the list
      return data.id;
    } catch (err) {
      console.error('useScriptsOptimized: Error duplicating script:', err);
      throw err;
    }
  }, [fetchScripts]);

  useEffect(() => {
    fetchScripts();
  }, [fetchScripts]);

  // ✅ Memoize return value to prevent unnecessary re-renders
  return useMemo(() => ({
    scripts,
    loading,
    error,
    fetchScripts,
    createScript,
    deleteScript,
    duplicateScript
  }), [scripts, loading, error, fetchScripts, createScript, deleteScript, duplicateScript]);
};
