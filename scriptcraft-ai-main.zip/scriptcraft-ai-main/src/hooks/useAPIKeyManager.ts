
import { useState, useEffect } from 'react';
import { storageService } from '../services/StorageService';
import { useAuth } from '../contexts/AuthContext';

export const useAPIKeyManager = () => {
  const { user } = useAuth();
  const [apiKey, setApiKeyState] = useState('');

  // Load API key on mount or when user changes
  useEffect(() => {
    const savedApiKey = storageService.getAPIKey('openai', user?.id || null);
    if (savedApiKey) {
      setApiKeyState(savedApiKey);
    } else {
      setApiKeyState('');
    }
  }, [user?.id]);

  // Save API key when it changes
  const setApiKey = (key: string) => {
    setApiKeyState(key);
    if (key.trim()) {
      storageService.setAPIKey('openai', key, user?.id || null);
    }
  };

  return {
    apiKey,
    setApiKey
  };
};
