
import { useCallback, useRef } from 'react';
import { ScriptElement } from '../types/script';
import { useSceneGeneration } from './useSceneGeneration';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';

/**
 * Hook responsible for all script editor actions and user interactions
 * FIXED: Eliminated React Error #310 by using stable references and preventing stale closures
 */
export const useScriptActions = (
  elements: ScriptElement[],
  setElements: (elements: ScriptElement[]) => void,
  brainstorm: ProjectBrainstorm | null,
  structure: ProjectStructure | null,
  characters: Character[],
  saveScript: () => Promise<void>,
  setIsGenerating: (generating: boolean) => void,
  setShowSceneGenerator: (show: boolean) => void,
  setSelectedSceneType: (type: string) => void,
  selectedSceneType: string
) => {
  const { generateScene } = useSceneGeneration();
  
  // FIXED: Use useRef to store stable reference to avoid circular dependencies
  const saveScriptRef = useRef(saveScript);
  saveScriptRef.current = saveScript;

  // FIXED: Stable callback for adding new elements
  const handleAddNewElement = useCallback(() => {
    const newElement: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'action',
      content: ''
    };
    const newElements = [...elements, newElement];
    setElements(newElements);
  }, [elements, setElements]);

  // FIXED: Stable callback for inserting character names
  const handleInsertCharacterName = useCallback((characterName: string) => {
    const newElement: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'character',
      content: characterName.toUpperCase()
    };
    const newElements = [...elements, newElement];
    setElements(newElements);
  }, [elements, setElements]);

  // FIXED: Stable wrapper for saveScript that accepts elements parameter
  const saveScriptWithElements = useCallback(async (elementsToSave: ScriptElement[]) => {
    // Update elements first, then save
    setElements(elementsToSave);
    // Wait for the next tick to ensure elements are updated
    await new Promise(resolve => setTimeout(resolve, 0));
    await saveScriptRef.current();
  }, [setElements]); // FIXED: Removed saveScript from dependencies, using ref instead

  // FIXED: Stable callback for generating first scene
  const generateFirstScene = useCallback(() => {
    generateScene(
      'first',
      brainstorm,
      structure,
      characters,
      elements,
      setElements,
      saveScriptWithElements,
      setIsGenerating,
      setShowSceneGenerator,
      setSelectedSceneType
    );
  }, [
    brainstorm,
    structure,
    characters,
    elements,
    setElements,
    saveScriptWithElements,
    generateScene,
    setIsGenerating,
    setShowSceneGenerator,
    setSelectedSceneType
  ]); // FIXED: Stable dependencies only
  
  // FIXED: Stable callback for generating next scene
  const generateNextScene = useCallback(() => {
    const sceneType = selectedSceneType || 'next';
    generateScene(
      sceneType,
      brainstorm,
      structure,
      characters,
      elements,
      setElements,
      saveScriptWithElements,
      setIsGenerating,
      setShowSceneGenerator,
      setSelectedSceneType
    );
  }, [
    selectedSceneType,
    brainstorm,
    structure,
    characters,
    elements,
    setElements,
    saveScriptWithElements,
    generateScene,
    setIsGenerating,
    setShowSceneGenerator,
    setSelectedSceneType
  ]); // FIXED: Stable dependencies only

  return {
    // Element manipulation actions
    handleAddNewElement,
    handleInsertCharacterName,
    
    // Scene generation actions
    generateFirstScene,
    generateNextScene
  };
};
