
import { useCallback, useRef, useEffect } from 'react';
import { ScriptElement } from '../types/script';

interface UseDebouncedSaveOptions {
  delay?: number;
  onSave: (elements: ScriptElement[]) => Promise<void>;
  onError?: (error: Error) => void;
}

export const useDebouncedSave = ({ 
  delay = 2000, 
  onSave, 
  onError 
}: UseDebouncedSaveOptions) => {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasUnsavedChangesRef = useRef(false);

  // ✅ Debounced save function
  const debouncedSave = useCallback(async (elements: ScriptElement[]) => {
    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    hasUnsavedChangesRef.current = true;

    // Set new timeout
    timeoutRef.current = setTimeout(async () => {
      try {
        console.log('Auto-saving script with', elements.length, 'elements');
        await onSave(elements);
        hasUnsavedChangesRef.current = false;
        console.log('Auto-save completed successfully');
      } catch (error) {
        console.error('Auto-save failed:', error);
        onError?.(error as Error);
      }
    }, delay);
  }, [delay, onSave, onError]);

  // ✅ Force immediate save (for critical moments like page unload)
  const flushSave = useCallback(async (elements: ScriptElement[]) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    if (hasUnsavedChangesRef.current) {
      try {
        await onSave(elements);
        hasUnsavedChangesRef.current = false;
      } catch (error) {
        console.error('Flush save failed:', error);
        onError?.(error as Error);
      }
    }
  }, [onSave, onError]);

  // ✅ Cleanup and beforeunload protection
  useEffect(() => {
    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      if (hasUnsavedChangesRef.current) {
        event.preventDefault();
        event.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return {
    debouncedSave,
    flushSave,
    hasUnsavedChanges: () => hasUnsavedChangesRef.current
  };
};
