
import { useScriptData } from './useScriptData';
import { useScriptUI } from './useScriptUI';
import { useCallback } from 'react';
import { ScriptElement } from '../types/script';

/**
 * Simplified script editor hook with only essential functionality
 * Removed problematic scene generation and AI features to prevent React Error #310
 */
export const useScriptEditor = (scriptId: string) => {
  // Data management
  const {
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    handleTitleSave,
    handleSaveScript
  } = useScriptData(scriptId);

  // UI state management
  const {
    activeElement,
    setActiveElement
  } = useScriptUI(elements);

  // Simple add new element handler
  const handleAddNewElement = useCallback(() => {
    const newElement: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'action',
      content: ''
    };
    const newElements = [...elements, newElement];
    setElements(newElements);
    setActiveElement(newElement.id);
  }, [elements, setElements, setActiveElement]);

  return {
    // Script data
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    
    // Title management
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    handleTitleSave,
    
    // UI state
    activeElement,
    setActiveElement,
    
    // Actions
    handleSaveScript,
    handleAddNewElement
  };
};
