
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useScriptFetching } from './useScriptFetching';
import { useScriptSaving } from './useScriptSaving';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export const useScript = (scriptId: string) => {
  const {
    script,
    setScript,
    elements,
    setElements,
    loading,
    error: fetchError,
    fetchScript: fetchScriptData
  } = useScriptFetching();

  const {
    saving,
    error: saveError,
    saveScript: saveScriptData
  } = useScriptSaving();

  // ✅ Use ref to track if we've already fetched for this script ID
  const lastFetchedScriptId = useRef<string | null>(null);
  const isInitialMount = useRef(true);

  // ✅ Stable fetchScript function that doesn't cause dependency loops
  const fetchScript = useCallback(async (id: string) => {
    console.log('useScript: fetchScript called for ID:', id);
    
    // Prevent duplicate fetches for the same script
    if (lastFetchedScriptId.current === id && !isInitialMount.current) {
      console.log('useScript: Skipping duplicate fetch for ID:', id);
      return;
    }
    
    lastFetchedScriptId.current = id;
    await fetchScriptData(id);
  }, [fetchScriptData]);

  // ✅ Memoized saveScript function
  const saveScript = useCallback(async (elementsToSave?: ScriptElement[]) => {
    const contentToSave = elementsToSave || elements;
    await saveScriptData(scriptId, contentToSave);
  }, [scriptId, elements, saveScriptData]);

  // ✅ Effect with stable dependencies - only runs when scriptId changes
  useEffect(() => {
    if (scriptId && scriptId !== lastFetchedScriptId.current) {
      console.log('useScript: useEffect triggered for new scriptId:', scriptId);
      fetchScript(scriptId);
    } else if (!scriptId) {
      console.log('useScript: No scriptId provided to useEffect');
    }
    
    // Mark that initial mount is complete
    isInitialMount.current = false;
  }, [scriptId, fetchScript]);

  // ✅ Combine errors from both hooks
  const error = fetchError || saveError;

  // ✅ Return memoized object to prevent unnecessary re-renders
  return useMemo(() => ({
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    saveScript,
    fetchScript,
    // Utility function to refetch current script
    refetch: () => scriptId && fetchScript(scriptId)
  }), [
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    saveScript,
    fetchScript,
    scriptId
  ]);
};
