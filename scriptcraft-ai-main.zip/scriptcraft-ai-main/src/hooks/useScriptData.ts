
import { useEffect, useCallback, useMemo, useRef } from 'react';
import { useScript } from './useScript';
import { useScriptTitle } from './useScriptTitle';

/**
 * Optimized script data hook with stable references and minimal re-renders
 * Fixed dependency loops and excessive re-rendering issues
 */
export const useScriptData = (scriptId: string) => {
  const { script, elements, setElements, loading, saving, error, saveScript } = useScript(scriptId);
  const {
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    loadScript,
    saveScriptTitle,
    resetTitleState
  } = useScriptTitle();

  // ✅ Use refs to track previous values and prevent unnecessary effects
  const prevScriptIdRef = useRef<string | null>(null);
  const prevScriptTitleRef = useRef<string | null>(null);
  const isInitialLoadRef = useRef(true);

  // ✅ Load script title when component mounts or scriptId changes
  useEffect(() => {
    if (scriptId && scriptId !== prevScriptIdRef.current && !loading) {
      console.log('useScriptData: Loading script title for new script:', scriptId);
      prevScriptIdRef.current = scriptId;
      resetTitleState();
      loadScript(scriptId);
    }
  }, [scriptId, loading, resetTitleState, loadScript]);

  // ✅ Set script title from loaded script data (only when it actually changes)
  useEffect(() => {
    if (script?.title && script.title !== prevScriptTitleRef.current) {
      console.log('useScriptData: Setting script title from loaded script:', script.title);
      prevScriptTitleRef.current = script.title;
      setScriptTitle(script.title);
    }
  }, [script?.title, setScriptTitle]);

  // ✅ Stable save handlers with memoization
  const handleSaveScript = useCallback(async () => {
    try {
      console.log('useScriptData: Manual save initiated with', elements.length, 'elements');
      await saveScript(elements);
      console.log('Script saved successfully');
    } catch (error) {
      console.error('Failed to save script:', error);
      alert('Failed to save script. Please try again.');
    }
  }, [saveScript, elements]);

  const handleTitleSave = useCallback(async (newTitle: string) => {
    if (scriptId && newTitle.trim()) {
      console.log('useScriptData: Saving title:', newTitle);
      try {
        await saveScriptTitle(scriptId, newTitle);
        console.log('useScriptData: Title saved successfully');
      } catch (error) {
        console.error('useScriptData: Failed to save title:', error);
        throw error;
      }
    }
  }, [scriptId, saveScriptTitle]);

  // ✅ Return memoized object with stable references
  return useMemo(() => ({
    // Script data
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    
    // Title management
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    handleTitleSave,
    
    // Actions
    handleSaveScript
  }), [
    script,
    elements,
    setElements,
    loading,
    saving,
    error,
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    handleTitleSave,
    handleSaveScript
  ]);
};
