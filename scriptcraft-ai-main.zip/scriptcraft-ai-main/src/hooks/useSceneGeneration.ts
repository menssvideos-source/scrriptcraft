
import { useState } from 'react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { ScriptElement } from '../types/script';
import { SceneNumbering } from '../lib/sceneNumbering';
import { createAIService } from '../services/AIService';
import { ContextService } from '../services/ContextService';

export const useSceneGeneration = () => {
  const [isSaving, setIsSaving] = useState(false);

  const getApiKey = () => {
    return localStorage.getItem('openai-api-key') || '';
  };

  const generateScene = async (
    sceneType: string,
    brainstorm: ProjectBrainstorm | null,
    structure: ProjectStructure | null,
    characters: Character[],
    elements: ScriptElement[],
    setElements: (elements: ScriptElement[]) => void,
    saveScript: (elements: ScriptElement[]) => Promise<void>,
    setIsGenerating: (generating: boolean) => void,
    setShowSceneGenerator: (show: boolean) => void,
    setSelectedSceneType: (type: string) => void,
    scriptTitle?: string
  ) => {
    const apiKey = getApiKey();
    if (!apiKey.trim()) {
      alert('Please enter your OpenAI API key in the AI Assistant panel first');
      return;
    }

    setIsGenerating(true);
    setIsSaving(true);
    
    try {
      const aiService = createAIService(apiKey);
      const nextSceneNumber = SceneNumbering.getNextSceneNumber(elements);
      
      const context = {
        brainstorm,
        structure,
        characters,
        existingElements: elements,
        sceneType,
        nextSceneNumber
      };

      console.log('Generating enhanced context-aware scene:', { 
        sceneType, 
        nextSceneNumber, 
        elementsCount: elements.length,
        hasCharacters: characters.length > 0,
        hasBrainstorm: !!brainstorm,
        hasStructure: !!structure,
        scriptTitle
      });
      
      // Build story context for enhanced AI prompts
      const storyContext = ContextService.buildStoryContext(
        brainstorm,
        structure,
        characters,
        elements,
        scriptTitle
      );
      
      const prompt = aiService.buildScenePrompt(context, scriptTitle);
      console.log('Enhanced context-aware prompt:', prompt.substring(0, 200) + '...');
      
      const sceneContent = await aiService.callOpenAI(prompt, undefined, storyContext);
      const newSceneElements = aiService.parseSceneContent(sceneContent);
      
      console.log('Generated scene elements with enhanced context:', newSceneElements.length);
      
      const newElements: ScriptElement[] = [...elements];
      
      // Add transition if not the first scene
      if (elements.length > 3) {
        newElements.push({
          id: Date.now().toString(),
          type: 'transition',
          content: 'CUT TO:'
        });
      }
      
      newElements.push(...newSceneElements);
      
      console.log('Total elements after enhanced context-aware generation:', newElements.length);
      
      // Update elements immediately
      setElements(newElements);
      
      // Save immediately after generation to Supabase
      console.log('Saving enhanced context-aware script to Supabase...');
      await saveScript(newElements);
      console.log('Enhanced context-aware script saved successfully to Supabase');
      
      setShowSceneGenerator(false);
      setSelectedSceneType('');
      
    } catch (error) {
      console.error('Enhanced context-aware scene generation failed:', error);
      alert(`Scene generation failed. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
      setIsSaving(false);
    }
  };

  return {
    generateScene,
    getApiKey,
    isSaving
  };
};
