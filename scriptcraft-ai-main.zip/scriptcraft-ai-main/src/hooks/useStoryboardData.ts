
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { StoryboardFrame } from '../lib/storyboard';
import { ImageStorageService } from '../lib/imageStorage';
import { StoryboardGenerator } from '../lib/storyboard';
import { AVAILABLE_IMAGE_MODELS } from '../contexts/APIKeyContext';
import { toast } from '../components/ui/sonner';

export const useStoryboardData = (imageApiKey: string) => {
  const { id } = useParams();
  const [storyboardFrames, setStoryboardFrames] = useState<StoryboardFrame[]>([]);
  const [loadingImages, setLoadingImages] = useState(false);

  // Load storyboard data exclusively from Supabase
  useEffect(() => {
    const loadStoryboardData = async () => {
      if (id) {
        setLoadingImages(true);
        
        try {
          console.log('Loading storyboard data from Supabase for script:', id);
          
          // Load stored images from Supabase only
          const imageStorage = new ImageStorageService();
          const storedImages = await imageStorage.getStoredImages(id);
          
          if (storedImages.length > 0) {
            console.log(`Found ${storedImages.length} stored images in Supabase`);
            
            // Convert stored images back to frames
            const frames: StoryboardFrame[] = storedImages.map(img => ({
              id: img.frame_id,
              sceneId: img.frame_id,
              sceneNumber: img.scene_number,
              title: img.title,
              visualDescription: 'Generated storyboard frame',
              shotType: 'Multi-Panel Layout',
              cameraAngle: 'Various Angles',
              mood: 'Cinematic',
              lighting: 'Dynamic',
              composition: '3-panel storyboard layout',
              panelCount: 3,
              keyMoments: [],
              imageUrl: ''
            }));
            
            // Load the actual image URLs
            const defaultImageModel = AVAILABLE_IMAGE_MODELS[0]; // Use the complete DALL-E 3 model
            const generator = new StoryboardGenerator(imageApiKey || 'temp', defaultImageModel);
            const framesWithStoredImages = await generator.loadStoredImages(id, frames);
            setStoryboardFrames(framesWithStoredImages);
            console.log('Successfully loaded stored images from Supabase');
          } else {
            console.log('No existing storyboard data found in Supabase');
            setStoryboardFrames([]);
          }
        } catch (error) {
          console.error('Failed to load storyboard data from Supabase:', error);
          toast.error('Failed to load storyboard data');
          setStoryboardFrames([]);
        } finally {
          setLoadingImages(false);
        }
      }
    };

    loadStoryboardData();
  }, [id, imageApiKey]);

  const updateStoryboardFrames = (updatedFrames: StoryboardFrame[]) => {
    console.log('Updating storyboard frames:', updatedFrames.length);
    setStoryboardFrames(updatedFrames);
    // Remove localStorage usage - data persistence handled by Supabase
  };

  return {
    storyboardFrames,
    loadingImages,
    updateStoryboardFrames,
    setStoryboardFrames
  };
};
