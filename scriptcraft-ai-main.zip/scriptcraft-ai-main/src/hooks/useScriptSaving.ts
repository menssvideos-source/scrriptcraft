
import { useState } from 'react';
import { supabase } from '../integrations/supabase/client';
import { useScriptValidation } from './useScriptValidation';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export const useScriptSaving = () => {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isValidUUID } = useScriptValidation();

  const saveScript = async (scriptId: string, elements: ScriptElement[]) => {
    try {
      console.log('useScriptSaving: Starting saveScript to Supabase');
      setSaving(true);
      setError(null);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      if (!isValidUUID(scriptId)) {
        throw new Error('Invalid script ID');
      }

      console.log('useScriptSaving: Saving', elements.length, 'elements to Supabase');

      // Get current content to preserve workflow data
      const { data: currentScript } = await supabase
        .from('scripts')
        .select('content')
        .eq('id', scriptId)
        .eq('user_id', user.id)
        .single();

      // Ensure currentContent is a proper object, defaulting to empty object if null/undefined
      const currentContent = (currentScript?.content && typeof currentScript.content === 'object') 
        ? currentScript.content as Record<string, any>
        : {};
      
      // Update content with new elements while preserving workflow data
      const updatedContent = {
        ...currentContent,
        elements: elements
      };

      const { error } = await supabase
        .from('scripts')
        .update({
          content: updatedContent as any, // Cast to any to satisfy Json type
          updated_at: new Date().toISOString()
        })
        .eq('id', scriptId)
        .eq('user_id', user.id);

      if (error) throw error;

      console.log('useScriptSaving: Script saved successfully to Supabase');
    } catch (err) {
      console.error('useScriptSaving: Error saving script:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to save script';
      setError(errorMessage);
      throw err;
    } finally {
      setSaving(false);
    }
  };

  return {
    saving,
    error: error,
    saveScript
  };
};
