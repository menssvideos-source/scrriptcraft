
import { useState, useRef, useCallback } from 'react';
import { supabase } from '../integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { useScriptValidation } from './useScriptValidation';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export const useScriptFetching = () => {
  const [script, setScript] = useState<any>(null);
  const [elements, setElements] = useState<ScriptElement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { isValidUUID } = useScriptValidation();

  // ✅ Use ref to track current request and prevent race conditions
  const currentRequestRef = useRef<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const createNewScript = useCallback(async (userId: string) => {
    const { data: newScript, error: createError } = await supabase
      .from('scripts')
      .insert({
        title: null,
        description: 'New screenplay project',
        genre: 'feature-film',
        user_id: userId,
        content: {
          elements: [],
          brainstorm: null,
          structure: null,
          characters: []
        }
      })
      .select()
      .single();

    if (createError) {
      console.error('useScriptFetching: Error creating new script:', createError);
      throw createError;
    }

    console.log('useScriptFetching: Created new script:', newScript.id);
    navigate(`/script/${newScript.id}`, { replace: true });
    return newScript;
  }, [navigate]);

  // ✅ Stable fetchScript function with request deduplication and race condition prevention
  const fetchScript = useCallback(async (scriptId: string) => {
    try {
      console.log('useScriptFetching: Starting fetchScript for ID:', scriptId);

      // Cancel previous request if it exists
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      // Create new abort controller for this request
      const abortController = new AbortController();
      abortControllerRef.current = abortController;

      // Skip if this is a duplicate request
      if (currentRequestRef.current === scriptId) {
        console.log('useScriptFetching: Skipping duplicate request for:', scriptId);
        return;
      }

      currentRequestRef.current = scriptId;
      setLoading(true);
      setError(null);

      if (!scriptId) {
        console.log('useScriptFetching: No script ID provided');
        setError('No script ID provided');
        return;
      }

      const { data: { user }, error: authError } = await supabase.auth.getUser();
      
      if (authError) {
        console.error('useScriptFetching: Auth error:', authError);
        setError('Authentication error');
        return;
      }

      if (!user) {
        console.log('useScriptFetching: No authenticated user');
        setError('User not authenticated');
        return;
      }

      console.log('useScriptFetching: User authenticated:', user.id);

      if (!isValidUUID(scriptId)) {
        console.log('useScriptFetching: Invalid UUID format, creating new script...');
        await createNewScript(user.id);
        return;
      }

      console.log('useScriptFetching: Fetching script with valid UUID:', scriptId);

      const { data, error: fetchError } = await supabase
        .from('scripts')
        .select('*')
        .eq('id', scriptId)
        .eq('user_id', user.id)
        .abortSignal(abortController.signal)
        .single();

      // Check if request was aborted
      if (abortController.signal.aborted) {
        console.log('useScriptFetching: Request was aborted');
        return;
      }

      if (fetchError) {
        console.error('useScriptFetching: Fetch error:', fetchError);
        
        if (fetchError.code === 'PGRST116') {
          console.log('useScriptFetching: Script not found, creating new script...');
          await createNewScript(user.id);
          return;
        }
        throw fetchError;
      }

      console.log('useScriptFetching: Successfully fetched script:', data.id);
      
      // Only update state if request wasn't aborted
      if (!abortController.signal.aborted) {
        setScript(data);
        
        // Load script elements from content.elements in JSONB
        if (data.content && typeof data.content === 'object') {
          const content = data.content as any;
          
          // Extract elements from the structured content
          let scriptElements: ScriptElement[] = [];
          
          if (Array.isArray(content.elements)) {
            scriptElements = content.elements.filter((item: any) => 
              item && 
              typeof item === 'object' && 
              typeof item.id === 'string' && 
              typeof item.type === 'string' && 
              typeof item.content === 'string'
            );
          } else if (Array.isArray(content)) {
            // Fallback for old format
            scriptElements = content.filter((item: any) => 
              item && 
              typeof item === 'object' && 
              typeof item.id === 'string' && 
              typeof item.type === 'string' && 
              typeof item.content === 'string'
            );
          }
          
          console.log('useScriptFetching: Loaded elements from Supabase:', scriptElements.length);
          setElements(scriptElements);
        } else {
          console.log('useScriptFetching: No content found, using default elements');
          const defaultElements: ScriptElement[] = [
            { id: '1', type: 'scene-heading', content: 'FADE IN:' },
            { id: '2', type: 'scene-heading', content: '' },
            { id: '3', type: 'action', content: '' }
          ];
          setElements(defaultElements);
        }
      }
    } catch (err) {
      if (err.name === 'AbortError') {
        console.log('useScriptFetching: Request was aborted');
        return;
      }
      
      console.error('useScriptFetching: Error in fetchScript:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch script');
    } finally {
      // Only update loading state if request wasn't aborted
      if (!abortControllerRef.current?.signal.aborted) {
        setLoading(false);
        currentRequestRef.current = null;
      }
    }
  }, [isValidUUID, createNewScript]);

  // ✅ Cleanup function to abort ongoing requests
  const cleanup = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    currentRequestRef.current = null;
  }, []);

  return {
    script,
    setScript,
    elements,
    setElements,
    loading,
    error,
    fetchScript,
    cleanup
  };
};
