import { useState, useEffect } from 'react';
import { supabase } from '../integrations/supabase/client';
import { Script } from '../types/script';

export const useScripts = () => {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const calculateWordCount = (content: any): number => {
    if (!content) return 0;
    
    // Handle different content formats
    if (typeof content === 'string') {
      return content.trim().split(/\s+/).filter(word => word.length > 0).length;
    }
    
    if (Array.isArray(content)) {
      return content.reduce((total, element) => {
        if (element && typeof element === 'object' && element.content) {
          // Handle object with content property
          if (typeof element.content === 'string') {
            const words = element.content.trim().split(/\s+/).filter(word => word.length > 0);
            return total + words.length;
          }
        } else if (typeof element === 'string') {
          // Handle string elements
          const words = element.trim().split(/\s+/).filter(word => word.length > 0);
          return total + words.length;
        }
        return total;
      }, 0);
    }
    
    // Handle object format
    if (typeof content === 'object') {
      let totalWords = 0;
      Object.values(content).forEach(value => {
        if (typeof value === 'string') {
          totalWords += value.trim().split(/\s+/).filter(word => word.length > 0).length;
        }
      });
      return totalWords;
    }
    
    return 0;
  };

  const calculateSceneCount = (content: any): number => {
    if (!content) return 0;
    
    if (Array.isArray(content)) {
      return content.filter(element => {
        if (element && typeof element === 'object') {
          // Check for scene heading type
          if (element.type === 'scene-heading' && element.content && element.content.trim()) {
            // Don't count FADE transitions as scenes
            return !element.content.toUpperCase().includes('FADE');
          }
        } else if (typeof element === 'string') {
          // Handle string format - look for scene heading patterns
          const trimmed = element.trim().toUpperCase();
          return (trimmed.startsWith('INT.') || trimmed.startsWith('EXT.')) && 
                 !trimmed.includes('FADE');
        }
        return false;
      }).length;
    }
    
    return 0;
  };

  const calculatePageCount = (content: any): number => {
    const wordCount = calculateWordCount(content);
    if (wordCount === 0) return 1;
    
    // Industry standard: 250 words per page for screenplay
    // But also consider scene count - typically 1-3 scenes per page
    const sceneCount = calculateSceneCount(content);
    const wordBasedPages = Math.ceil(wordCount / 250);
    const sceneBasedPages = Math.ceil(sceneCount / 2); // Rough estimate
    
    // Use the higher of the two estimates, but at least 1 page
    return Math.max(1, Math.max(wordBasedPages, sceneBasedPages));
  };

  const fetchScripts = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setScripts([]);
        return;
      }

      const { data, error } = await supabase
        .from('scripts')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      // Transform database scripts to match our Script type
      const transformedScripts: Script[] = (data || []).map(script => {
        // Ensure template is one of the allowed values
        let template: 'feature-film' | 'tv-episode' | 'short-film' = 'feature-film';
        if (script.genre === 'tv-episode' || script.genre === 'short-film') {
          template = script.genre as 'tv-episode' | 'short-film';
        }

        const wordCount = calculateWordCount(script.content);
        const sceneCount = calculateSceneCount(script.content);
        const pageCount = calculatePageCount(script.content);

        return {
          id: script.id,
          title: script.title,
          description: script.description || '',
          template,
          createdAt: new Date(script.created_at),
          lastModified: new Date(script.updated_at),
          wordCount,
          pageCount,
          sceneCount, // Add scene count to the script object
          isStarred: false // We'll add this field to database later if needed
        };
      });

      setScripts(transformedScripts);
    } catch (err) {
      console.error('Error fetching scripts:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch scripts');
    } finally {
      setLoading(false);
    }
  };

  const createScript = async (title: string, description: string, template: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('scripts')
        .insert({
          title,
          description,
          genre: template,
          user_id: user.id,
          content: []
        })
        .select()
        .single();

      if (error) throw error;

      await fetchScripts(); // Refresh the list
      return data.id;
    } catch (err) {
      console.error('Error creating script:', err);
      throw err;
    }
  };

  const updateScript = async (scriptId: string, updates: Partial<{
    title: string;
    description: string;
    content: any;
  }>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('scripts')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', scriptId)
        .eq('user_id', user.id);

      if (error) throw error;

      await fetchScripts(); // Refresh the list
    } catch (err) {
      console.error('Error updating script:', err);
      throw err;
    }
  };

  const deleteScript = async (scriptId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('scripts')
        .delete()
        .eq('id', scriptId)
        .eq('user_id', user.id);

      if (error) throw error;

      await fetchScripts(); // Refresh the list
    } catch (err) {
      console.error('Error deleting script:', err);
      throw err;
    }
  };

  const duplicateScript = async (scriptId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // First get the original script
      const { data: originalScript, error: fetchError } = await supabase
        .from('scripts')
        .select('*')
        .eq('id', scriptId)
        .eq('user_id', user.id)
        .single();

      if (fetchError) throw fetchError;

      // Create duplicate
      const { data, error } = await supabase
        .from('scripts')
        .insert({
          title: `${originalScript.title} (Copy)`,
          description: originalScript.description,
          genre: originalScript.genre,
          content: originalScript.content,
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;

      await fetchScripts(); // Refresh the list
      return data.id;
    } catch (err) {
      console.error('Error duplicating script:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchScripts();
  }, []);

  return {
    scripts,
    loading,
    error,
    fetchScripts,
    createScript,
    updateScript,
    deleteScript,
    duplicateScript
  };
};
