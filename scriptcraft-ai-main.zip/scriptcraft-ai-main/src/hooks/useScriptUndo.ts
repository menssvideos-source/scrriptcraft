
import { useState, useCallback } from 'react';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

interface UndoState {
  elements: ScriptElement[];
  timestamp: number;
  action: string;
}

export const useScriptUndo = (initialElements: ScriptElement[]) => {
  const [undoStack, setUndoStack] = useState<UndoState[]>([]);
  const [redoStack, setRedoStack] = useState<UndoState[]>([]);
  const [currentElements, setCurrentElements] = useState<ScriptElement[]>(initialElements);

  const saveState = useCallback((elements: ScriptElement[], action: string) => {
    const newState: UndoState = {
      elements: [...currentElements],
      timestamp: Date.now(),
      action
    };
    
    setUndoStack(prev => [...prev, newState].slice(-50)); // Keep last 50 states
    setRedoStack([]); // Clear redo stack when new action is performed
    setCurrentElements(elements);
  }, [currentElements]);

  const undo = useCallback(() => {
    if (undoStack.length === 0) return null;
    
    const lastState = undoStack[undoStack.length - 1];
    const newRedoState: UndoState = {
      elements: [...currentElements],
      timestamp: Date.now(),
      action: 'redo'
    };
    
    setRedoStack(prev => [...prev, newRedoState]);
    setUndoStack(prev => prev.slice(0, -1));
    setCurrentElements(lastState.elements);
    
    return lastState.elements;
  }, [undoStack, currentElements]);

  const redo = useCallback(() => {
    if (redoStack.length === 0) return null;
    
    const nextState = redoStack[redoStack.length - 1];
    const newUndoState: UndoState = {
      elements: [...currentElements],
      timestamp: Date.now(),
      action: 'undo'
    };
    
    setUndoStack(prev => [...prev, newUndoState]);
    setRedoStack(prev => prev.slice(0, -1));
    setCurrentElements(nextState.elements);
    
    return nextState.elements;
  }, [redoStack, currentElements]);

  const canUndo = undoStack.length > 0;
  const canRedo = redoStack.length > 0;

  return {
    saveState,
    undo,
    redo,
    canUndo,
    canRedo,
    currentElements,
    setCurrentElements
  };
};
