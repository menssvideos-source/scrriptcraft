
import * as React from "react"

const MOBILE_BREAKPOINT = 768
const TABLET_BREAKPOINT = 1024

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const checkMobile = () => {
      // Use both window.innerWidth and screen.width to handle zoom better
      const effectiveWidth = Math.min(window.innerWidth, window.screen.width)
      setIsMobile(effectiveWidth < MOBILE_BREAKPOINT)
    }

    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    mql.addEventListener("change", checkMobile)
    
    // Initial check
    checkMobile()
    
    // Also listen to resize events for zoom changes
    window.addEventListener("resize", checkMobile)
    
    return () => {
      mql.removeEventListener("change", checkMobile)
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  return !!isMobile
}

export function useIsTablet() {
  const [isTablet, setIsTablet] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const checkTablet = () => {
      const effectiveWidth = Math.min(window.innerWidth, window.screen.width)
      setIsTablet(effectiveWidth >= MOBILE_BREAKPOINT && effectiveWidth < TABLET_BREAKPOINT)
    }

    const mql = window.matchMedia(`(min-width: ${MOBILE_BREAKPOINT}px) and (max-width: ${TABLET_BREAKPOINT - 1}px)`)
    mql.addEventListener("change", checkTablet)
    
    checkTablet()
    window.addEventListener("resize", checkTablet)
    
    return () => {
      mql.removeEventListener("change", checkTablet)
      window.removeEventListener("resize", checkTablet)
    }
  }, [])

  return !!isTablet
}
