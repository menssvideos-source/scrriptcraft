
import { useState, useCallback } from 'react';
import { Character } from '../types/project';

export const useCharacterOperations = () => {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);

  const generateUniqueId = () => {
    return crypto.randomUUID();
  };

  const addCharacter = useCallback(() => {
    const newCharacter: Character = {
      id: generateUniqueId(),
      name: '',
      role: 'supporting',
      description: '',
      physicalDescription: '',
      age: undefined,
      gender: '',
      relationships: []
    };
    setCharacters(prev => [...prev, newCharacter]);
    setSelectedCharacter(newCharacter.id);
  }, []);

  const updateCharacter = useCallback((characterId: string, updates: Partial<Character>) => {
    setCharacters(prev => prev.map(char => 
      char.id === characterId ? { ...char, ...updates } : char
    ));
  }, []);

  const deleteCharacter = useCallback((characterId: string) => {
    setCharacters(prev => {
      if (prev.length <= 1) return prev;
      
      const newCharacters = prev.filter(char => char.id !== characterId);
      
      if (selectedCharacter === characterId) {
        setSelectedCharacter(newCharacters[0]?.id || null);
      }
      
      return newCharacters;
    });
  }, [selectedCharacter]);

  const replaceAllCharacters = useCallback((newCharacters: Character[]) => {
    // Single state update with proper UUIDs assigned
    const charactersWithIds = newCharacters.map(char => ({
      ...char,
      id: generateUniqueId()
    }));
    
    // Update both characters and selection in sequence to prevent flickering
    setCharacters(charactersWithIds);
    
    // Select first character if available
    if (charactersWithIds.length > 0) {
      setSelectedCharacter(charactersWithIds[0].id);
    } else {
      setSelectedCharacter(null);
    }
  }, []);

  const saveCharacters = useCallback((projectId: string) => {
    if (projectId) {
      localStorage.setItem(`project-${projectId}-characters`, JSON.stringify(characters));
    }
  }, [characters]);

  const loadCharacters = useCallback((projectId: string) => {
    const savedCharacters = localStorage.getItem(`project-${projectId}-characters`);
    if (savedCharacters) {
      const characterData = JSON.parse(savedCharacters);
      setCharacters(characterData);
      if (characterData.length > 0) {
        setSelectedCharacter(characterData[0].id);
      }
    } else {
      // Create default protagonist with proper UUID
      const defaultCharacter: Character = {
        id: generateUniqueId(),
        name: '',
        role: 'protagonist',
        description: '',
        physicalDescription: '',
        age: undefined,
        gender: '',
        relationships: []
      };
      setCharacters([defaultCharacter]);
      setSelectedCharacter(defaultCharacter.id);
    }
  }, []);

  return {
    characters,
    setCharacters,
    selectedCharacter,
    setSelectedCharacter,
    addCharacter,
    updateCharacter,
    deleteCharacter,
    replaceAllCharacters,
    saveCharacters,
    loadCharacters
  };
};
