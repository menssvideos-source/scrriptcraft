
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { StoryboardFrame, StoryboardGenerator } from '../lib/storyboard';
import { ImageModel } from '../contexts/APIKeyContext';
import { toast } from '../components/ui/sonner';

export const useImageGeneration = (
  imageApiKey: string, 
  imageModel: ImageModel,
  updateStoryboardFrames: (frames: StoryboardFrame[]) => void
) => {
  const { id } = useParams();
  const [generatingImages, setGeneratingImages] = useState(false);

  const generateStoryboardImages = async (storyboardFrames: StoryboardFrame[]) => {
    console.log('Generate images called with:', {
      apiKey: imageApiKey ? 'Present' : 'Missing',
      framesCount: storyboardFrames.length,
      scriptId: id,
      imageModel: imageModel.name
    });

    if (!imageApiKey.trim()) {
      const errorMsg = 'Please configure your API key for image generation first';
      console.error(errorMsg);
      toast.error(errorMsg);
      return;
    }

    if (storyboardFrames.length === 0) {
      const errorMsg = 'Please generate storyboard frames first';
      console.error(errorMsg);
      toast.error(errorMsg);
      return;
    }

    if (!id) {
      const errorMsg = 'No script ID found';
      console.error(errorMsg);
      toast.error(errorMsg);
      return;
    }

    setGeneratingImages(true);
    
    try {
      console.log(`Starting image generation for ${storyboardFrames.length} frames using ${imageModel.name}`);
      toast.info(`Starting image generation for ${storyboardFrames.length} frames using ${imageModel.name}...`);
      
      const generator = new StoryboardGenerator(imageApiKey, imageModel);
      
      // Track progress with individual frame updates
      let completedFrames = 0;
      const framesWithImages = await generator.generateImagesForFrames(
        storyboardFrames,
        id,
        (progressFrames) => {
          console.log('Image generation progress update:', progressFrames.length);
          updateStoryboardFrames(progressFrames);
          
          // Count completed frames for progress tracking
          const newCompletedFrames = progressFrames.filter(f => f.imageUrl && !f.isGeneratingImage).length;
          if (newCompletedFrames > completedFrames) {
            completedFrames = newCompletedFrames;
            toast.info(`Generated ${completedFrames}/${storyboardFrames.length} images using ${imageModel.name}...`);
          }
        }
      );
      
      console.log(`Image generation completed with ${imageModel.name} and permanent storage`);
      toast.success(`Successfully generated ${completedFrames} images using ${imageModel.name}!`);
      updateStoryboardFrames(framesWithImages);
      
    } catch (error) {
      console.error('Image generation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast.error(`Image generation failed: ${errorMessage}`);
    } finally {
      setGeneratingImages(false);
    }
  };

  return {
    generatingImages,
    generateStoryboardImages
  };
};
