
import { useState, useMemo } from 'react';
import { ScriptElement } from '../types/script';

/**
 * Simplified UI state management hook
 * Removed complex state management that was causing React Error #310
 */
export const useScriptUI = (elements: ScriptElement[]) => {
  const [activeElement, setActiveElement] = useState<string>('');

  // Simple computed values
  const hasMultipleScenes = useMemo(() => {
    const sceneHeadings = elements.filter(el => el.type === 'scene-heading');
    return sceneHeadings.length > 1;
  }, [elements]);

  return {
    activeElement,
    setActiveElement,
    hasMultipleScenes
  };
};
