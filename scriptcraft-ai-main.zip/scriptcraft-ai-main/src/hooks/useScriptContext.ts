
import { useMemo } from 'react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

interface ScriptContext {
  // Project foundation
  brainstorm: ProjectBrainstorm | null;
  structure: ProjectStructure | null;
  characters: Character[];
  
  // Script state
  elements: ScriptElement[];
  currentAct: 1 | 2 | 3;
  currentSceneIndex: number;
  totalScenes: number;
  
  // Context-aware helpers
  getCharacterByName: (name: string) => Character | undefined;
  getCurrentActInfo: () => { act: number; description: string; progress: number };
  getStoryContext: () => string;
  getCharacterContext: () => string;
}

export const useScriptContext = (
  brainstorm: ProjectBrainstorm | null,
  structure: ProjectStructure | null,
  characters: Character[],
  elements: ScriptElement[]
): ScriptContext => {
  
  const scenes = useMemo(() => {
    return elements.filter(el => 
      el.type === 'scene-heading' && 
      el.content.trim() && 
      !el.content.includes('FADE')
    );
  }, [elements]);

  const currentSceneIndex = useMemo(() => {
    // Find the last scene heading before or at current position
    for (let i = elements.length - 1; i >= 0; i--) {
      if (elements[i].type === 'scene-heading' && 
          elements[i].content.trim() && 
          !elements[i].content.includes('FADE')) {
        return scenes.findIndex(scene => scene.id === elements[i].id);
      }
    }
    return 0;
  }, [elements, scenes]);

  const currentAct = useMemo((): 1 | 2 | 3 => {
    const totalScenes = scenes.length;
    if (totalScenes === 0) return 1;
    
    // Rough act breakdown: Act 1 (25%), Act 2 (50%), Act 3 (25%)
    if (currentSceneIndex < totalScenes * 0.25) return 1;
    if (currentSceneIndex < totalScenes * 0.75) return 2;
    return 3;
  }, [currentSceneIndex, scenes.length]);

  const getCharacterByName = (name: string): Character | undefined => {
    return characters.find(char => 
      char.name.toLowerCase() === name.toLowerCase()
    );
  };

  const getCurrentActInfo = () => {
    const totalScenes = scenes.length;
    let description = '';
    let progress = 0;

    switch (currentAct) {
      case 1:
        description = structure?.act1?.setup || 'Setup and character introduction';
        progress = totalScenes > 0 ? (currentSceneIndex / (totalScenes * 0.25)) * 100 : 0;
        break;
      case 2:
        description = structure?.act2?.confrontation || 'Confrontation and rising action';
        progress = totalScenes > 0 ? ((currentSceneIndex - totalScenes * 0.25) / (totalScenes * 0.5)) * 100 : 0;
        break;
      case 3:
        description = structure?.act3?.climax || 'Climax and resolution';
        progress = totalScenes > 0 ? ((currentSceneIndex - totalScenes * 0.75) / (totalScenes * 0.25)) * 100 : 0;
        break;
    }

    return { act: currentAct, description, progress: Math.max(0, Math.min(100, progress)) };
  };

  const getStoryContext = (): string => {
    let context = '';
    
    if (brainstorm) {
      context += `Story: ${brainstorm.idea}\n`;
      context += `Genre: ${brainstorm.genre}\n`;
      context += `Theme: ${brainstorm.theme}\n`;
      context += `Setting: ${brainstorm.setting}\n`;
    }

    if (structure) {
      const actInfo = getCurrentActInfo();
      context += `\nCurrent Act: ${actInfo.act} - ${actInfo.description}\n`;
      
      if (currentAct === 1 && structure.act1) {
        context += `Act 1 Goals: Setup: ${structure.act1.setup}\n`;
        context += `Inciting Incident: ${structure.act1.incitingIncident}\n`;
      } else if (currentAct === 2 && structure.act2) {
        context += `Act 2 Goals: Confrontation: ${structure.act2.confrontation}\n`;
        context += `Midpoint: ${structure.act2.midpoint}\n`;
      } else if (currentAct === 3 && structure.act3) {
        context += `Act 3 Goals: Climax: ${structure.act3.climax}\n`;
        context += `Resolution: ${structure.act3.resolution}\n`;
      }
    }

    return context;
  };

  const getCharacterContext = (): string => {
    if (characters.length === 0) return '';
    
    let context = '\nCharacters:\n';
    characters.forEach(char => {
      context += `${char.name} (${char.role}): ${char.description}\n`;
      if (char.motivation) context += `  Motivation: ${char.motivation}\n`;
      if (char.arc) context += `  Arc: ${char.arc}\n`;
    });
    
    return context;
  };

  return {
    brainstorm,
    structure,
    characters,
    elements,
    currentAct,
    currentSceneIndex,
    totalScenes: scenes.length,
    getCharacterByName,
    getCurrentActInfo,
    getStoryContext,
    getCharacterContext
  };
};
