
import { useState } from 'react';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export const useScriptOperations = () => {
  const [activeElement, setActiveElement] = useState<string>('');
  const [showProjectInfo, setShowProjectInfo] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedSceneType, setSelectedSceneType] = useState<string>('');
  const [showSceneGenerator, setShowSceneGenerator] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const addNewElement = (elements: ScriptElement[], setElements: (elements: ScriptElement[]) => void) => {
    const newElement: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'action',
      content: ''
    };
    const newElements = [...elements, newElement];
    setElements(newElements);
    setActiveElement(newElement.id);
  };

  const insertCharacterName = (characterName: string, elements: ScriptElement[], setElements: (elements: ScriptElement[]) => void) => {
    const newElement: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'character',
      content: characterName.toUpperCase()
    };
    const newElements = [...elements, newElement];
    setElements(newElements);
    setActiveElement(newElement.id);
  };

  return {
    activeElement,
    setActiveElement,
    showProjectInfo,
    setShowProjectInfo,
    isGenerating,
    setIsGenerating,
    selectedSceneType,
    setSelectedSceneType,
    showSceneGenerator,
    setShowSceneGenerator,
    isLoading,
    setIsLoading,
    addNewElement,
    insertCharacterName
  };
};
