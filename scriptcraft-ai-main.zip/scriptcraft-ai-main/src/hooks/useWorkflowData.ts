
import { useState, useEffect, useCallback, useRef } from 'react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { supabase } from '../integrations/supabase/client';

export const useWorkflowData = (id: string | undefined) => {
  const [brainstorm, setBrainstormState] = useState<ProjectBrainstorm | null>(null);
  const [structure, setStructureState] = useState<ProjectStructure | null>(null);
  const [characters, setCharactersState] = useState<Character[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [authReady, setAuthReady] = useState(false);

  // FIXED: Use useRef for stable timer reference that prevents stale closures
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const authSubscriptionRef = useRef<any>(null);

  // FIXED: Stable debounced save function that manages its own cleanup
  const debouncedSave = useCallback((
    updatedBrainstorm?: ProjectBrainstorm | null,
    updatedStructure?: ProjectStructure | null,
    updatedCharacters?: Character[]
  ) => {
    // Clear existing timer synchronously
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }
    
    // Set new timer with stable reference
    debounceTimerRef.current = setTimeout(() => {
      saveWorkflowData(updatedBrainstorm, updatedStructure, updatedCharacters);
      debounceTimerRef.current = null; // Clear reference after execution
    }, 2000);
  }, []); // FIXED: Empty dependencies to prevent recreation

  // Manual save function with stable reference
  const saveWorkflowData = useCallback(async (
    updatedBrainstorm?: ProjectBrainstorm | null,
    updatedStructure?: ProjectStructure | null,
    updatedCharacters?: Character[]
  ) => {
    if (!id) {
      console.warn('useWorkflowData: Cannot save - no project ID provided');
      return false;
    }

    setSaving(true);
    try {
      // Enhanced authentication check with retry
      let user = null;
      let retryCount = 0;
      const maxRetries = 3;

      while (!user && retryCount < maxRetries) {
        console.log(`useWorkflowData: Authentication attempt ${retryCount + 1}/${maxRetries}`);
        const { data, error } = await supabase.auth.getUser();
        
        if (error) {
          console.error('useWorkflowData: Auth error:', error);
          if (retryCount < maxRetries - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            retryCount++;
            continue;
          }
          throw new Error(`Authentication failed after ${maxRetries} attempts: ${error.message}`);
        }
        
        user = data.user;
        if (!user) {
          console.warn('useWorkflowData: No user found, retrying...');
          if (retryCount < maxRetries - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            retryCount++;
            continue;
          }
        }
        break;
      }

      if (!user) {
        console.error('useWorkflowData: No authenticated user after retries');
        return false;
      }

      console.log('useWorkflowData: Starting manual save operation for project:', id, 'User:', user.id);

      // Get current script content
      const { data: script, error: fetchError } = await supabase
        .from('scripts')
        .select('content')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();

      if (fetchError) {
        console.error('useWorkflowData: Failed to fetch script:', fetchError);
        throw fetchError;
      }

      // Enhanced content handling - handle both empty arrays and null/undefined
      let currentContent: Record<string, any> = {};
      
      if (script?.content) {
        if (Array.isArray(script.content)) {
          // If content is an array (old format), convert to object
          console.log('useWorkflowData: Converting array content to object format');
          currentContent = {};
        } else if (typeof script.content === 'object') {
          currentContent = script.content as Record<string, any>;
        }
      }
        
      const workflowData = {
        ...currentContent,
        brainstorm: updatedBrainstorm !== undefined ? updatedBrainstorm : brainstorm,
        structure: updatedStructure !== undefined ? updatedStructure : structure,
        characters: updatedCharacters !== undefined ? updatedCharacters : characters
      };

      console.log('useWorkflowData: Saving workflow data:', {
        projectId: id,
        userId: user.id,
        hasBrainstorm: !!workflowData.brainstorm,
        hasStructure: !!workflowData.structure,
        charactersCount: workflowData.characters?.length || 0,
        brainstormFields: workflowData.brainstorm ? Object.keys(workflowData.brainstorm) : [],
        contentType: typeof script?.content,
        isContentArray: Array.isArray(script?.content)
      });

      const { error } = await supabase
        .from('scripts')
        .update({ 
          content: workflowData as any, // Cast to any to satisfy Json type
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('useWorkflowData: Save failed with error:', error);
        throw error;
      }

      console.log('useWorkflowData: Workflow data saved to Supabase successfully');
      setLastSaved(new Date());
      return true;
    } catch (error) {
      console.error('useWorkflowData: Failed to save workflow data:', error);
      return false;
    } finally {
      setSaving(false);
    }
  }, [id, brainstorm, structure, characters]);

  // FIXED: Enhanced authentication state monitoring with proper cleanup
  useEffect(() => {
    console.log('useWorkflowData: Setting up auth state monitoring');
    
    const handleAuthChange = (event: string, session: any) => {
      console.log('useWorkflowData: Auth state changed:', event, !!session?.user);
      setAuthReady(!!session?.user);
    };
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange(handleAuthChange);
    authSubscriptionRef.current = subscription;

    // Check initial auth state
    supabase.auth.getUser().then(({ data: { user }, error }) => {
      console.log('useWorkflowData: Initial auth check:', !!user, error?.message);
      setAuthReady(!!user);
    });

    // FIXED: Return synchronous cleanup function that doesn't capture stale state
    return () => {
      console.log('useWorkflowData: Cleaning up auth subscription');
      if (authSubscriptionRef.current) {
        authSubscriptionRef.current.unsubscribe();
        authSubscriptionRef.current = null;
      }
    };
  }, []); // FIXED: Empty dependencies for one-time setup

  // FIXED: Load data on mount - wait for auth to be ready with stable dependencies
  useEffect(() => {
    if (id && authReady) {
      const fetchWorkflowData = async () => {
        setLoading(true);
        try {
          console.log('useWorkflowData: Loading workflow data for project:', id);
          
          const { data: { user }, error: authError } = await supabase.auth.getUser();
          if (authError || !user) {
            console.error('useWorkflowData: Cannot load - auth error:', authError?.message);
            setLoading(false);
            return;
          }

          const { data: script, error } = await supabase
            .from('scripts')
            .select('content')
            .eq('id', id)
            .eq('user_id', user.id)
            .single();

          if (error) {
            console.error('useWorkflowData: Failed to load script:', error);
            setLoading(false);
            return;
          }

          // Enhanced content processing - handle arrays and null/undefined
          let content: Record<string, any> = {};
          
          if (script?.content) {
            if (Array.isArray(script.content)) {
              console.log('useWorkflowData: Found array content, treating as empty workflow data');
              content = {}; // Convert array to empty object
            } else if (typeof script.content === 'object') {
              content = script.content as Record<string, any>;
            }
          }
          
          console.log('useWorkflowData: Loaded content from Supabase:', {
            hasBrainstorm: !!content.brainstorm,
            hasStructure: !!content.structure,
            charactersCount: content.characters?.length || 0,
            brainstormFields: content.brainstorm ? Object.keys(content.brainstorm) : [],
            rawBrainstorm: content.brainstorm,
            contentType: typeof script?.content,
            isContentArray: Array.isArray(script?.content)
          });
          
          setBrainstormState(content.brainstorm || null);
          setStructureState(content.structure || null);
          setCharactersState(content.characters || []);
        } catch (error) {
          console.error('useWorkflowData: Failed to load workflow data:', error);
        } finally {
          setLoading(false);
        }
      };

      fetchWorkflowData();
    } else if (id && !authReady) {
      console.log('useWorkflowData: Waiting for authentication to be ready...');
    }
  }, [id, authReady]); // FIXED: Only primitive dependencies

  // FIXED: Setter functions that update state and trigger auto-save with stable references
  const setBrainstorm = useCallback((data: ProjectBrainstorm | null) => {
    console.log('useWorkflowData: Setting brainstorm data:', data);
    setBrainstormState(data);
    debouncedSave(data, undefined, undefined);
  }, [debouncedSave]);

  const setStructure = useCallback((data: ProjectStructure | null) => {
    console.log('useWorkflowData: Setting structure data:', data);
    setStructureState(data);
    debouncedSave(undefined, data, undefined);
  }, [debouncedSave]);

  const setCharacters = useCallback((data: Character[]) => {
    console.log('useWorkflowData: Setting characters data:', data);
    setCharactersState(data);
    debouncedSave(undefined, undefined, data);
  }, [debouncedSave]);

  // FIXED: Manual save function for immediate saves with stable reference
  const saveNow = useCallback(async () => {
    return await saveWorkflowData();
  }, [saveWorkflowData]);

  // FIXED: Component cleanup - ensure timer is cleared on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
        debounceTimerRef.current = null;
      }
    };
  }, []);

  return {
    brainstorm,
    setBrainstorm,
    structure,
    setStructure,
    characters,
    setCharacters,
    loading: loading || !authReady, // Show loading until auth is ready
    saving,
    lastSaved,
    saveNow
  };
};
