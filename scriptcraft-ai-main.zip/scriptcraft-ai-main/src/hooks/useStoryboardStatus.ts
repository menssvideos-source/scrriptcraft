
import { useState, useEffect } from 'react';
import { supabase } from '../integrations/supabase/client';

export interface StoryboardStatus {
  hasStoryboard: boolean;
  storyboardStatus: 'none' | 'generating' | 'partial' | 'complete';
  imageCount: number;
}

export const useStoryboardStatus = (scriptId: string) => {
  const [status, setStatus] = useState<StoryboardStatus>({
    hasStoryboard: false,
    storyboardStatus: 'none',
    imageCount: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkStoryboardStatus = async () => {
      if (!scriptId) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('storyboard_images')
          .select('id, frame_id')
          .eq('script_id', scriptId);

        if (error) {
          console.error('Error checking storyboard status:', error);
          setStatus({
            hasStoryboard: false,
            storyboardStatus: 'none',
            imageCount: 0
          });
          return;
        }

        const imageCount = data?.length || 0;
        let storyboardStatus: 'none' | 'generating' | 'partial' | 'complete' = 'none';

        if (imageCount === 0) {
          storyboardStatus = 'none';
        } else if (imageCount < 5) {
          storyboardStatus = 'partial';
        } else {
          storyboardStatus = 'complete';
        }

        setStatus({
          hasStoryboard: imageCount > 0,
          storyboardStatus,
          imageCount
        });
      } catch (error) {
        console.error('Error in storyboard status check:', error);
        setStatus({
          hasStoryboard: false,
          storyboardStatus: 'none',
          imageCount: 0
        });
      } finally {
        setLoading(false);
      }
    };

    checkStoryboardStatus();
  }, [scriptId]);

  return { status, loading };
};

export const useMultipleStoryboardStatus = (scriptIds: string[]) => {
  const [statusMap, setStatusMap] = useState<Record<string, StoryboardStatus>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkMultipleStatus = async () => {
      if (scriptIds.length === 0) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('storyboard_images')
          .select('script_id, id')
          .in('script_id', scriptIds);

        if (error) {
          console.error('Error checking multiple storyboard status:', error);
          return;
        }

        const newStatusMap: Record<string, StoryboardStatus> = {};

        scriptIds.forEach(scriptId => {
          const images = data?.filter(img => img.script_id === scriptId) || [];
          const imageCount = images.length;
          
          let storyboardStatus: 'none' | 'generating' | 'partial' | 'complete' = 'none';
          if (imageCount === 0) {
            storyboardStatus = 'none';
          } else if (imageCount < 5) {
            storyboardStatus = 'partial';
          } else {
            storyboardStatus = 'complete';
          }

          newStatusMap[scriptId] = {
            hasStoryboard: imageCount > 0,
            storyboardStatus,
            imageCount
          };
        });

        setStatusMap(newStatusMap);
      } catch (error) {
        console.error('Error in multiple storyboard status check:', error);
      } finally {
        setLoading(false);
      }
    };

    checkMultipleStatus();
  }, [scriptIds]);

  return { statusMap, loading };
};
