
import { useState, useEffect } from 'react';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { supabase } from '../integrations/supabase/client';

export const useStructurePlanning = (projectId?: string) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [brainstorm, setBrainstorm] = useState<ProjectBrainstorm | null>(null);
  const [structure, setStructure] = useState<ProjectStructure>({
    act1: { setup: '', incitingIncident: '', plotPoint1: '' },
    act2: { confrontation: '', midpoint: '', plotPoint2: '' },
    act3: { climax: '', resolution: '' }
  });
  const [characters, setCharacters] = useState<Character[]>([]);

  // Load project data when projectId changes
  useEffect(() => {
    if (projectId) {
      loadProjectData();
    }
  }, [projectId]);

  const loadProjectData = async () => {
    if (!projectId) return;
    
    setLoading(true);
    try {
      const { data: script } = await supabase
        .from('scripts')
        .select('*')
        .eq('id', projectId)
        .maybeSingle();

      if (script?.content) {
        const content = script.content;
        if (content && typeof content === 'object' && !Array.isArray(content)) {
          const contentObj = content as Record<string, any>;
          if (contentObj.brainstorm) {
            setBrainstorm(contentObj.brainstorm);
            console.log('Loaded brainstorm data:', contentObj.brainstorm);
          }
          if (contentObj.structure) {
            setStructure(contentObj.structure);
            console.log('Loaded structure data:', contentObj.structure);
          }
          if (contentObj.characters) {
            setCharacters(contentObj.characters);
            console.log('Loaded characters data:', contentObj.characters);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load project data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getApiKey = () => {
    return localStorage.getItem('openai-api-key') || '';
  };

  const extractCharacterNames = (text: string): string[] => {
    if (!text) return [];
    
    const namePatterns = [
      /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g,
      /\b([A-Z]{2,})\b/g,
    ];
    
    const names = new Set<string>();
    namePatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          const commonWords = ['THE', 'AND', 'OR', 'BUT', 'IF', 'WHEN', 'WHERE', 'ACT', 'SCENE', 'INT', 'EXT', 'FADE', 'CUT'];
          if (!commonWords.includes(match.toUpperCase()) && match.length > 2) {
            names.add(match);
          }
        });
      }
    });
    
    return Array.from(names).slice(0, 10);
  };

  const callOpenAI = async (prompt: string, systemMessage?: string) => {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: systemMessage || 'You are a professional screenplay structure consultant. Create detailed story elements that build on existing brainstorm concepts and maintain character consistency. Always reference established characters by name and expand on the established story concept.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 400,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  };

  const buildFieldPrompt = (
    fieldKey: string,
    brainstormData: ProjectBrainstorm | null,
    charactersData: Character[]
  ): string => {
    let context = '';
    
    // Build context from previous pages
    if (brainstormData) {
      context += `STORY FOUNDATION FROM BRAINSTORM:\n`;
      if (brainstormData.idea) context += `Core Idea: ${brainstormData.idea}\n`;
      if (brainstormData.premise) context += `Premise: ${brainstormData.premise}\n`;
      if (brainstormData.logline) context += `Logline: ${brainstormData.logline}\n`;
      if (brainstormData.genre) context += `Genre: ${brainstormData.genre}\n`;
      if (brainstormData.theme) context += `Theme: ${brainstormData.theme}\n`;
      if (brainstormData.setting) context += `Setting: ${brainstormData.setting}\n`;
      if (brainstormData.tone) context += `Tone: ${brainstormData.tone}\n`;
      if (brainstormData.targetAudience) context += `Target Audience: ${brainstormData.targetAudience}\n`;
    }

    if (charactersData && charactersData.length > 0) {
      context += `\nCHARACTERS FROM CHARACTER DEVELOPMENT:\n`;
      charactersData.forEach(char => {
        context += `${char.name} (${char.role}): ${char.description}\n`;
        if (char.motivation) context += `  Motivation: ${char.motivation}\n`;
        if (char.arc) context += `  Character Arc: ${char.arc}\n`;
      });
    }

    let mainCharacterName = 'the protagonist';
    if (charactersData && charactersData.length > 0) {
      const protagonist = charactersData.find(c => c.role === 'protagonist') || charactersData[0];
      mainCharacterName = protagonist.name;
    } else if (brainstormData?.idea) {
      const extractedNames = extractCharacterNames(brainstormData.idea);
      if (extractedNames.length > 0) {
        mainCharacterName = extractedNames[0];
      }
    }

    context += `\nBased on the above story foundation and character development, generate a detailed ${getFieldDisplayName(fieldKey)} that:\n`;
    context += `- Builds directly on the established story concept and premise\n`;
    context += `- References ${mainCharacterName} and other established characters by name\n`;
    context += `- Maintains consistency with the ${brainstormData?.genre || 'established genre'} and ${brainstormData?.tone || 'established tone'}\n`;
    context += `- Expands on the ${brainstormData?.theme || 'established themes'}\n\n`;

    // Field-specific instructions
    switch (fieldKey) {
      case 'setup':
        context += `For the SETUP: Show ${mainCharacterName} in their ordinary world before the story begins. Establish their current life, relationships, goals, and what they care about. This should set up what will be disrupted by the inciting incident.`;
        break;
      case 'incitingIncident':
        context += `For the INCITING INCIDENT: Create the specific event that disrupts ${mainCharacterName}'s normal world and sets the main story in motion. This should directly relate to the core conflict established in the premise.`;
        break;
      case 'plotPoint1':
        context += `For PLOT POINT 1: Show ${mainCharacterName} making the decision to pursue their goal and enter the new world of Act II. This is the point of no return that commits them to the story's central conflict.`;
        break;
      case 'confrontation':
        context += `For the CONFRONTATION: Detail the escalating obstacles ${mainCharacterName} faces while pursuing their goal. Each challenge should build toward the midpoint and test their resolve.`;
        break;
      case 'midpoint':
        context += `For the MIDPOINT: Create a major twist or revelation that changes everything for ${mainCharacterName}. This should raise the stakes significantly and shift the story's direction.`;
        break;
      case 'plotPoint2':
        context += `For PLOT POINT 2: Show the darkest moment where ${mainCharacterName} faces their greatest fear or lowest point. All seems lost before the final act begins.`;
        break;
      case 'climax':
        context += `For the CLIMAX: Create the final confrontation where ${mainCharacterName} faces their biggest challenge using everything they've learned throughout their journey.`;
        break;
      case 'resolution':
        context += `For the RESOLUTION: Show the new normal. How has ${mainCharacterName} changed? What is their world like now that the central conflict is resolved?`;
        break;
    }

    context += `\n\nWrite 2-3 detailed sentences that could serve as a guide for writing this part of the screenplay.`;

    return context;
  };

  const getFieldDisplayName = (fieldKey: string): string => {
    const fieldNames: Record<string, string> = {
      'setup': 'Setup',
      'incitingIncident': 'Inciting Incident', 
      'plotPoint1': 'Plot Point 1',
      'confrontation': 'Confrontation',
      'midpoint': 'Midpoint',
      'plotPoint2': 'Plot Point 2',
      'climax': 'Climax',
      'resolution': 'Resolution'
    };
    return fieldNames[fieldKey] || fieldKey;
  };

  const buildContextualPrompt = (
    structureType: string,
    brainstormData: ProjectBrainstorm | null,
    charactersData: Character[]
  ): string => {
    let prompt = '';
    
    // Ensure we have the most current data
    console.log('Building contextual prompt with:', {
      hasBrainstorm: !!brainstormData,
      brainstormKeys: brainstormData ? Object.keys(brainstormData) : [],
      charactersCount: charactersData?.length || 0,
      characterNames: charactersData?.map(c => c.name) || []
    });
    
    if (brainstormData) {
      if (brainstormData.idea) prompt += `Story Concept: ${brainstormData.idea}\n`;
      if (brainstormData.premise) prompt += `Premise: ${brainstormData.premise}\n`;
      if (brainstormData.logline) prompt += `Logline: ${brainstormData.logline}\n`;
      if (brainstormData.genre) prompt += `Genre: ${brainstormData.genre}\n`;
      if (brainstormData.theme) prompt += `Theme: ${brainstormData.theme}\n`;
      if (brainstormData.setting) prompt += `Setting: ${brainstormData.setting}\n`;
      if (brainstormData.tone) prompt += `Tone: ${brainstormData.tone}\n`;
      if (brainstormData.timeframe) prompt += `Time Period: ${brainstormData.timeframe}\n`;
      if (brainstormData.targetAudience) prompt += `Target Audience: ${brainstormData.targetAudience}\n`;
    }

    if (charactersData && charactersData.length > 0) {
      prompt += `\nDeveloped Characters:\n`;
      charactersData.forEach(char => {
        prompt += `${char.name} (${char.role}): ${char.description}\n`;
        if (char.motivation) prompt += `  Motivation: ${char.motivation}\n`;
        if (char.arc) prompt += `  Character Arc: ${char.arc}\n`;
        if (char.backstory) prompt += `  Backstory: ${char.backstory}\n`;
      });
    }

    let mainCharacterName = 'the protagonist';
    if (charactersData && charactersData.length > 0) {
      const protagonist = charactersData.find(c => c.role === 'protagonist') || charactersData[0];
      mainCharacterName = protagonist.name;
    } else if (brainstormData?.idea) {
      const extractedNames = extractCharacterNames(brainstormData.idea);
      if (extractedNames.length > 0) {
        mainCharacterName = extractedNames[0];
      }
    }

    if (structureType === 'act1') {
      prompt += `\nBased on the established story foundation above, generate complete Act 1 structure for ${mainCharacterName}'s story. Use the specific genre (${brainstormData?.genre || 'established genre'}), setting (${brainstormData?.setting || 'established setting'}), and tone (${brainstormData?.tone || 'established tone'}). Reference the developed characters by name and build directly on the core story concept and premise.

Format your response with these exact labeled sections:

Setup:
[Introduce ${mainCharacterName} in their ordinary world within the ${brainstormData?.setting || 'established setting'}. Show their current life, relationships, and what they care about before everything changes. Build on the established character development and story concept.]

Inciting Incident:
[The specific event that disrupts ${mainCharacterName}'s normal world and sets the main story in motion. This should directly relate to the core concept: ${brainstormData?.idea || 'the established story idea'}.]

Plot Point 1:
[${mainCharacterName}'s decision to pursue their goal and enter the new world of Act II. Reference their established motivation and character arc.]

Maintain consistency with the ${brainstormData?.genre || 'established genre'} genre, ${brainstormData?.tone || 'established tone'} tone, and ${brainstormData?.theme || 'established theme'} theme throughout.`;

    } else if (structureType === 'act2') {
      prompt += `\nGenerate complete Act 2 structure for ${mainCharacterName}'s story. Format your response with these exact labeled sections:

Confrontation:
[${mainCharacterName} faces escalating obstacles while pursuing their goal, building toward the midpoint revelation]

Midpoint:
[Major twist or revelation that changes everything for ${mainCharacterName}, raising the stakes significantly]

Plot Point 2:
[The darkest moment where ${mainCharacterName} faces their greatest fear or lowest point before the final act]

Build on the established story elements and character development.`;

    } else if (structureType === 'act3') {
      prompt += `\nGenerate complete Act 3 structure for ${mainCharacterName}'s story. Format your response with these exact labeled sections:

Climax:
[The final confrontation where ${mainCharacterName} faces their biggest challenge using everything they've learned]

Resolution:
[Show the new normal - how has ${mainCharacterName} changed and what is their world like now]

Bring together all established story threads and character development.`;

    } else {
      prompt += `\nCreate a complete three-act structure for ${mainCharacterName}'s story that builds on all established elements. Maintain character consistency and reference the established story concept throughout.`;
    }

    console.log('Final contextual prompt:', prompt.substring(0, 300) + '...');
    return prompt;
  };

  const generateStructure = async (
    structureType: string,
    brainstormData: ProjectBrainstorm | null,
    charactersData: Character[],
    setStructureCallback: (structure: ProjectStructure) => void,
    saveStructureCallback: (structure: ProjectStructure) => Promise<void>
  ) => {
    setIsGenerating(true);
    
    try {
      // Ensure we have the latest data before generation
      console.log('Starting generation with current data:', { 
        structureType, 
        hasBrainstorm: !!brainstormData,
        brainstormIdea: brainstormData?.idea?.substring(0, 50),
        charactersCount: charactersData?.length || 0,
        characterNames: charactersData?.map(c => c.name)
      });
      
      const prompt = buildContextualPrompt(structureType, brainstormData, charactersData);
      console.log('Generated prompt length:', prompt.length);
      
      const response = await callOpenAI(prompt);
      console.log('Generated response:', response.substring(0, 200) + '...');

      // Get current structure to preserve other acts
      const currentStructure = structure;
      
      if (structureType === 'act1') {
        // Parse Act 1 response into all three fields
        const setupMatch = response.match(/Setup:\s*(.*?)(?=Inciting Incident:|$)/is);
        const incitingMatch = response.match(/Inciting Incident:\s*(.*?)(?=Plot Point 1:|$)/is);
        const plotPoint1Match = response.match(/Plot Point 1:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act1: {
            setup: setupMatch ? setupMatch[1].trim() : response.split('\n')[0] || '',
            incitingIncident: incitingMatch ? incitingMatch[1].trim() : response.split('\n')[1] || '',
            plotPoint1: plotPoint1Match ? plotPoint1Match[1].trim() : response.split('\n')[2] || ''
          }
        };
        
        console.log('Generated Act 1 structure:', newStructure.act1);
        setStructureCallback(newStructure);
        await saveStructureCallback(newStructure);
        
      } else if (structureType === 'act2') {
        // Parse Act 2 response into all three fields
        const confrontationMatch = response.match(/Confrontation:\s*(.*?)(?=Midpoint:|$)/is);
        const midpointMatch = response.match(/Midpoint:\s*(.*?)(?=Plot Point 2:|$)/is);
        const plotPoint2Match = response.match(/Plot Point 2:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act2: {
            confrontation: confrontationMatch ? confrontationMatch[1].trim() : response.split('\n')[0] || '',
            midpoint: midpointMatch ? midpointMatch[1].trim() : response.split('\n')[1] || '',
            plotPoint2: plotPoint2Match ? plotPoint2Match[1].trim() : response.split('\n')[2] || ''
          }
        };
        
        setStructureCallback(newStructure);
        await saveStructureCallback(newStructure);
        
      } else if (structureType === 'act3') {
        // Parse Act 3 response into both fields
        const climaxMatch = response.match(/Climax:\s*(.*?)(?=Resolution:|$)/is);
        const resolutionMatch = response.match(/Resolution:\s*(.*?)(?=\n\n|$)/is);
        
        const newStructure: ProjectStructure = {
          ...currentStructure,
          act3: {
            climax: climaxMatch ? climaxMatch[1].trim() : response.split('\n')[0] || '',
            resolution: resolutionMatch ? resolutionMatch[1].trim() : response.split('\n')[1] || ''
          }
        };
        
        setStructureCallback(newStructure);
        await saveStructureCallback(newStructure);
      }

      console.log('Structure generation completed successfully');
      
    } catch (error) {
      console.error('Structure generation failed:', error);
      alert(`Structure generation failed. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // New function to generate individual fields
  const generateIndividualField = async (fieldKey: string) => {
    setIsGenerating(true);
    
    try {
      console.log('Generating individual field with context:', { 
        fieldKey, 
        hasBrainstorm: !!brainstorm,
        charactersCount: characters?.length || 0
      });
      
      const prompt = buildFieldPrompt(fieldKey, brainstorm, characters);
      console.log('Individual field prompt:', prompt.substring(0, 200) + '...');
      
      const response = await callOpenAI(prompt);
      console.log('Generated individual field response for:', fieldKey);

      // Update the specific field in the structure
      const currentStructure = structure;
      let newStructure: ProjectStructure;

      if (['setup', 'incitingIncident', 'plotPoint1'].includes(fieldKey)) {
        newStructure = {
          ...currentStructure,
          act1: {
            ...currentStructure.act1,
            [fieldKey]: response.trim()
          }
        };
      } else if (['confrontation', 'midpoint', 'plotPoint2'].includes(fieldKey)) {
        newStructure = {
          ...currentStructure,
          act2: {
            ...currentStructure.act2,
            [fieldKey]: response.trim()
          }
        };
      } else if (['climax', 'resolution'].includes(fieldKey)) {
        newStructure = {
          ...currentStructure,
          act3: {
            ...currentStructure.act3,
            [fieldKey]: response.trim()
          }
        };
      } else {
        newStructure = currentStructure;
      }
      
      setStructure(newStructure);
      await saveStructure(newStructure);
      
      console.log('Individual field generated and saved successfully');
      
    } catch (error) {
      console.error('Individual field generation failed:', error);
      alert(`Failed to generate ${getFieldDisplayName(fieldKey)}. Please check your API key and try again. Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Updated handleAIAssist function
  const handleAIAssist = (field: string): void => {
    console.log('AI Assist called for field:', field);
    console.log('Current brainstorm data:', brainstorm);
    console.log('Current characters data:', characters);
    
    if (['act1', 'act2', 'act3'].includes(field)) {
      // Generate complete act structure (all fields at once) with current data
      generateStructure(field, brainstorm, characters, setStructure, saveStructure).catch(error => {
        console.error('AI assist error:', error);
      });
    } else {
      // Generate individual field with context from previous pages
      generateIndividualField(field).catch(error => {
        console.error('AI assist error:', error);
      });
    }
  };

  const saveStructure = async (structureToSave?: ProjectStructure) => {
    if (!projectId) return;
    
    const structureData = structureToSave || structure;
    
    try {
      const { data: script } = await supabase
        .from('scripts')
        .select('content')
        .eq('id', projectId)
        .maybeSingle();

      // Fixed: Safer type handling for existingContent
      let existingContent: Record<string, any> = {};
      if (script?.content && typeof script.content === 'object' && !Array.isArray(script.content)) {
        existingContent = script.content as Record<string, any>;
      }
      
      const updatedContent = {
        ...existingContent,
        structure: structureData
      };

      await supabase
        .from('scripts')
        .update({ content: updatedContent as any })
        .eq('id', projectId);

      console.log('Structure saved successfully');
    } catch (error) {
      console.error('Failed to save structure:', error);
    }
  };

  const canProceed = (): boolean => {
    return !!(structure?.act1?.setup && structure?.act2?.confrontation && structure?.act3?.climax);
  };

  return {
    brainstorm,
    structure,
    setStructure,
    characters,
    isGenerating,
    loading,
    handleAIAssist,
    canProceed,
    saveStructure,
    generateStructure,
    getApiKey
  };
};
