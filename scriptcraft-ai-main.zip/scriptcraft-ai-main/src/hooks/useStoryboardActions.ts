
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { SceneAnalyzer } from '../lib/sceneAnalyzer';
import { StoryboardGenerator, StoryboardFrame } from '../lib/storyboard';
import { ImageModel } from '../contexts/APIKeyContext';
import { toast } from '../components/ui/sonner';
import { useStoryboardGeneration } from '../contexts/StoryboardGenerationContext';

export const useStoryboardActions = (
  imageApiKey: string,
  imageModel: ImageModel,
  elements: any[],
  updateStoryboardFrames: (frames: StoryboardFrame[]) => void
) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [generatingStoryboard, setGeneratingStoryboard] = useState(false);
  const { 
    startGeneration, 
    updateProgress, 
    abortController,
    progress
  } = useStoryboardGeneration();

  const generateCompleteStoryboard = async () => {
    console.log('=== ENHANCED STORYBOARD GENERATION START ===');
    console.log('Generate complete storyboard called with:', {
      apiKey: imageApiKey ? 'Present' : 'Missing',
      scriptId: id,
      elementsCount: elements?.length || 0,
      imageModel: imageModel.name
    });

    // Enhanced validation with detailed logging
    if (!imageApiKey.trim()) {
      const errorMsg = 'Please configure your API key for storyboard generation first';
      console.error('❌ VALIDATION FAILED:', errorMsg);
      toast.error(errorMsg);
      return;
    }

    if (!id) {
      const errorMsg = 'No script ID found';
      console.error('❌ VALIDATION FAILED:', errorMsg);
      toast.error(errorMsg);
      return;
    }

    if (!elements || elements.length === 0) {
      const errorMsg = 'No script content found to generate storyboard from. Please add some content to your script first.';
      console.error('❌ VALIDATION FAILED:', errorMsg);
      console.error('Elements state:', elements);
      toast.error(errorMsg);
      return;
    }

    setGeneratingStoryboard(true);
    
    try {
      // Step 1: Analyzing scenes with unified SceneAnalyzer
      console.log('=== SCENE ANALYSIS START ===');
      
      // Clear any old localStorage data to ensure fresh generation
      localStorage.removeItem(`storyboard-${id}`);
      
      // Use unified SceneAnalyzer with enhanced logging
      console.log('Calling SceneAnalyzer.analyzeScenes...');
      const analyzedScenes = SceneAnalyzer.analyzeScenes(elements);
      
      console.log('=== SCENE ANALYSIS RESULTS ===');
      console.log(`Scene analysis completed: ${analyzedScenes.length} scenes detected`);
      
      if (analyzedScenes.length === 0) {
        console.error('❌ NO SCENES DETECTED');
        const errorMsg = 'No scenes found in the script. Please add scene headings (INT./EXT.) to your script.';
        toast.error(errorMsg);
        updateProgress({ 
          currentStep: 'error', 
          message: errorMsg,
          isGenerating: false 
        });
        return;
      }

      // Initialize progress tracking
      startGeneration(analyzedScenes.length);
      updateProgress({
        currentStep: 'analyzing',
        message: `Analyzing ${analyzedScenes.length} scenes...`,
        totalScenes: analyzedScenes.length
      });

      // Convert to ParsedScene format for storyboard generation
      const parsedScenes = analyzedScenes.map(scene => ({
        id: scene.id,
        heading: scene.heading,
        location: scene.location,
        timeOfDay: scene.timeOfDay,
        actions: scene.actions,
        characters: scene.characters,
        dialogue: scene.dialogue,
        keyMoments: scene.keyMoments
      }));

      console.log(`✅ Successfully converted ${parsedScenes.length} scenes for storyboard generation`);

      // Step 2: Creating frames
      updateProgress({
        currentStep: 'generating',
        message: `Creating storyboard frames for ${parsedScenes.length} scenes...`,
        currentScene: 0
      });

      console.log('=== STORYBOARD FRAME GENERATION START ===');

      // Generate storyboard frames using AI with character extraction and selected model
      const generator = new StoryboardGenerator(imageApiKey, imageModel);
      const frames = await generator.generateStoryboard(parsedScenes, elements);
      
      console.log(`✅ Generated ${frames.length} storyboard frames with ${imageModel.name}`);
      
      // Step 3: Generating images with progressive updates
      updateProgress({
        message: `Generating images for ${frames.length} frames using ${imageModel.name}...`,
        frames: frames
      });

      console.log('=== IMAGE GENERATION START ===');
      
      // Generate images for all frames with progress tracking and cancellation support
      let completedImages = 0;
      const framesWithImages = await generator.generateImagesForFrames(
        frames,
        id,
        (progressFrames) => {
          // Check if generation was cancelled
          if (abortController?.signal.aborted) {
            console.log('Generation cancelled by user');
            throw new Error('Generation cancelled');
          }

          console.log('Image generation progress update:', progressFrames.length);
          updateStoryboardFrames(progressFrames);
          
          // Count completed frames for progress tracking
          const newCompletedImages = progressFrames.filter(f => f.imageUrl && !f.isGeneratingImage).length;
          const currentGenerating = progressFrames.find(f => f.isGeneratingImage);
          
          if (newCompletedImages > completedImages) {
            completedImages = newCompletedImages;
            updateProgress({
              currentScene: completedImages,
              message: `Generated ${completedImages}/${frames.length} images using ${imageModel.name}...`,
              frames: progressFrames
            });
          }

          if (currentGenerating) {
            updateProgress({
              message: `Generating image for ${currentGenerating.title}... (${completedImages + 1}/${frames.length})`,
              frames: progressFrames
            });
          }
        }
      );
      
      console.log(`✅ Complete storyboard generation finished with ${imageModel.name}`);
      console.log('=== STORYBOARD GENERATION COMPLETE ===');
      
      updateProgress({
        currentStep: 'completed',
        message: `Successfully generated complete storyboard with ${completedImages} images!`,
        frames: framesWithImages,
        isGenerating: false
      });

      toast.success(`Successfully generated complete storyboard with ${completedImages} images using ${imageModel.name}!`);
      
      updateStoryboardFrames(framesWithImages);
      
      // Save complete storyboard to localStorage
      localStorage.setItem(`storyboard-${id}`, JSON.stringify(framesWithImages));
      
    } catch (error) {
      console.error('❌ Complete storyboard generation failed:', error);
      
      if (error.message === 'Generation cancelled') {
        console.log('Generation was cancelled by user');
        return; // Don't show error toast for user cancellation
      }

      console.error('Error details:', {
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : 'No stack trace'
      });
      
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateProgress({
        currentStep: 'error',
        message: `Storyboard generation failed: ${errorMessage}`,
        isGenerating: false
      });
      
      toast.error(`Storyboard generation failed: ${errorMessage}`);
    } finally {
      setGeneratingStoryboard(false);
      console.log('=== STORYBOARD GENERATION END ===');
    }
  };

  const deleteImage = async (frameId: string, storyboardFrames: StoryboardFrame[]) => {
    if (!id) return;
    
    try {
      console.log('Deleting image for frame:', frameId);
      const generator = new StoryboardGenerator(imageApiKey || 'temp', imageModel);
      await generator.deleteImage(id, frameId);
      
      // Update frames to remove the image
      const updatedFrames = storyboardFrames.map(frame => 
        frame.id === frameId ? { ...frame, imageUrl: undefined } : frame
      );
      updateStoryboardFrames(updatedFrames);
      toast.success('Image deleted successfully');
      
    } catch (error) {
      console.error('Failed to delete image:', error);
      toast.error('Failed to delete image');
    }
  };

  const deleteAllImages = async (storyboardFrames: StoryboardFrame[]) => {
    if (!id) return;
    
    try {
      console.log('Deleting all images for script:', id);
      const generator = new StoryboardGenerator(imageApiKey || 'temp', imageModel);
      await generator.deleteAllImages(id);
      
      // Update frames to remove all images
      const updatedFrames = storyboardFrames.map(frame => ({ 
        ...frame, 
        imageUrl: undefined 
      }));
      updateStoryboardFrames(updatedFrames);
      toast.success('All images deleted successfully');
      
    } catch (error) {
      console.error('Failed to delete all images:', error);
      toast.error('Failed to delete all images');
    }
  };

  return {
    generatingStoryboard,
    generateCompleteStoryboard,
    deleteImage,
    deleteAllImages
  };
};
