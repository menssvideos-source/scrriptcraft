
import { useScriptContext } from './useScriptContext';
import { ProjectBrainstorm, ProjectStructure, Character } from '../types/project';
import { ContextService } from '../services/ContextService';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export const useContextualSceneGeneration = () => {
  const getApiKey = () => {
    return localStorage.getItem('openai-api-key') || '';
  };

  const callOpenAI = async (prompt: string, storyContext?: any) => {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('Please enter your OpenAI API key in the AI Assistant panel first');
    }

    // Enhanced system message with story context
    let systemMessage = `You are a professional screenplay writing assistant`;
    
    if (storyContext) {
      systemMessage += ` working on "${storyContext.scriptTitle}" - a ${storyContext.genre} story.

STORY CONTEXT:
- Main Character: ${storyContext.mainCharacter?.name || 'Protagonist'} - ${storyContext.mainCharacter?.description || 'Character in development'}
- Current Act: ${storyContext.currentAct} - ${storyContext.actDescription}
- Genre: ${storyContext.genre}

WRITING GUIDELINES:
- Maintain character voice and consistency
- Build on established plot threads
- Reference previous events naturally
- Keep scenes focused and properly formatted
- Advance the story naturally within the ${storyContext.genre} framework

Generate scene content that maintains story continuity and character consistency for "${storyContext.scriptTitle}".`;
    } else {
      systemMessage += `. Generate scene content that maintains story continuity, character consistency, and proper screenplay format. Always reference established characters by name and build on previous story elements. Consider the three-act structure and character arcs when suggesting scenes.`;
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          {
            role: 'system',
            content: systemMessage
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 200,
      }),
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  };

  const generateContextualScene = async (
    scriptContext: ReturnType<typeof useScriptContext>,
    sceneType: string = 'next',
    scriptTitle?: string
  ): Promise<string> => {
    const {
      getCurrentActInfo,
      currentSceneIndex,
      totalScenes,
      elements,
      characters
    } = scriptContext;

    // Build enhanced story context using the new ContextService
    const storyContext = ContextService.buildStoryContext(
      undefined, // brainstorm not available in this context
      undefined, // structure not available in this context
      characters,
      elements,
      scriptTitle
    );

    // Build contextual prompt using the enhanced context
    let prompt = ContextService.buildContextualPrompt('', storyContext);
    
    const actInfo = getCurrentActInfo();
    prompt += `\nCurrent Position: Act ${actInfo.act} (${Math.round(actInfo.progress)}% complete)\n`;
    prompt += `Scene ${currentSceneIndex + 1} of ${totalScenes}\n`;
    prompt += `Act Goal: ${actInfo.description}\n`;

    // Add recent script context for continuity
    const recentElements = elements.slice(-10);
    const recentContent = recentElements
      .filter(el => el.content.trim())
      .map(el => `${el.type.toUpperCase()}: ${el.content}`)
      .join('\n');
    
    if (recentContent) {
      prompt += `\nRecent Script Content:\n${recentContent}\n`;
    }

    const mainCharacterName = storyContext.mainCharacter?.name || 'the protagonist';

    // Enhanced scene-specific instructions with story context
    if (sceneType === 'opening' || totalScenes === 0) {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write the opening scene that introduces ${mainCharacterName} in their ordinary world. Build on the established ${storyContext.genre} story concept and maintain character consistency.`;
    } else if (sceneType === 'inciting' && actInfo.act === 1) {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write the inciting incident scene for ${mainCharacterName} that disrupts their normal life and sets the main story in motion.`;
    } else if (sceneType === 'character') {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write a character development scene for ${mainCharacterName} that reveals important aspects of their personality, motivation, or backstory.`;
    } else if (sceneType === 'conflict') {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write a conflict scene where ${mainCharacterName} faces obstacles or opposition related to their main goal.`;
    } else if (sceneType === 'revelation') {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write a revelation scene where ${mainCharacterName} discovers important information that changes their understanding or situation.`;
    } else if (sceneType === 'climax' && actInfo.act === 3) {
      prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write a climactic scene where ${mainCharacterName} faces their greatest challenge and the main conflict reaches its peak.`;
    } else {
      // Default "next" scene with enhanced context
      if (actInfo.act === 1) {
        prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write the next scene that continues the setup, developing ${mainCharacterName} and building toward the inciting incident.`;
      } else if (actInfo.act === 2) {
        prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write the next scene that escalates the conflict and pushes ${mainCharacterName} further from their comfort zone.`;
      } else {
        prompt += `\nContinue ${mainCharacterName}'s story in "${storyContext.scriptTitle}". Write the next scene that moves toward resolution, addressing consequences and tying up story threads.`;
      }
    }

    // Add character voice consistency
    const characterVoice = storyContext.characterVoiceSamples[mainCharacterName];
    if (characterVoice && characterVoice.length > 0) {
      prompt += `\n\nCharacter Voice: Maintain consistency with ${mainCharacterName}'s established speaking style: ${characterVoice.slice(0, 2).map(v => `"${v}"`).join(', ')}`;
    }

    prompt += `\n\nFormat: Start with scene heading (INT./EXT. LOCATION - TIME), then action lines. Use established character names and maintain story continuity with "${storyContext.scriptTitle}". Keep it concise but compelling, appropriate for the ${storyContext.genre} genre.`;

    return await callOpenAI(prompt, storyContext);
  };

  const generateContextualDialogue = async (
    scriptContext: ReturnType<typeof useScriptContext>,
    characterName: string,
    situation: string,
    scriptTitle?: string
  ): Promise<string> => {
    const { getCharacterByName, characters, elements } = scriptContext;
    let character = getCharacterByName(characterName);
    
    // If character not found in development, try to find in content
    if (!character) {
      character = characters.find(c => c.name.toLowerCase().includes(characterName.toLowerCase()));
    }

    // Build story context for enhanced dialogue generation
    const storyContext = ContextService.buildStoryContext(
      undefined,
      undefined,
      characters,
      elements,
      scriptTitle
    );

    let prompt = ContextService.buildContextualPrompt('', storyContext);
    
    if (character) {
      prompt += `\nCharacter Focus: ${character.name}\n`;
      prompt += `Role: ${character.role}\n`;
      prompt += `Description: ${character.description}\n`;
      if (character.motivation) prompt += `Motivation: ${character.motivation}\n`;
      if (character.voiceSample) prompt += `Voice Sample: ${character.voiceSample}\n`;
    } else {
      prompt += `\nCharacter Focus: ${characterName} (maintain consistency with previous appearances)\n`;
    }

    // Add established voice samples
    const characterVoice = storyContext.characterVoiceSamples[characterName];
    if (characterVoice && characterVoice.length > 0) {
      prompt += `\nEstablished Voice Examples:\n${characterVoice.map(v => `"${v}"`).join('\n')}\n`;
    }
    
    prompt += `\nSituation: ${situation}\n`;
    prompt += `\nWrite dialogue for ${characterName} in "${storyContext.scriptTitle}" that fits their established character, motivation, and the current situation. Maintain character consistency and voice from their previous appearances. Keep it natural and true to their established personality in this ${storyContext.genre} story.`;

    return await callOpenAI(prompt, storyContext);
  };

  return {
    generateContextualScene,
    generateContextualDialogue,
    getApiKey
  };
};
