
import { ImageModel } from '../contexts/APIKeyContext';
import { useStoryboardData } from './useStoryboardData';
import { useStoryboardActions } from './useStoryboardActions';

export const useStoryboardOperations = (imageApiKey: string, elements: any[], imageModel: ImageModel) => {
  // Data management hook (simplified since we don't need frames in the panel)
  const { loadingImages } = useStoryboardData(imageApiKey);

  // Actions hook with the combined generation workflow
  const { generatingStoryboard, generateCompleteStoryboard } = useStoryboardActions(
    imageApiKey, 
    imageModel, 
    elements, 
    () => {} // No need to update frames in the panel since we navigate away
  );

  return {
    generatingStoryboard,
    loadingImages,
    generateCompleteStoryboard
  };
};
