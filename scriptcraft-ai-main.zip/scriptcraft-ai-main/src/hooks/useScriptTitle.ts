
import { useState, useCallback } from 'react';
import { supabase } from '../integrations/supabase/client';

export const useScriptTitle = () => {
  const [scriptTitle, setScriptTitle] = useState('');
  const [isSavingTitle, setIsSavingTitle] = useState(false);
  const [titleSaved, setTitleSaved] = useState(false);
  const [titleLoaded, setTitleLoaded] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const isValidUUID = (uuid: string): boolean => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(uuid);
  };

  const isTimestampId = (id: string): boolean => {
    // Check if it's a timestamp (13 digits for milliseconds since epoch)
    return /^\d{13}$/.test(id);
  };

  const loadScript = useCallback(async (projectId: string) => {
    if (titleLoaded) {
      console.log('useScriptTitle: Title already loaded, skipping');
      return;
    }

    try {
      console.log('useScriptTitle: Loading script with ID:', projectId);
      
      // Handle both UUIDs and legacy timestamp IDs
      if (!isValidUUID(projectId) && !isTimestampId(projectId)) {
        console.error('useScriptTitle: Invalid project ID format:', projectId);
        setScriptTitle('');
        setTitleLoaded(true);
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('useScriptTitle: No authenticated user found');
        setScriptTitle('');
        setTitleLoaded(true);
        return;
      }

      // For timestamp IDs, try to find or create a script
      if (isTimestampId(projectId)) {
        console.log('useScriptTitle: Handling legacy timestamp ID:', projectId);
        
        // Check if we have project data in localStorage
        const projectData = localStorage.getItem(`project-${projectId}`);
        if (projectData) {
          try {
            const parsed = JSON.parse(projectData);
            setScriptTitle(parsed.title || 'Untitled Script');
            setTitleLoaded(true);
            return;
          } catch (error) {
            console.error('useScriptTitle: Error parsing project data:', error);
          }
        }
        
        // If no localStorage data, set default title
        setScriptTitle('Untitled Script');
        setTitleLoaded(true);
        return;
      }

      const { data: script, error } = await supabase
        .from('scripts')
        .select('title')
        .eq('id', projectId)
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('useScriptTitle: Error loading script:', error);
        setScriptTitle('');
        setTitleLoaded(true);
        return;
      }

      if (script) {
        console.log('useScriptTitle: Script loaded successfully:', script.title);
        setScriptTitle(script.title || '');
      } else {
        console.log('useScriptTitle: No script found with this ID');
        setScriptTitle('');
      }
      
      setTitleLoaded(true);
    } catch (error) {
      console.error('useScriptTitle: Error loading script:', error);
      setScriptTitle('');
      setTitleLoaded(true);
    }
  }, [titleLoaded]);

  const saveScriptTitle = useCallback(async (projectId: string, newTitle: string) => {
    if (!projectId || !newTitle.trim()) {
      console.log('useScriptTitle: No project ID or title to save');
      throw new Error('No project ID or title provided');
    }

    // Handle legacy timestamp IDs differently
    if (isTimestampId(projectId)) {
      console.log('useScriptTitle: Saving title for legacy timestamp ID:', projectId);
      
      setIsSavingTitle(true);
      setTitleSaved(false);
      setSaveError(null);

      try {
        // Update localStorage for timestamp IDs
        const projectData = localStorage.getItem(`project-${projectId}`);
        let data = { title: newTitle.trim() };
        
        if (projectData) {
          try {
            data = { ...JSON.parse(projectData), title: newTitle.trim(), lastModified: new Date() };
          } catch (error) {
            console.error('useScriptTitle: Error parsing existing project data:', error);
          }
        }
        
        localStorage.setItem(`project-${projectId}`, JSON.stringify(data));
        setScriptTitle(newTitle.trim());
        setTitleSaved(true);
        setTimeout(() => setTitleSaved(false), 2000);
        console.log('useScriptTitle: Title saved to localStorage for legacy ID');
        return;
      } catch (error) {
        console.error('useScriptTitle: Error saving title for legacy ID:', error);
        setSaveError(error instanceof Error ? error.message : 'Unknown error');
        throw error;
      } finally {
        setIsSavingTitle(false);
      }
    }

    if (!isValidUUID(projectId)) {
      console.error('useScriptTitle: Invalid project ID format for saving:', projectId);
      throw new Error('Invalid project ID');
    }

    setIsSavingTitle(true);
    setTitleSaved(false);
    setSaveError(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('useScriptTitle: No authenticated user for saving');
        throw new Error('User not authenticated');
      }

      console.log('useScriptTitle: Saving script title:', newTitle, 'for project:', projectId);

      const { error: updateError } = await supabase
        .from('scripts')
        .update({ 
          title: newTitle.trim(),
          updated_at: new Date().toISOString()
        })
        .eq('id', projectId)
        .eq('user_id', user.id);

      if (updateError) {
        console.error('useScriptTitle: Error updating script:', updateError);
        throw updateError;
      }

      console.log('useScriptTitle: Script title saved successfully');
      setScriptTitle(newTitle.trim());
      setTitleSaved(true);
      setTimeout(() => setTitleSaved(false), 2000);
    } catch (error) {
      console.error('useScriptTitle: Error saving script title:', error);
      setSaveError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    } finally {
      setIsSavingTitle(false);
    }
  }, []);

  const resetTitleState = useCallback(() => {
    setTitleLoaded(false);
    setSaveError(null);
  }, []);

  return {
    scriptTitle,
    setScriptTitle,
    isSavingTitle,
    titleSaved,
    saveError,
    loadScript,
    saveScriptTitle,
    resetTitleState
  };
};
