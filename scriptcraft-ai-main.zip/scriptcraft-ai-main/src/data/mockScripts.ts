import { Script, ScriptTemplate } from '../types/script';

export const mockScripts: Script[] = [
  {
    id: '1',
    title: 'The Last Stand',
    description: 'A thrilling action drama about redemption',
    template: 'feature-film',
    createdAt: new Date('2024-01-15'),
    lastModified: new Date('2024-01-20'),
    wordCount: 12450,
    pageCount: 95,
    sceneCount: 38,
    isStarred: true
  },
  {
    id: '2',
    title: 'Desert Moon',
    description: 'A western tale of love and revenge',
    template: 'feature-film',
    createdAt: new Date('2024-01-10'),
    lastModified: new Date('2024-01-18'),
    wordCount: 8900,
    pageCount: 68,
    sceneCount: 28
  },
  {
    id: '3',
    title: 'City Lights - Pilot',
    description: 'TV drama series pilot episode',
    template: 'tv-episode',
    createdAt: new Date('2024-01-05'),
    lastModified: new Date('2024-01-16'),
    wordCount: 6200,
    pageCount: 45,
    sceneCount: 18
  },
  {
    id: '4',
    title: 'Coffee Break',
    description: 'A heartwarming short about human connection',
    template: 'short-film',
    createdAt: new Date('2023-12-20'),
    lastModified: new Date('2024-01-12'),
    wordCount: 1200,
    pageCount: 8,
    sceneCount: 5,
    isStarred: true
  },
  {
    id: '5',
    title: 'Midnight Express',
    description: 'Crime thriller set in the subway system',
    template: 'feature-film',
    createdAt: new Date('2023-12-15'),
    lastModified: new Date('2024-01-08'),
    wordCount: 15600,
    pageCount: 112,
    sceneCount: 45
  }
];

export const scriptTemplates: ScriptTemplate[] = [
  {
    id: 'feature-film',
    name: 'Feature Film',
    description: 'Full-length screenplay (90-120 pages)',
    template: 'feature-film',
    icon: 'Film',
    defaultTitle: 'Untitled Feature Film'
  },
  {
    id: 'tv-episode',
    name: 'TV Episode',
    description: 'Television episode script (22-60 pages)',
    template: 'tv-episode',
    icon: 'Tv',
    defaultTitle: 'Untitled TV Episode'
  },
  {
    id: 'short-film',
    name: 'Short Film',
    description: 'Short screenplay (1-30 pages)',
    template: 'short-film',
    icon: 'Clock',
    defaultTitle: 'Untitled Short Film'
  }
];
