
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider } from './contexts/AuthContext';
import { APIKeyProvider } from './contexts/APIKeyContext';
import Homepage from './pages/Homepage';
import Dashboard from './pages/Dashboard';
import ScriptEditor from './pages/ScriptEditor';
import StoryboardView from './pages/StoryboardView';
import MyScripts from './pages/MyScripts';
import NewScript from './pages/NewScript';
import Login from './pages/Login';
import Signup from './pages/Signup';
import ResetPassword from './pages/ResetPassword';
import CharacterDevelopment from './pages/CharacterDevelopment';
import StructurePlanning from './pages/StructurePlanning';
import ProjectBrainstorm from './pages/ProjectBrainstorm';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Contact from './pages/Contact';
import SetupGuide from './pages/SetupGuide';
import UserGuide from './pages/UserGuide';
import NotFound from './pages/NotFound';
import { Toaster } from '@/components/ui/sonner';

// Create a client
const queryClient = new QueryClient();

function App() {
  return (
    <Router>
      <QueryClientProvider client={queryClient}>
        <LanguageProvider>
          <AuthProvider>
            <APIKeyProvider>
              <Toaster />
              <div className="min-h-screen bg-script-slate-50">
                <Routes>
                  <Route path="/" element={<Homepage />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/signup" element={<Signup />} />
                  <Route path="/reset-password" element={<ResetPassword />} />
                  <Route path="/scripts" element={<MyScripts />} />
                  <Route path="/new-script" element={<NewScript />} />
                  <Route path="/script/:id" element={<ScriptEditor />} />
                  <Route path="/script/:id/storyboard" element={<StoryboardView />} />
                  <Route path="/script/:id/character-development" element={<CharacterDevelopment />} />
                  <Route path="/script/:id/structure-planning" element={<StructurePlanning />} />
                  <Route path="/script/:id/brainstorm" element={<ProjectBrainstorm />} />
                  <Route path="/privacy" element={<Privacy />} />
                  <Route path="/terms" element={<Terms />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/setup-guide" element={<SetupGuide />} />
                  <Route path="/user-guide" element={<UserGuide />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </div>
            </APIKeyProvider>
          </AuthProvider>
        </LanguageProvider>
      </QueryClientProvider>
    </Router>
  );
}

export default App;
