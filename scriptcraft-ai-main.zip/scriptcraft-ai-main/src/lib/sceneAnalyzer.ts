
interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export interface AnalyzedScene {
  id: string;
  number: number;
  heading: string;
  location: string;
  timeOfDay: string;
  type: 'opening' | 'inciting' | 'character' | 'conflict' | 'revelation' | 'climax' | 'resolution' | 'general';
  actions: string[];
  characters: string[];
  dialogue: { character: string; text: string }[];
  keyMoments: string[];
  elementIndex: number;
}

export class SceneAnalyzer {
  static analyzeScenes(elements: ScriptElement[]): AnalyzedScene[] {
    console.log(`SceneAnalyzer: Starting analysis of ${elements.length} elements`);
    
    const scenes: AnalyzedScene[] = [];
    let currentScene: Partial<AnalyzedScene> | null = null;
    let sceneCounter = 1;

    elements.forEach((element, elementIndex) => {
      switch (element.type) {
        case 'scene-heading':
          // Save previous scene if exists
          if (currentScene && currentScene.heading) {
            const finalizedScene = this.finalizeScene(currentScene, sceneCounter - 1);
            scenes.push(finalizedScene);
            console.log(`SceneAnalyzer: Finalized scene ${sceneCounter - 1}: ${finalizedScene.heading}`);
          }
          
          // Validate scene heading with unified logic
          const content = element.content.trim();
          console.log(`SceneAnalyzer: Validating scene heading: "${content}"`);
          
          if (content && this.isValidSceneHeading(content)) {
            const { location, timeOfDay } = this.parseSceneHeading(content);
            const sceneType = this.detectSceneType(content, sceneCounter, scenes.length);
            
            currentScene = {
              id: `scene-${sceneCounter}`,
              number: sceneCounter,
              heading: content,
              location,
              timeOfDay,
              type: sceneType,
              actions: [],
              characters: [],
              dialogue: [],
              keyMoments: [],
              elementIndex
            };
            console.log(`SceneAnalyzer: ✅ Started new scene ${sceneCounter}: ${content}`);
            sceneCounter++;
          } else {
            console.log(`SceneAnalyzer: ❌ Skipped invalid scene heading: "${content}"`);
          }
          break;

        case 'action':
          if (currentScene && element.content.trim()) {
            currentScene.actions = currentScene.actions || [];
            currentScene.actions.push(element.content);
            
            if (this.isKeyMoment(element.content)) {
              currentScene.keyMoments = currentScene.keyMoments || [];
              currentScene.keyMoments.push(element.content);
            }
          }
          break;

        case 'character':
          if (currentScene && element.content.trim()) {
            const characterName = element.content.toUpperCase().trim();
            currentScene.characters = currentScene.characters || [];
            if (!currentScene.characters.includes(characterName)) {
              currentScene.characters.push(characterName);
            }
          }
          break;

        case 'dialogue':
          if (currentScene && element.content.trim()) {
            const lastCharacter = currentScene.characters?.[currentScene.characters.length - 1];
            if (lastCharacter) {
              currentScene.dialogue = currentScene.dialogue || [];
              currentScene.dialogue.push({
                character: lastCharacter,
                text: element.content
              });
            }
          }
          break;
      }
    });

    // Don't forget the last scene
    if (currentScene && currentScene.heading) {
      const finalizedScene = this.finalizeScene(currentScene, sceneCounter - 1);
      scenes.push(finalizedScene);
      console.log(`SceneAnalyzer: Finalized final scene ${sceneCounter - 1}: ${finalizedScene.heading}`);
    }

    console.log(`SceneAnalyzer: ✅ ANALYSIS COMPLETE. Found ${scenes.length} scenes total`);
    console.log('SceneAnalyzer: All detected scenes:', scenes.map(s => `${s.number}. ${s.heading}`));
    return scenes;
  }

  // Unified scene heading validation - more permissive and consistent
  private static isValidSceneHeading(content: string): boolean {
    const upperContent = content.toUpperCase();
    console.log(`SceneAnalyzer: Testing patterns for: "${upperContent}"`);
    
    // Skip only obvious non-scene elements
    const skipPatterns = [
      /^FADE\s+(IN|OUT|TO\s+BLACK)[:.]?$/i,
      /^THE\s+END$/i,
      /^TITLE\s+CARD/i,
      /^SUPER:/i,
      /^INSERT\s+-/i
    ];

    for (const pattern of skipPatterns) {
      if (pattern.test(upperContent)) {
        console.log(`SceneAnalyzer: ❌ Skipping transition/title: "${upperContent}"`);
        return false;
      }
    }

    // Enhanced scene patterns - very permissive
    const scenePatterns = [
      /^(SCENE|SC\.?)\s*\d+/i,           // SCENE 1, SCENE 2, SC. 1, SC 2
      /^\d+\./,                          // 1., 2., 3. (numbered scenes)
      /^(INT|EXT)\.?\s+/i,               // Standard INT./EXT. format
      /^(INTERIOR|EXTERIOR)\s+/i,        // Full words
      /\s+-\s+(DAY|NIGHT|DAWN|DUSK|MORNING|EVENING|AFTERNOON|LATER|CONTINUOUS)/i, // Time indicators
      /^[A-Z\s\-.,()]+\s+-\s+[A-Z\s]+$/,  // General LOCATION - TIME format
      /^[A-Z][A-Z\s\-.,()]{5,}$/,        // Any capitalized text that's long enough
      /^[A-Z]/                           // ANY line starting with capital letter (very permissive)
    ];

    // Test each pattern
    for (let i = 0; i < scenePatterns.length; i++) {
      const pattern = scenePatterns[i];
      if (pattern.test(upperContent)) {
        console.log(`SceneAnalyzer: ✅ Accepted scene heading: "${upperContent}" (matched pattern ${i + 1})`);
        return true;
      }
    }

    // Fallback: accept if reasonably formatted (30% uppercase threshold)
    const hasLocation = content.length >= 3;
    const uppercaseCount = upperContent.split('').filter(c => c.match(/[A-Z]/)).length;
    const isMainlyUppercase = uppercaseCount > content.length * 0.3;
    
    if (hasLocation && isMainlyUppercase) {
      console.log(`SceneAnalyzer: ✅ Accepted scene heading: "${upperContent}" (general formatting - ${Math.round(uppercaseCount/content.length*100)}% uppercase)`);
      return true;
    }

    console.log(`SceneAnalyzer: ❌ Rejected scene heading: "${upperContent}" (${Math.round(uppercaseCount/content.length*100)}% uppercase, needs 30%+)`);
    return false;
  }

  private static parseSceneHeading(heading: string): { location: string; timeOfDay: string } {
    console.log(`SceneAnalyzer: Parsing scene heading: "${heading}"`);
    
    let location = 'Unknown Location';
    let timeOfDay = 'DAY';

    // Try standard format first
    const standardMatch = heading.match(/^(INT|EXT)\.?\s+(.+?)\s+-\s+(.+)$/i);
    if (standardMatch) {
      location = standardMatch[2].trim();
      timeOfDay = standardMatch[3].trim().toUpperCase();
    } else {
      // Try alternative formats
      const dashSplit = heading.split(' - ');
      if (dashSplit.length >= 2) {
        location = dashSplit[0].replace(/^(INT|EXT)\.?\s*/i, '').trim();
        timeOfDay = dashSplit[1].trim().toUpperCase();
      } else {
        location = heading.replace(/^(INT|EXT)\.?\s*/i, '').trim();
        
        // Look for time indicators
        const headingLower = heading.toLowerCase();
        if (headingLower.includes('night') || headingLower.includes('evening')) {
          timeOfDay = 'NIGHT';
        } else if (headingLower.includes('dawn') || headingLower.includes('morning')) {
          timeOfDay = 'DAWN';
        } else if (headingLower.includes('dusk') || headingLower.includes('sunset')) {
          timeOfDay = 'DUSK';
        } else if (headingLower.includes('afternoon')) {
          timeOfDay = 'AFTERNOON';
        } else if (headingLower.includes('later') || headingLower.includes('continuous')) {
          timeOfDay = 'CONTINUOUS';
        }
      }
    }

    console.log(`SceneAnalyzer: Parsed "${heading}" → Location: "${location}", Time: "${timeOfDay}"`);
    return { location, timeOfDay };
  }

  private static isKeyMoment(action: string): boolean {
    const keyMomentIndicators = [
      /\b(enters?|exits?|walks?|runs?|sits?|stands?|opens?|closes?|moves?)\b/i,
      /\b(approaches?|leaves?|arrives?|disappears?|appears?)\b/i,
      /\b(looks?|stares?|glances?|watches?|observes?|sees?)\b/i,
      /\b(picks?\s+up|grabs?|holds?|drops?|throws?|catches?)\b/i,
      /\b(smiles?|frowns?|laughs?|cries?|shouts?|whispers?)\b/i,
      /\b(nods?|shakes?\s+head|gestures?|points?)\b/i,
      /\b(suddenly|slowly|quickly|carefully|nervously|quietly|loudly)\b/i,
      /\b(cut\s+to|dissolve|fade)\b/i,
      /\b(phone|door|window|car|gun|knife|computer|screen)\b/i
    ];

    return keyMomentIndicators.some(pattern => pattern.test(action));
  }

  private static detectSceneType(heading: string, sceneNumber: number, totalScenes: number): AnalyzedScene['type'] {
    const headingLower = heading.toLowerCase();
    
    if (sceneNumber === 1) return 'opening';
    
    if (headingLower.includes('flashback') || headingLower.includes('memory')) return 'revelation';
    if (headingLower.includes('fight') || headingLower.includes('chase') || headingLower.includes('battle')) return 'conflict';
    if (headingLower.includes('bedroom') || headingLower.includes('home') || headingLower.includes('house')) return 'character';
    if (headingLower.includes('office') || headingLower.includes('meeting') || headingLower.includes('conference')) return 'character';
    
    const position = sceneNumber / Math.max(totalScenes + 1, 1);
    if (position < 0.15) return 'opening';
    if (position < 0.25) return 'inciting';
    if (position < 0.5) return 'character';
    if (position < 0.75) return 'conflict';
    if (position < 0.9) return 'revelation';
    if (position >= 0.9) return 'climax';
    
    return 'general';
  }

  private static finalizeScene(scene: Partial<AnalyzedScene>, index: number): AnalyzedScene {
    return {
      id: scene.id || `scene-${index}`,
      number: scene.number || index,
      heading: scene.heading || '',
      location: scene.location || '',
      timeOfDay: scene.timeOfDay || '',
      type: scene.type || 'general',
      actions: scene.actions || [],
      characters: scene.characters || [],
      dialogue: scene.dialogue || [],
      keyMoments: scene.keyMoments || [],
      elementIndex: scene.elementIndex || 0
    };
  }

  // Utility methods for backwards compatibility
  static getNextSceneNumber(elements: ScriptElement[]): number {
    const scenes = this.analyzeScenes(elements);
    return scenes.length + 1;
  }

  static getSceneTypeDescription(type: AnalyzedScene['type']): string {
    const descriptions = {
      opening: 'Introduces character in ordinary world',
      inciting: 'Event that disrupts normal life',
      character: 'Develops character personality/backstory',
      conflict: 'Character faces obstacles',
      revelation: 'Important information revealed',
      climax: 'Major confrontation or turning point',
      resolution: 'Wrapping up story threads',
      general: 'Advances the story'
    };
    
    return descriptions[type];
  }
}
