
export interface StoryboardFrame {
  id: string;
  sceneId: string;
  sceneNumber: number;
  title: string;
  visualDescription: string;
  shotType: string;
  cameraAngle: string;
  mood: string;
  lighting: string;
  composition: string;
  imageUrl?: string;
  isGeneratingImage?: boolean;
  panelCount?: number;
  keyMoments?: string[];
  imageModel?: string;
  imageError?: string;
}
