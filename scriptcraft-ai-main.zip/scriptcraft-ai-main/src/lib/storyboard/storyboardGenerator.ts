
import { ParsedScene } from '../sceneParser';
import { CharacterExtractor, CharacterDescription } from '../characterExtractor';
import { FrameGenerator } from './frameGenerator';
import { ImageProcessor } from './imageProcessor';
import { StoryboardFrame } from './types';
import { ImageModel } from '../../contexts/APIKeyContext';
import { ContextService } from '../../services/ContextService';
import { ProjectBrainstorm, ProjectStructure, Character } from '../../types/project';

export class StoryboardGenerator {
  private apiKey: string;
  private imageModel: ImageModel;
  private frameGenerator: FrameGenerator;
  private imageProcessor: ImageProcessor;

  constructor(apiKey: string, imageModel: ImageModel) {
    this.apiKey = apiKey;
    this.imageModel = imageModel;
    this.frameGenerator = new FrameGenerator(apiKey);
    this.imageProcessor = new ImageProcessor(apiKey, imageModel);
  }

  async generateStoryboard(
    scenes: ParsedScene[], 
    elements: any[] = [],
    brainstorm?: ProjectBrainstorm | null,
    structure?: ProjectStructure | null,
    characters: Character[] = [],
    scriptTitle?: string
  ): Promise<StoryboardFrame[]> {
    console.log(`Generating enhanced storyboard for ${scenes.length} scenes with story context`);
    
    // Build story context
    const storyContext = ContextService.buildStoryContext(
      brainstorm,
      structure,
      characters,
      elements,
      scriptTitle
    );

    // Set story context for generators
    this.frameGenerator.setStoryContext(brainstorm, structure, characters, elements, scriptTitle);
    this.imageProcessor.setStoryContext(storyContext);

    // Extract characters for visual consistency
    const characterDescriptions = CharacterExtractor.extractCharacterDescriptions(elements);
    this.frameGenerator.setCharacters(characterDescriptions);
    this.imageProcessor.setCharacters(characterDescriptions);

    const frames: StoryboardFrame[] = [];
    
    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      console.log(`Processing scene ${i + 1}/${scenes.length} with story context: ${scene.heading}`);
      
      try {
        const frame = await this.frameGenerator.generateFrameForScene(scene, i + 1);
        frames.push(frame);
        console.log(`✅ Generated context-aware frame for scene ${i + 1}: ${frame.title}`);
      } catch (error) {
        console.error(`Failed to generate frame for scene ${i + 1}:`, error);
        // Create basic fallback frame
        frames.push({
          id: `${scene.id}-frame`,
          sceneId: scene.id,
          sceneNumber: i + 1,
          title: `Scene ${i + 1}`,
          visualDescription: scene.actions.join(' '),
          shotType: 'Medium Shot',
          cameraAngle: 'Eye Level',
          mood: 'Neutral',
          lighting: 'Natural',
          composition: 'Standard',
          panelCount: 1,
          keyMoments: scene.keyMoments
        });
      }
    }

    console.log(`✅ Generated ${frames.length} context-aware storyboard frames`);
    return frames;
  }

  async generateImagesForFrames(
    frames: StoryboardFrame[], 
    scriptId: string,
    onProgressUpdate?: (updatedFrames: StoryboardFrame[]) => void
  ): Promise<StoryboardFrame[]> {
    return this.imageProcessor.generateImagesForFrames(frames, scriptId, onProgressUpdate);
  }

  async loadStoredImages(scriptId: string, frames: StoryboardFrame[]): Promise<StoryboardFrame[]> {
    return this.imageProcessor.loadStoredImages(scriptId, frames);
  }

  async deleteImage(scriptId: string, frameId: string): Promise<void> {
    await this.imageProcessor.deleteImage(scriptId, frameId);
  }

  async deleteAllImages(scriptId: string): Promise<void> {
    await this.imageProcessor.deleteAllImages(scriptId);
  }
}
