import { StoryboardFrame } from './types';
import { ImageStorageService } from '../imageStorage';
import { CharacterDescription } from '../characterExtractor';
import { ImageModel } from '../../contexts/APIKeyContext';
import { ContextService, StoryContext } from '../../services/ContextService';

export class ImageProcessor {
  private apiKey: string;
  private imageModel?: ImageModel;
  private characters: CharacterDescription[] = [];
  private storyContext?: StoryContext;

  constructor(apiKey: string, imageModel?: ImageModel) {
    this.apiKey = apiKey;
    this.imageModel = imageModel;
  }

  setCharacters(characters: CharacterDescription[]) {
    this.characters = characters;
  }

  setStoryContext(storyContext: StoryContext) {
    this.storyContext = storyContext;
  }

  async generateImagesForFrames(
    frames: StoryboardFrame[], 
    scriptId: string,
    onProgressUpdate?: (updatedFrames: StoryboardFrame[]) => void
  ): Promise<StoryboardFrame[]> {
    const updatedFrames = [...frames];
    const imageStorage = new ImageStorageService();

    console.log(`Starting image generation for ${frames.length} frames using ${this.imageModel?.name || 'OpenAI DALL-E'}`);

    for (let i = 0; i < frames.length; i++) {
      const frame = frames[i];
      
      console.log(`Processing frame ${i + 1}/${frames.length}: ${frame.title}`);
      
      // Mark frame as generating
      updatedFrames[i] = { ...frame, isGeneratingImage: true, imageModel: this.imageModel?.name };
      onProgressUpdate?.(updatedFrames);

      try {
        // Create enhanced prompt with character descriptions
        const enhancedPrompt = this.createEnhancedPrompt(frame);
        console.log(`Enhanced prompt for frame ${frame.id}:`, enhancedPrompt.substring(0, 100) + '...');
        
        // Generate image based on selected model provider
        let temporaryImageUrl: string;
        
        if (this.imageModel?.provider === 'openai') {
          console.log(`Generating with OpenAI model: ${this.imageModel.id}`);
          temporaryImageUrl = await this.generateWithOpenAI(enhancedPrompt);
        } else if (this.imageModel?.provider === 'replicate') {
          console.log(`Generating with Replicate model: ${this.imageModel.id}`);
          temporaryImageUrl = await this.generateWithReplicate(enhancedPrompt);
        } else {
          // Default to OpenAI for backward compatibility
          console.log('Using default OpenAI DALL-E-3');
          temporaryImageUrl = await this.generateWithOpenAI(enhancedPrompt);
        }

        console.log(`Generated temporary image URL for frame ${frame.id}`);

        // Immediately store the image using server-side Edge Function
        console.log(`Storing image immediately for frame ${frame.id}`);
        const storedImageUrl = await imageStorage.downloadAndStoreImage(
          temporaryImageUrl,
          scriptId,
          frame.id,
          frame.sceneNumber,
          frame.title
        );

        console.log(`Successfully stored image for frame ${frame.id}: ${storedImageUrl}`);

        // Update frame with stored image URL
        updatedFrames[i] = { 
          ...frame, 
          imageUrl: storedImageUrl,
          isGeneratingImage: false,
          imageModel: this.imageModel?.name,
          imageError: undefined
        };
        
        console.log(`Updated frame ${frame.id} with stored image URL`);
        onProgressUpdate?.(updatedFrames);
        
      } catch (error) {
        console.error(`Failed to generate/store image for frame ${frame.id}:`, error);
        
        // Determine error type for better user feedback
        let errorMessage = error.message;
        if (error.message.includes('User not authenticated')) {
          errorMessage = 'Please log in to store images';
        } else if (error.message.includes('content policy')) {
          errorMessage = 'Image content violates policy - try different description';
        } else if (error.message.includes('API error: 400')) {
          errorMessage = 'Invalid image prompt - try simpler description';
        } else if (error.message.includes('Server-side storage failed')) {
          errorMessage = 'Storage failed - please try again';
        }
        
        updatedFrames[i] = { 
          ...frame, 
          isGeneratingImage: false,
          imageError: errorMessage,
          imageModel: this.imageModel?.name
        };
        onProgressUpdate?.(updatedFrames);
      }
    }

    console.log(`Completed image generation process. Successfully generated ${updatedFrames.filter(f => f.imageUrl).length}/${frames.length} images`);
    return updatedFrames;
  }

  private createEnhancedPrompt(frame: StoryboardFrame): string {
    let prompt = '';

    // Add story context for enhanced prompt
    if (this.storyContext) {
      prompt = ContextService.buildImagePrompt(
        frame.visualDescription,
        frame.title,
        frame.shotType || 'Medium Shot',
        frame.mood || 'Neutral',
        frame.lighting || 'Natural',
        this.storyContext
      );
    } else {
      // Fallback to original prompt structure
      prompt = `Create a detailed storyboard frame for: ${frame.title}. `;
      prompt += `Visual description: ${frame.visualDescription}. `;
      
      if (frame.mood) prompt += `Mood: ${frame.mood}. `;
      if (frame.lighting) prompt += `Lighting: ${frame.lighting}. `;
      if (frame.shotType) prompt += `Shot type: ${frame.shotType}. `;
      if (frame.cameraAngle) prompt += `Camera angle: ${frame.cameraAngle}. `;
      
      // Add character descriptions if available
      if (this.characters.length > 0) {
        prompt += `Characters in scene: `;
        this.characters.forEach(char => {
          const traits = char.physicalTraits.length > 0 ? ` (${char.physicalTraits.join(', ')})` : '';
          prompt += `${char.name}: ${char.description}${traits}. `;
        });
      }
    }
    
    // Provider-specific prompt optimization
    if (this.imageModel?.provider === 'replicate') {
      prompt += ` Style: Cinematic storyboard panel, professional film production quality, detailed illustration, high contrast, dramatic lighting.`;
    } else {
      prompt += ` Style: Cinematic storyboard panel, professional film production quality, detailed illustration.`;
    }
    
    return prompt;
  }

  private async generateWithOpenAI(prompt: string): Promise<string> {
    console.log('Making OpenAI API call with model:', this.imageModel?.id || 'dall-e-3');
    
    const requestBody = {
      model: this.imageModel?.id || 'dall-e-3',
      prompt: prompt,
      n: 1,
      size: '1024x1024',
      quality: this.imageModel?.quality === 'ultra' ? 'hd' : 'standard'
    };
    
    console.log('OpenAI request body:', requestBody);

    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    console.log('OpenAI API response status:', response.status);

    if (!response.ok) {
      const errorData = await response.text();
      console.error('OpenAI API error response:', errorData);
      throw new Error(`OpenAI API error: ${response.status} ${errorData}`);
    }

    const data = await response.json();
    console.log('OpenAI API response data:', data);
    
    if (!data.data || !data.data[0] || !data.data[0].url) {
      console.error('Invalid OpenAI response structure:', data);
      throw new Error('Invalid response from OpenAI API');
    }

    const imageUrl = data.data[0].url;
    console.log('Extracted image URL:', imageUrl);
    return imageUrl;
  }

  private async generateWithReplicate(prompt: string): Promise<string> {
    console.log(`Generating image with Replicate model: ${this.imageModel?.name}`);
    
    // Use Supabase edge function for Replicate API calls
    const { data, error } = await fetch('/api/replicate-image-generation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: prompt,
        model: this.imageModel?.id || 'flux-schnell',
        quality: this.imageModel?.quality || 'standard'
      })
    }).then(res => res.json());

    if (error) {
      console.error('Replicate generation error:', error);
      throw new Error(`Replicate API error: ${error.message}`);
    }

    if (!data?.imageUrl) {
      console.error('No image URL returned from Replicate:', data);
      throw new Error('No image URL returned from Replicate');
    }

    console.log('Replicate generated image URL:', data.imageUrl);
    return data.imageUrl;
  }

  async loadStoredImages(scriptId: string, frames: StoryboardFrame[]): Promise<StoryboardFrame[]> {
    try {
      console.log(`Loading stored images for script: ${scriptId}`);
      const imageStorage = new ImageStorageService();
      const storedImages = await imageStorage.getStoredImages(scriptId);
      
      console.log(`Found ${storedImages.length} stored images in database`);
      
      return frames.map(frame => {
        const storedImage = storedImages.find(img => img.frame_id === frame.id);
        if (storedImage) {
          // Get public URL for stored image
          const { data: urlData } = imageStorage.supabase.storage
            .from('storyboard-images')
            .getPublicUrl(storedImage.image_path);
          
          console.log(`Loaded stored image for frame ${frame.id}: ${urlData.publicUrl}`);
          return { ...frame, imageUrl: urlData.publicUrl };
        }
        return frame;
      });
    } catch (error) {
      console.error('Failed to load stored images:', error);
      return frames;
    }
  }

  async deleteImage(scriptId: string, frameId: string): Promise<void> {
    const imageStorage = new ImageStorageService();
    await imageStorage.deleteStoredImage(scriptId, frameId);
  }

  async deleteAllImages(scriptId: string): Promise<void> {
    const imageStorage = new ImageStorageService();
    await imageStorage.deleteAllImagesForScript(scriptId);
  }
}
