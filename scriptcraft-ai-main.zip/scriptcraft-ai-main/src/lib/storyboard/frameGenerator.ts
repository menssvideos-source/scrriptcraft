
import { ParsedScene } from '../sceneParser';
import { CharacterDescription, CharacterExtractor } from '../characterExtractor';
import { StoryboardFrame } from './types';
import { ContextService, StoryContext } from '../../services/ContextService';
import { ProjectBrainstorm, ProjectStructure, Character } from '../../types/project';

export class FrameGenerator {
  private apiKey: string;
  private characters: CharacterDescription[] = [];
  private storyContext?: StoryContext;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  setCharacters(characters: CharacterDescription[]) {
    this.characters = characters;
  }

  setStoryContext(
    brainstorm?: ProjectBrainstorm | null,
    structure?: ProjectStructure | null,
    characters: Character[] = [],
    elements: any[] = [],
    scriptTitle?: string
  ) {
    this.storyContext = ContextService.buildStoryContext(
      brainstorm,
      structure,
      characters,
      elements,
      scriptTitle
    );
  }

  async generateFrameForScene(scene: ParsedScene, sceneNumber: number): Promise<StoryboardFrame> {
    const prompt = this.buildVisualPrompt(scene);
    
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4.1-2025-04-14',
          messages: [
            {
              role: 'system',
              content: this.buildEnhancedSystemMessage()
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7,
          max_tokens: 500,
        }),
      });

      if (!response.ok) {
        throw new Error(`API call failed: ${response.status}`);
      }

      const data = await response.json();
      const result = JSON.parse(data.choices[0].message.content);
      
      return {
        id: `${scene.id}-frame`,
        sceneId: scene.id,
        sceneNumber,
        title: result.frame.title,
        visualDescription: result.frame.visualDescription,
        shotType: result.frame.shotType,
        cameraAngle: result.frame.cameraAngle,
        mood: result.frame.mood,
        lighting: result.frame.lighting,
        composition: result.frame.composition,
        panelCount: result.frame.panelCount || 3,
        keyMoments: result.frame.keyMoments || scene.keyMoments
      };

    } catch (error) {
      console.error('Storyboard generation failed:', error);
      // Return a basic frame if AI fails
      return {
        id: `${scene.id}-frame`,
        sceneId: scene.id,
        sceneNumber,
        title: `Scene ${sceneNumber}`,
        visualDescription: `Multi-panel storyboard for: ${scene.actions.join(' ')}`,
        shotType: 'Multi-Panel Layout',
        cameraAngle: 'Various Angles',
        mood: 'Neutral',
        lighting: 'Natural',
        composition: '3-panel layout',
        panelCount: 3,
        keyMoments: scene.keyMoments
      };
    }
  }

  private buildEnhancedSystemMessage(): string {
    let systemMessage = `You are a professional storyboard artist creating visual frames`;
    
    if (this.storyContext) {
      systemMessage += ` for "${this.storyContext.scriptTitle}" - a ${this.storyContext.genre} story.

STORY CONTEXT:
- Genre: ${this.storyContext.genre} (adjust visual style accordingly)
- Main Character: ${this.storyContext.mainCharacter?.name || 'Protagonist'}
- Current Act: ${this.storyContext.currentAct} - ${this.storyContext.actDescription}
- Visual Style: ${this.storyContext.genre}-appropriate cinematography

CHARACTER VISUAL CONSISTENCY:
${Object.entries(this.storyContext.visualCharacterTraits).map(([name, traits]) => 
  `- ${name}: ${traits}`
).join('\n') || '- Characters: Maintain visual consistency'}

Create storyboard frames that match the ${this.storyContext.genre} genre and maintain visual character consistency throughout "${this.storyContext.scriptTitle}".`;
    } else {
      systemMessage += ` for a screenplay.`;
    }

    systemMessage += ` Analyze the scene and create ONE comprehensive multi-panel storyboard description that captures the entire scene in 2-4 key visual moments. Return valid JSON only in this exact format:
{
  "frame": {
    "title": "Scene Opening",
    "visualDescription": "Multi-panel storyboard showing: Panel 1 - Wide establishing shot of location; Panel 2 - Medium shot of character entering; Panel 3 - Close-up of character's reaction; Panel 4 - Action moment",
    "shotType": "Multi-Panel Layout",
    "cameraAngle": "Various Angles",
    "mood": "Tense",
    "lighting": "Natural daylight",
    "composition": "4-panel grid layout with clear visual flow",
    "panelCount": 4,
    "keyMoments": ["Character enters", "Character reacts", "Main action occurs"]
  }
}`;

    return systemMessage;
  }

  private buildVisualPrompt(scene: ParsedScene): string {
    let prompt = '';
    
    // Add story context if available
    if (this.storyContext) {
      prompt += `STORY: "${this.storyContext.scriptTitle}" (${this.storyContext.genre})
Main Character: ${this.storyContext.mainCharacter?.name || 'Protagonist'}
Act ${this.storyContext.currentAct}: ${this.storyContext.actDescription}

`;
    }

    prompt += `Scene: ${scene.heading}
Location: ${scene.location}
Time: ${scene.timeOfDay}

Action: ${scene.actions.join(' ')}
Characters present: ${scene.characters.join(', ')}
Key moments: ${scene.keyMoments.join('; ')}
Key dialogue: ${scene.dialogue.map(d => `${d.character}: "${d.text}"`).join(' | ')}

`;

    // Enhanced character descriptions with visual consistency
    if (this.storyContext && Object.keys(this.storyContext.visualCharacterTraits).length > 0) {
      prompt += `CHARACTER VISUAL DETAILS:
${Object.entries(this.storyContext.visualCharacterTraits).map(([name, traits]) => 
  `${name}: ${traits}`
).join('\n')}

`;
    } else {
      const characterPrompt = CharacterExtractor.createCharacterPrompt(this.characters);
      if (characterPrompt) {
        prompt += characterPrompt + '\n';
      }
    }

    if (this.storyContext) {
      prompt += `Create a comprehensive multi-panel storyboard description for this ${this.storyContext.genre} scene from "${this.storyContext.scriptTitle}" that shows the entire scene in 2-4 key visual moments. Maintain visual consistency with established character designs and ${this.storyContext.genre} cinematography conventions.`;
    } else {
      prompt += `Create a comprehensive multi-panel storyboard description that shows the entire scene in 2-4 key visual moments. Focus on visual storytelling and clear panel flow.`;
    }

    return prompt;
  }
}
