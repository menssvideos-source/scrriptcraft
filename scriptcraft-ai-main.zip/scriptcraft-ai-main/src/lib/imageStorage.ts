import { supabase } from '../integrations/supabase/client';

export interface StoredImage {
  id: string;
  script_id: string;
  frame_id: string;
  scene_number: number;
  title: string;
  image_path: string;
  created_at: string;
}

export class ImageStorageService {
  public supabase = supabase;

  async downloadAndStoreImage(
    temporaryUrl: string,
    scriptId: string,
    frameId: string,
    sceneNumber: number,
    title: string
  ): Promise<string> {
    try {
      console.log(`Starting server-side image storage for frame ${frameId}`);
      console.log(`Source URL: ${temporaryUrl.substring(0, 60)}...`);

      // Get current user and session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        throw new Error('User not authenticated - please log in to store images');
      }

      console.log(`Using server-side storage for user: ${session.user.id}`);

      // Call the Supabase Edge Function to handle image download and storage
      const { data, error } = await supabase.functions.invoke('download-and-store-image', {
        body: {
          temporaryUrl,
          scriptId,
          frameId,
          sceneNumber,
          title
        }
      });

      if (error) {
        console.error('Edge function error:', error);
        throw new Error(`Server-side storage failed: ${error.message}`);
      }

      if (!data.success) {
        console.error('Edge function returned error:', data.error);
        throw new Error(`Server-side storage failed: ${data.error}`);
      }

      console.log(`Successfully stored image for frame ${frameId}: ${data.publicUrl}`);
      return data.publicUrl;

    } catch (error) {
      console.error('Complete image storage process failed:', error);
      throw error;
    }
  }

  async getStoredImages(scriptId: string): Promise<StoredImage[]> {
    console.log(`Fetching stored images for script: ${scriptId}`);
    
    const { data, error } = await supabase
      .from('storyboard_images')
      .select('*')
      .eq('script_id', scriptId)
      .order('scene_number', { ascending: true });

    if (error) {
      console.error('Error fetching stored images:', error);
      throw error;
    }

    console.log(`Found ${data?.length || 0} stored images`);
    return data || [];
  }

  async deleteStoredImage(scriptId: string, frameId: string): Promise<void> {
    console.log(`Deleting stored image: script=${scriptId}, frame=${frameId}`);

    // First get the image path
    const { data: imageData } = await supabase
      .from('storyboard_images')
      .select('image_path')
      .eq('script_id', scriptId)
      .eq('frame_id', frameId)
      .single();

    if (imageData?.image_path) {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('storyboard-images')
        .remove([imageData.image_path]);

      if (storageError) {
        console.error('Error deleting from storage:', storageError);
      }
    }

    // Delete from database
    const { error: dbError } = await supabase
      .from('storyboard_images')
      .delete()
      .eq('script_id', scriptId)
      .eq('frame_id', frameId);

    if (dbError) {
      console.error('Error deleting from database:', dbError);
      throw dbError;
    }

    console.log('Image deleted successfully');
  }

  async deleteAllImagesForScript(scriptId: string): Promise<void> {
    console.log(`Deleting all images for script: ${scriptId}`);

    // Get all image paths for this script
    const { data: images } = await supabase
      .from('storyboard_images')
      .select('image_path')
      .eq('script_id', scriptId);

    if (images && images.length > 0) {
      // Delete from storage
      const imagePaths = images.map(img => img.image_path);
      const { error: storageError } = await supabase.storage
        .from('storyboard-images')
        .remove(imagePaths);

      if (storageError) {
        console.error('Error deleting from storage:', storageError);
      }
    }

    // Delete from database
    const { error: dbError } = await supabase
      .from('storyboard_images')
      .delete()
      .eq('script_id', scriptId);

    if (dbError) {
      console.error('Error deleting from database:', dbError);
      throw dbError;
    }

    console.log(`Deleted all images for script ${scriptId}`);
  }
}
