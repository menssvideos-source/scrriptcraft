
import { Language, LanguageConfig } from './types';
import { languages } from './languages';
import { enTranslations } from './translations/en';
import { arTranslations } from './translations/ar';

export type { Language, LanguageConfig };
export { languages };

export const translations = {
  en: enTranslations,
  ar: arTranslations
} as const;

export type TranslationKey = keyof typeof enTranslations;
