
export type Language = 'en' | 'ar';

export interface LanguageConfig {
  name: string;
  dir: 'ltr' | 'rtl';
}
