
import { Language, LanguageConfig } from './types';

export const languages: Record<Language, LanguageConfig> = {
  en: { name: 'English', dir: 'ltr' },
  ar: { name: 'العربية', dir: 'rtl' }
};
