
import { StoryboardFrame } from './storyboard';
import JSZip from 'jszip';

export class DownloadService {
  static async downloadSingleImage(frame: StoryboardFrame) {
    if (!frame.imageUrl) {
      throw new Error('No image URL available for this frame');
    }

    try {
      const response = await fetch(frame.imageUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `scene-${frame.sceneNumber}-${frame.title.replace(/[^a-zA-Z0-9]/g, '-')}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download image:', error);
      throw error;
    }
  }

  static async downloadAllImages(frames: StoryboardFrame[], scriptTitle: string = 'storyboard') {
    const framesWithImages = frames.filter(frame => frame.imageUrl);
    
    if (framesWithImages.length === 0) {
      throw new Error('No images available to download');
    }

    if (framesWithImages.length === 1) {
      // Download single image directly
      return this.downloadSingleImage(framesWithImages[0]);
    }

    // Create ZIP file for multiple images
    const zip = new JSZip();
    
    try {
      console.log(`Downloading ${framesWithImages.length} images for ZIP archive...`);
      
      const downloadPromises = framesWithImages.map(async (frame) => {
        try {
          const response = await fetch(frame.imageUrl!);
          if (!response.ok) {
            throw new Error(`Failed to fetch image for scene ${frame.sceneNumber}`);
          }
          
          const blob = await response.blob();
          const fileName = `scene-${frame.sceneNumber.toString().padStart(2, '0')}-${frame.title.replace(/[^a-zA-Z0-9]/g, '-')}.png`;
          zip.file(fileName, blob);
          
          console.log(`Added ${fileName} to ZIP`);
        } catch (error) {
          console.error(`Failed to download image for scene ${frame.sceneNumber}:`, error);
          // Continue with other images even if one fails
        }
      });

      await Promise.all(downloadPromises);
      
      console.log('Generating ZIP file...');
      const content = await zip.generateAsync({ type: 'blob' });
      
      const url = window.URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${scriptTitle.replace(/[^a-zA-Z0-9]/g, '-')}-storyboard.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      window.URL.revokeObjectURL(url);
      console.log('ZIP download completed');
      
    } catch (error) {
      console.error('Failed to create ZIP archive:', error);
      throw error;
    }
  }
}
