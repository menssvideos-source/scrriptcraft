
import { Character } from '../types/project';
import { SceneAnalyzer, AnalyzedScene } from './sceneAnalyzer';

export interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export interface ParsedScene {
  id: string;
  heading: string;
  location: string;
  timeOfDay: string;
  actions: string[];
  characters: string[];
  dialogue: { character: string; text: string }[];
  keyMoments: string[];
  visualDescription?: string;
  shotSuggestions?: string[];
  mood?: string;
}

export class SceneParser {
  static parseScenes(elements: ScriptElement[]): ParsedScene[] {
    console.log(`SceneParser: Delegating to SceneAnalyzer for ${elements.length} elements`);
    
    // Use the unified SceneAnalyzer
    const analyzedScenes = SceneAnalyzer.analyzeScenes(elements);
    
    // Convert to ParsedScene format for backwards compatibility
    const parsedScenes: ParsedScene[] = analyzedScenes.map(scene => ({
      id: scene.id,
      heading: scene.heading,
      location: scene.location,
      timeOfDay: scene.timeOfDay,
      actions: scene.actions,
      characters: scene.characters,
      dialogue: scene.dialogue,
      keyMoments: scene.keyMoments
    }));
    
    console.log(`SceneParser: ✅ Converted ${analyzedScenes.length} analyzed scenes to parsed scenes`);
    console.log('SceneParser: All scene headings found:', parsedScenes.map(s => s.heading));
    
    return parsedScenes;
  }
}
