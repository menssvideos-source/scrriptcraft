
import { SceneAnalyzer, AnalyzedScene } from './sceneAnalyzer';

interface ScriptElement {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition';
  content: string;
}

export interface SceneInfo {
  number: number;
  heading: string;
  type: 'opening' | 'inciting' | 'character' | 'conflict' | 'revelation' | 'climax' | 'resolution' | 'general';
  location: string;
  timeOfDay: string;
}

export class SceneNumbering {
  static detectScenes(elements: ScriptElement[]): SceneInfo[] {
    console.log(`SceneNumbering: Delegating to SceneAnalyzer for ${elements.length} elements`);
    
    // Use the unified SceneAnalyzer
    const analyzedScenes = SceneAnalyzer.analyzeScenes(elements);
    
    // Convert to SceneInfo format for backwards compatibility
    const sceneInfos: SceneInfo[] = analyzedScenes.map(scene => ({
      number: scene.number,
      heading: scene.heading,
      type: scene.type,
      location: scene.location,
      timeOfDay: scene.timeOfDay
    }));
    
    console.log(`SceneNumbering: ✅ Converted ${analyzedScenes.length} analyzed scenes to scene infos`);
    console.log('SceneNumbering: All detected scenes:', sceneInfos.map(s => `${s.number}. ${s.heading}`));
    
    return sceneInfos;
  }

  static getNextSceneNumber(elements: ScriptElement[]): number {
    return SceneAnalyzer.getNextSceneNumber(elements);
  }

  static generateSceneHeading(
    sceneNumber: number,
    location: string = '',
    timeOfDay: string = 'DAY',
    isInterior: boolean = true
  ): string {
    const prefix = isInterior ? 'INT.' : 'EXT.';
    const formattedLocation = location.toUpperCase() || 'LOCATION';
    const formattedTime = timeOfDay.toUpperCase();
    
    return `${prefix} ${formattedLocation} - ${formattedTime}`;
  }

  static getSceneTypeDescription(type: SceneInfo['type']): string {
    return SceneAnalyzer.getSceneTypeDescription(type);
  }
}
