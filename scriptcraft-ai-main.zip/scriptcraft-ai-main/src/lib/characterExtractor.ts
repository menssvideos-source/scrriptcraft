
export interface CharacterDescription {
  name: string;
  description: string;
  physicalTraits: string[];
  clothing: string[];
}

export class CharacterExtractor {
  static extractCharacterDescriptions(elements: any[]): CharacterDescription[] {
    const characters: Map<string, CharacterDescription> = new Map();
    
    for (const element of elements) {
      if (element.type === 'action' && element.content) {
        // Look for character descriptions in action lines
        const descriptions = this.parseCharacterDescriptions(element.content);
        descriptions.forEach(char => {
          if (!characters.has(char.name)) {
            characters.set(char.name, char);
          } else {
            // Merge descriptions
            const existing = characters.get(char.name)!;
            existing.physicalTraits = [...new Set([...existing.physicalTraits, ...char.physicalTraits])];
            existing.clothing = [...new Set([...existing.clothing, ...char.clothing])];
          }
        });
      }
    }
    
    return Array.from(characters.values());
  }

  private static parseCharacterDescriptions(text: string): CharacterDescription[] {
    const characters: CharacterDescription[] = [];
    
    // Basic patterns to identify character descriptions
    const characterPatterns = [
      /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*),?\s*(?:a|an)?\s*([^.]+)/g,
      /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:is|was|appears?|looks?)\s+([^.]+)/g,
      /(?:The|A)\s+([^,]+),\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/g
    ];

    for (const pattern of characterPatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const [, name, description] = match;
        if (name && description && name.length < 30) {
          const physicalTraits = this.extractPhysicalTraits(description);
          const clothing = this.extractClothing(description);
          
          characters.push({
            name: name.trim(),
            description: description.trim(),
            physicalTraits,
            clothing
          });
        }
      }
    }
    
    return characters;
  }

  private static extractPhysicalTraits(text: string): string[] {
    const traits: string[] = [];
    const traitPatterns = [
      /\b(tall|short|thin|fat|muscular|slim|athletic|elderly|young|middle-aged)\b/gi,
      /\b(blonde?|brunette?|redhead|black-haired|gray-haired|bald)\b/gi,
      /\b(blue|brown|green|hazel|dark|light)\s+eyes?\b/gi,
      /\b(pale|tan|dark|olive|fair)\s+skin\b/gi,
      /\b(beard|mustache|glasses|scar|tattoo)\b/gi
    ];

    for (const pattern of traitPatterns) {
      const matches = text.match(pattern);
      if (matches) {
        traits.push(...matches.map(m => m.toLowerCase()));
      }
    }

    return [...new Set(traits)];
  }

  private static extractClothing(text: string): string[] {
    const clothing: string[] = [];
    const clothingPatterns = [
      /\b(suit|dress|jeans|shirt|jacket|coat|uniform|robe|gown)\b/gi,
      /\b(wearing|dressed in|clad in)\s+([^.]+)/gi
    ];

    for (const pattern of clothingPatterns) {
      const matches = text.match(pattern);
      if (matches) {
        clothing.push(...matches.map(m => m.toLowerCase()));
      }
    }

    return [...new Set(clothing)];
  }

  static createCharacterPrompt(characters: CharacterDescription[]): string {
    if (characters.length === 0) return '';
    
    const characterDescriptions = characters.map(char => {
      const traits = char.physicalTraits.length > 0 ? ` (${char.physicalTraits.join(', ')})` : '';
      const clothing = char.clothing.length > 0 ? ` wearing ${char.clothing.join(', ')}` : '';
      return `${char.name}${traits}${clothing}`;
    }).join(', ');

    return `Character consistency: ${characterDescriptions}.`;
  }
}
