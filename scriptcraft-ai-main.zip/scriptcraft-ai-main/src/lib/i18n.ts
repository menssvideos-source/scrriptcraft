
// Re-export everything from the new modular structure
export type { Language, LanguageConfig, TranslationKey } from './i18n/index';
export { languages, translations } from './i18n/index';
