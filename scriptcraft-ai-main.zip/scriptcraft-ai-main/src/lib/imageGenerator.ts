
import { CharacterDescription } from './characterExtractor';

export interface ImageGenerationParams {
  prompt: string;
  size?: '1024x1024' | '1792x1024' | '1024x1792';
  quality?: 'standard' | 'hd';
  style?: 'vivid' | 'natural';
}

export interface GeneratedImage {
  url: string;
  revisedPrompt?: string;
}

export class ImageGenerator {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private validateApiKey(): void {
    if (!this.apiKey || !this.apiKey.trim()) {
      throw new Error('OpenAI API key is required for image generation');
    }
    
    if (!this.apiKey.startsWith('sk-')) {
      throw new Error('Invalid OpenAI API key format. Please check your API key.');
    }
  }

  async generateImage(params: ImageGenerationParams): Promise<GeneratedImage> {
    this.validateApiKey();
    
    console.log('Generating image with DALL-E 3:', {
      promptLength: params.prompt.length,
      size: params.size,
      quality: params.quality,
      style: params.style
    });

    try {
      const response = await fetch('https://api.openai.com/v1/images/generations', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: params.prompt,
          n: 1,
          size: params.size || '1024x1024',
          quality: params.quality || 'standard',
          style: params.style || 'natural',
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `Image generation failed: ${response.status} ${response.statusText}`;
        
        try {
          const errorData = JSON.parse(errorText);
          if (errorData.error?.message) {
            errorMessage = `Image generation failed: ${errorData.error.message}`;
          }
        } catch (parseError) {
          console.error('Failed to parse error response:', parseError);
        }
        
        console.error('OpenAI API Error:', errorMessage, errorText);
        throw new Error(errorMessage);
      }

      const data = await response.json();
      
      if (!data.data || !data.data[0] || !data.data[0].url) {
        throw new Error('Invalid response format from OpenAI API');
      }
      
      console.log('Image generated successfully:', {
        originalUrl: data.data[0].url,
        revisedPrompt: data.data[0].revised_prompt?.slice(0, 100) + '...'
      });
      
      return {
        url: data.data[0].url,
        revisedPrompt: data.data[0].revised_prompt
      };
    } catch (error) {
      console.error('Image generation error:', error);
      
      if (error instanceof Error) {
        // Re-throw with more specific error message
        if (error.message.includes('API key')) {
          throw new Error('Invalid API key. Please check your OpenAI API key in the settings.');
        } else if (error.message.includes('quota')) {
          throw new Error('API quota exceeded. Please check your OpenAI account billing.');
        } else if (error.message.includes('network') || error.message.includes('fetch')) {
          throw new Error('Network error. Please check your internet connection and try again.');
        }
      }
      
      throw error;
    }
  }

  createCinematicPrompt(visualDescription: string, shotType: string, mood: string, lighting: string): string {
    return `Professional cinematic storyboard frame: ${visualDescription}. Shot type: ${shotType}. Mood: ${mood}. Lighting: ${lighting}. Rendered in the style of a professional film storyboard sketch, black and white, detailed but clean composition, suitable for pre-production planning.`;
  }

  createMultiPanelCinematicPrompt(
    visualDescription: string, 
    shotType: string, 
    mood: string, 
    lighting: string,
    sceneNumber: number,
    panelCount: number,
    keyMoments: string[],
    characters: CharacterDescription[]
  ): string {
    
    // Create character consistency description
    const characterPrompt = characters.length > 0 
      ? `Character consistency: ${characters.map(char => {
          const traits = char.physicalTraits.length > 0 ? ` (${char.physicalTraits.join(', ')})` : '';
          const clothing = char.clothing.length > 0 ? ` wearing ${char.clothing.join(', ')}` : '';
          return `${char.name}${traits}${clothing}`;
        }).join(', ')}. ` 
      : '';

    // Create panel layout description
    const panelLayout = panelCount === 2 ? '2-panel horizontal layout' :
                       panelCount === 3 ? '3-panel horizontal layout' :
                       panelCount === 4 ? '2x2 grid layout' :
                       '3-panel layout';

    const prompt = `Professional hand-drawn pencil sketch storyboard in ${panelLayout}. Scene number "#${sceneNumber}" clearly visible in upper left corner. ${characterPrompt}${visualDescription}. Overall mood: ${mood}. Lighting: ${lighting}. Style: Hand-drawn pencil sketches, clean line art, professional film storyboard aesthetic, no text or dialogue bubbles, no written words except scene number. Each panel shows clear visual storytelling with consistent character designs across panels. Black and white sketched illustrations only.`;
    
    console.log('Generated multi-panel prompt:', {
      sceneNumber,
      panelCount,
      promptLength: prompt.length,
      hasCharacters: characters.length > 0
    });
    
    return prompt;
  }
}
